import falcon
import settings
import logging

from middleware.AuthHandler import AuthHandler
from middleware.DatabaseManager import DatabaseManager
from middleware.JSONTranslator import JSONTranslator
from falcon_multipart.middleware import MultipartMiddleware
from routes.v1_routes import V1RoutesDict
from database.mongo import mongoDb
from falcon_cors import CORS

cors = CORS(allow_all_origins=True, allow_all_headers=True,
            allow_all_methods=True)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
    ]
)

# Initialize Middleware
middleware = [DatabaseManager(mongoDb), AuthHandler(), JSONTranslator(), MultipartMiddleware(),cors.middleware]

app = falcon.App(middleware=middleware)

app.req_options.keep_blank_qs_values = True
app.req_options.auto_parse_form_urlencoded = True

# Register API Route To APP
for keys, value in V1RoutesDict.items():
    route = settings.V1_API_PREFIX + keys
    app.add_route(route, value)
    logging.info(f'Registered route: {route}')


class LoggingMiddleware:
    def process_request(self, req, resp):
        logging.info(f'Received {req.method} request to {req.url}')

    def process_response(self, req, resp, resource, req_succeeded):
        logging.info(f'Response status: {resp.status} for {req.method} request to {req.url}')

middleware.append(LoggingMiddleware())
