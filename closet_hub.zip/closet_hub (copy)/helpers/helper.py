import json
from bson.json_util import dumps
from datetime import datetime, timedelta
from utils.auth import encodeJwt

from settings import JWT_EXPIRY_DAY, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_BUCKET_NAME
import boto3
import re

def create_token(id):

    payload = {
        "sub": str(id),
        "iat": datetime.now() - timedelta(days=1),
        "exp": datetime.now() + timedelta(int(JWT_EXPIRY_DAY))}

    decodedJwt = encodeJwt(payload)

    encodedJwt = decodedJwt
    return encodedJwt

def bson_to_json(documents):
    if not documents:
        return []

    documents_list = list(documents)

    json_data = json.loads(dumps(documents_list))

    return json_data

def imageUploadToS3(image):
    image.file.seek(0)
    image_name = image.filename
    new_image_name = image_name.replace(" ", "_")

    session = boto3.Session(
        aws_access_key_id=AWS_ACCESS_KEY_ID,
        aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
    )
    s3 = session.resource('s3')
    s3_client = session.client('s3')
    bucket_name = AWS_BUCKET_NAME

    try:
        s3.Object(bucket_name, new_image_name).put(Body=image.file.read())
        return f"https://{bucket_name}.s3.ap-south-1.amazonaws.com/{new_image_name}"
    except FileNotFoundError:
        print("The file was not found")
        return False

def imageUploadToS3new(file_object, filename):
    file_object.seek(0)
    new_image_name = filename.replace(" ", "_")

    session = boto3.Session(
        aws_access_key_id=AWS_ACCESS_KEY_ID,
        aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
    )
    s3 = session.resource('s3')
    bucket_name = AWS_BUCKET_NAME

    try:
        s3.Object(bucket_name, new_image_name).put(Body=file_object.read())
        return f"https://{bucket_name}.s3.ap-south-1.amazonaws.com/{new_image_name}"
    except FileNotFoundError:
        print("The file was not found")
        return False


def extract_products_from_mongo(mongo_session, store_id, identifiers):
    collection_name = f"data_all_{store_id}"
    all_data_coll = mongo_session['closet'][collection_name]

    regex_patterns = [re.escape(name) + "$" for name in identifiers]  # Escapes any regex special characters in filenames
    regex_query = "|".join(regex_patterns)  # Joins all patterns as alternatives

    query = {"images": {"$regex": regex_query}}

    # Fetching the documents that match the query
    documents = all_data_coll.find(query)

    results = list(documents)

    final_result=[]

    for item in results:
        final_result.append({
            "product_name" : item["product_name"],
            "product_id" : item["product_id"],
            "stock" : item["stock"],
            "price" : item["price"],
            "special_price" : item["special_price"],
            "categories" : item["categories"],
            "artists" : item["artists"],
            "patterns" : item["patterns"],
            "material_compositions" : item["material_compositions"],
            "seasons" : item["seasons"],
            "occasions" : item["occasions"],
            "textures" : item["textures"],
            "images" : item["images"],
            })

    return final_result
