import falcon
from utils.auth import decodeJwt
from bson import ObjectId

class AuthHandler(object):
    def process_request(self, req, resp):
        if req.auth and req.auth != 'null':
            req.context['user'] = None
            tokenData = decodeJwt(req.auth)

            if tokenData is None:
                raise falcon.HTTPUnauthorized("Your session has expired.Kindly logout and login")

            user_id = tokenData.get("sub", None)

            if user_id:
                req.context['user'] = user_id

                mongo_session = req.context['mongo_session']

                # Access the database
                db = mongo_session['closet']

                # Access the collection
                user_collection = db['data_users']

                # Query to find the user by _id
                udata = user_collection.find_one({"user_id": int(user_id)})

                if not udata:
                    raise falcon.HTTPUnauthorized("Your session has expired.Kindly logout and login")

                req.context['user'] = {
                    'user': user_id,
                    'first_name': udata.get('first_name', ""),
                    'last_name': udata.get('last_name', ""),
                    'email': udata.get('email', ""),
                    'phone': udata.get('phone', ""),
                    'created_at': udata.get('created_at', "")
                }
            else:
                raise falcon.HTTPUnauthorized("Your session has expired.Kindly login")
        else:
            req.context['user'] = None
