import os
from os.path import join, dirname
from dotenv import load_dotenv, find_dotenv

dotenv_path = join(dirname(__file__), '.env')
load_dotenv(find_dotenv(), override=True)
ENV = os.environ

V1_API_PREFIX = '/api/v1'
JWT_EXPIRY_DAY = 30
SECRET_KEY = ""
LLAMA_API_KEY = ""


# AWS S3 credentials
AWS_ACCESS_KEY_ID=''
AWS_SECRET_ACCESS_KEY=''
AWS_BUCKET_NAME=''


OPEN_API_KEY=""
