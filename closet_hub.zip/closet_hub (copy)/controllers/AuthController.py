import json
import bcrypt
import falcon

from helpers.helper import create_token
from utils.validations import email_validation,data_sanitization
from datetime import datetime


class Login:

    def on_post(self, req, resp):
        reqData = req.context["data"]
        mongo_session = req.context['mongo_session']

        if not reqData or 'email' not in reqData or 'password' not in reqData:
            raise falcon.HTTPBadRequest("Invalid Input", "Email and password are required")

        email = reqData["email"]
        password = reqData["password"]

        if not email_validation(email):
            raise falcon.HTTPBadRequest("Invalid Input", "Enter a valid email address")

        users_collection = mongo_session['closet']['data_users']

        user = users_collection.find_one({"email": email})
        if user:
            try:
                stored_hash = user.get("password")
                if str(password) == str(stored_hash):
                    auth_token = create_token(str(user['user_id']))
                    data = {
                        "message": "Login successful",
                        "user_id": str(user['user_id']),
                        "auth_token": auth_token
                    }
                    resp.status = falcon.HTTP_200
                    resp.text = json.dumps(data)
                    return
                else:
                    data = {"message": "Invalid email or password"}
                    resp.status = falcon.HTTP_401
            except ValueError as e:
                print(str(e))
                raise falcon.HTTPUnauthorized("Invalid Credentials", "Invalid password hash format.")
        else:
            data = {"message": "User Not Found"}
            resp.status = falcon.HTTP_404

        resp.text = json.dumps(data)

