<template>
  <div v-if="showHeader" :class="{'supima-menu': callerComp === 'supimaMenu', 'activewear-menu': callerComp === 'activeWearMenu', 'birthday-logo': isBirthdayMonth}">
    <div id="notifylogin" class="notifylogin">&nbsp;</div>
    <div class="loadingOverlay" v-if="userAcc.loader">
      <div class="loading"></div>
    </div>
    <div v-if="!['supimaMenu', 'activeWearMenu'].includes(callerComp)" class="topbar img-auto" :class="{ bgOrange: $route.path === '/membership' }">
      <div class="container py-1" :class="bannerPlaceHolderForAppDownldPopup ? 'goAppOnlySale' : ''">
        <div class="row" v-if="(this.getSystemBrowser() !== 'safari') && bannerPlaceHolderForAppDownldPopup && !isBflUtm && !bannerPlaceHolderForGoForAppOnlySale">
          <div
            class="col-12 text-white d-flex justify-content-end align-items-center justify-content-center"
            :class="(this.getSystemBrowser() === 'safari') ? 'py-1' :'py-2'"
          >
            <div class="col">
              {{bannerPlaceHolderForAppDownldPopup && bannerPlaceHolderForAppDownldPopup.tag_text}}
            </div>
            <div>
              <span
                @click="appOpenHandler"
                class="pointer text-uppercase p-1"
                style="border: 2px solid #fff; border-radius: 6px;"
              >
                &ensp;
                <i
                  class="fa fa-mobile mr-1"
                  style="font-size: 15px;"
                  aria-hidden="true"
                ></i>
                Open App&ensp;
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <nav class="navbar navbar-toggleable-md navbar-light bg-faded">
      <button
        v-if="!bannerPlaceHolderForGoForAppOnlySale && $route.name === 'home' || ['supimaMenu', 'activeWearMenu'].includes(callerComp)"
        class="navbar-toggler navbar-toggler-left newmobilenav"
        aria-label="navigation menu"
        type="button"
        @click="navCategoriesRequestHandler"
      >
        <span v-if="$route.name === 'home'" class="navbar-toggler-icon"></span>
        <span v-else class='menu-hamburger'>
          <img src='./assets/images/hamburger-white.png'/>
        </span>
      </button>
      <div
        class="navbar-toggler-left toggle-menu left-arrow-style"
        v-else
      >
        <img v-if="!bannerPlaceHolderForGoForAppOnlySale" @click="goToPreviousPage" data-src="https://tss-static-images.gumlet.io/icons/back_arrow.png" alt="Arrow"/>
      </div>
      <div v-if="this.$route.name === 'listing' || this.$route.name === 'search' || this.$route.name === 'mywishlist'" class="pl-4"
        :class="[this.$route.name === 'mywishlist' ? 'pr-1' : 'pr-5', productListingStyle.fontPosition ? `text-${productListingStyle.fontPosition}` : '']"
      >
        <span
          class="pl-3 pr-5 txtTruncate font-weight-bold text-capitalize"
          style="color:#191919;"
          :class="productListingHeader.subHeader ? '' : 'pt-1'"
        >
          {{productListingHeader.header}}
        </span>
        <span 
          v-if="productListingHeader.subHeader"
          class="pl-2 pr-5 txtTruncate text-capitalize"
          style="line-height:1;font-size: 12px;"
        >{{productListingHeader.subHeader}}</span>
      </div>
      <div v-show="!bannerPlaceHolderForGoForAppOnlySale" class="headerRight">
        <div>
          <span class="hicon" @click="openSearch()">
            <img
              v-if="['supimaMenu', 'activeWearMenu'].includes(callerComp)"
              style="width: 27px !important;"
              src='./assets/images/search-white.png'
              alt="search"
            />
            <img v-else :src="imgBaseUrl + 'appIcons/ic_search@2x.png'" alt="search"/>
          </span>
         <router-link
           :to="'/mywishlist'"
           class="hicon"
           v-if="!disableWishlist && $route.name !== 'mywishlist'"
           @click.native="myWishlistVisitEventHandler('default')"
          >
            <span
              v-if="['supimaMenu', 'activeWearMenu'].includes(callerComp)"
              class="headercart hicon fa heart"
              :class="this.$router.currentRoute.path === '/mywishlist' ? 'fa-heart-o active' : 'fa-heart-o'"
            ></span>
            <span v-else class="headercart hicon">
              <img :src="imgBaseUrl + 'appIcons/ic_wishlist@2x.png'" alt="wishlist" />
            </span>
            <div class="count" v-if="wishlistCount > 0">{{ wishlistCount }}</div>
          </router-link>
          <router-link :to="'/cart'" class="hicon" @click.native="removeBlackShow()">
            <span @click="cartEventHandler">
              <svg xmlns="http://www.w3.org/2000/svg"
                class="mt-1 headercart"
                width="25"
                height="23"
                viewBox="0 0 48 48"
                v-if="['supimaMenu', 'activeWearMenu'].includes(callerComp)"
                style="stroke: #fff;fill: #fff;stroke-width:1.4;-webkit-font-smoothing: antialiased;"
              >
                <path xmlns="http://www.w3.org/2000/svg"
                  d="M43,46H5c-2.209,0-4-1.791-4-4l4-24c0.678-3.442,2.668-4,4.877-4h2.652  C14.037,7.052,18.602,2,24,2s9.963,5.052,11.471,12h2.652c2.209,0,4.199,0.558,4.877,4l4,24C47,44.209,45.209,46,43,46z M24,4  c-4.352,0-8.045,4.178-9.418,10h18.837C32.045,8.178,28.353,4,24,4z M41,18c-0.308-1.351-0.957-2-2.37-2h-2.828  C35.925,16.976,36,17.975,36,19c0,0.552-0.447,1-1,1s-1-0.448-1-1c0-1.027-0.069-2.031-0.201-3H14.201C14.07,16.969,14,17.973,14,19  c0,0.552-0.447,1-1,1s-1-0.448-1-1c0-1.025,0.075-2.024,0.197-3H9.369C7.957,16,7.309,16.649,7,18L3,42c0,1.104,0.896,2,2,2h38  c1.104,0,2-0.896,2-2L41,18z"
                  shape-rendering="auto"
                />
                <line x1="5" y1="32" x2="44" y2="32" style="stroke-width:3;"/>
              </svg>
              <img v-else :src="imgBaseUrl + 'appIcons/ic_newCart@2x.png'" alt="cart" />
              <div class="count" v-if="cartcount > 0">{{ cartcount }}</div>
            </span>
          </router-link>
        </div>
      </div>
      <div
        v-if="this.$route.name !== 'listing' && this.$route.name !== 'search' && this.$route.name !== 'mywishlist'"
        :class="['supimaMenu', 'activeWearMenu'].includes(callerComp) ? 'pabsolute supima-home-logo' : 'navbar-brand'"
        @click="homeEventHandler(webcategory && isComboActive ?'/'+ webcategory:'/')"
      >
        <img v-if="['supimaMenu', 'activeWearMenu'].includes(callerComp)" :src="callerComp === 'supimaMenu' ? imgBaseUrl + 'supima-home-logo.png' : imgBaseUrl + 'active-wear-logo-mob.png'"/>
        &nbsp;
      </div>
      <div>
        <div
          class="collapse navbar-collapse stylescrollbar navMenu"
          id="navbarNavDropdown"
          :class="!['supimaMenu', 'activeWearMenu'].includes(callerComp) ? 'navbar-mt' : ''"
        >
          <div class="navheader showmobile">
              <div class="row header-background">
              <div
                class="navbar-toggler-left toggle-menu left-arrow-style" style="top: 20px;"
                @click="setHomeMenu(webcategory)"
              >
                <img data-src="https://tss-static-images.gumlet.io/icons/back_arrow.png" alt="Arrow"/>
              </div>
              <div style="left: 38%;" class="col-4 col-sm-3 col-md-2 d-flex align-items-center">
                <router-link :to="webcategory && isComboActive ? '/'+ webcategory:'/'" class="toggle-menu"
                  >&nbsp;
                  <img
                    :data-src="exclusiveUser ? 'https://prod-img.thesouledstore.com/public/theSoul/images/exclusive/MemebrIcon_On.png' : '/static/img/newlogosticky.f7f01f0.png'"
                    class="sidebar-home-img"
                    alt="The Souled Store Logo"
                  />
                </router-link>
              </div>
              <div class="headerRight mt-2">
                <div>
                  <span class="hicon" @click="openSearch()">
                    <img :src="imgBaseUrl + 'appIcons/ic_search@2x.png'" alt="search"/>
                  </span>
                  <router-link :to="'/cart'" @click.native="removeBlackShow()" class="hicon">
                    <span @click="cartEventHandler">
                      <img :src="imgBaseUrl + 'appIcons/ic_newCart@2x.png'" alt="cart"/>
                      <div class="count" v-if="cartcount > 0">{{ cartcount }}</div>
                    </span>
                  </router-link>
                </div>
              </div>
            </div>
          </div>
          <categories 
            moreSectionId='collapseMoreNav'
            v-if="isCategoryRequested"
          >
          </categories>
        </div>
        <div class="overlay"></div>
      </div>
      <div>
        <div class="mobilesearch" v-if="togglesearch">
          <div class="mbinput">
            <autocomplete
              :trigger="trigger"
              :searchTerm="searchTerm"
            ></autocomplete>
          </div>
        </div>
      </div>
    </nav>
    <div class="row home-gender-wrapper" v-if="!bannerPlaceHolderForGoForAppOnlySale && ($route.path === '/men' || $route.path === '/women' || $route.path === '/kids')">
        <div class="col" style="padding-top: 0.1rem;" :class="$route.path === '/men' ? 'home-active-tab-class':''">
          <button  :style="$route.path === '/men' ? 'font-weight: 600' : ''" class='tab-btn pt-1 pb-1 men '  @click="setHomeMenu('men')">
            Men
          </button>
        </div>
        <div class="col" style="padding-top: 0.1rem;" :class="$route.path === '/women' ? 'home-active-tab-class':''">
          <button :style="$route.path === '/women' ? 'font-weight: 600' : ''" class='tab-btn pt-1 pb-1 women'  @click="setHomeMenu('women')">
            Women
          </button>
        </div>
        <div v-if="bannerPlaceHolderForKidsWebCategory" class="col" style="padding-top: 0.1rem;" :class="$route.path === '/kids' ? 'home-active-tab-class':''">
          <button  :style="$route.path === '/kids' ? 'font-weight: 600' : ''" class='tab-btn pt-1 pb-1 men '  @click="setHomeMenu('kids')">
            Kids
          </button>
        </div>
      </div>
    <login-modal
      v-if="loginModel"
      @close="userAcc.loginBox = false"
    ></login-modal>
    <order-track v-if="oTrack" @close="oTrack = false"></order-track>
  </div>
</template>
<script>
var $ = require('jquery')
window.jQuery = $
const LoginModal = () => import('./components/common/LoginModal.vue')
const orderTrack = () => import('./components/widgets/orderTrack')
const autocomplete = () => import('./components/common/autocomplete')
const categories = () => import('./components/categories.vue')
import auth from './auth/index.js'
import { mapGetters } from 'vuex'
import debounce from 'lodash/debounce'
import {appMixins, osDetector, browserDetector} from './assets/js/appMixins'
import Vue from 'vue'

var offm = {
  props: {
    dataname: String,
    dataurl: String
  },
  data () {
    return {
      linkarray: this.dataname.split(','),
      datalink: this.dataurl.split(','),
      linkpath: '/artists/'
    }
  },
  template:
    '<div class="sublevel2"><ul class="submenu"><li v-for="(item, index) in linkarray" :key="index"><a href="https://www.thesouledstore.com" target="_blank" v-if="datalink[index] === \'wwe-official-merchandise\'">{{ item}} </a> <router-link :to="\'/artist/\'+ datalink[index]" v-else>{{ item}} </router-link></li></ul></div>'
}
export default {
  name: 'app',
  components: {
    LoginModal,
    'off-nav': offm,
    orderTrack,
    autocomplete,
    categories
  },
  mixins: [appMixins, osDetector, browserDetector],
  data () {
    return {
      userAcc: auth.user,
      activeCl: 'navopen',
      ckAuth: auth,
      searchTerm: '',
      value: '',
      suggestionAttribute: 'product',
      suggestions: [],
      selectedEvent: '',
      oTrack: false,
      count: 0,
      catImgPath: process.env.IMG_BASE_URL + process.env.CATEGORY_IMG,
      togglesearch: false,
      now: new Date(),
      launchDate: new Date(process.env.TIMER_START),
      trigger: false,
      showHeader: true,
      activeGenderType: 'men',
      imgBaseUrl: process.env.STATIC_IMG_SERVER2,
      isCategoryRequested: false
    }
  },
  methods: {
    setHomeMenu (gender) {
      this.activeCl = 'navopen'
      this.$store.commit('WEBCATEGORY', gender)
      Vue.ls.set('tss_landingCategory', gender)
      this.$router.push(`/${gender}`)
    },
    redirectToMyAcc () {
      this.$router.push('/my-account')
    },
    openSearch () {
      this.$router.push('/autocomplete')
    },
    removeBlackShow () {
      $('.overlay').removeClass('show')
    },
    redirectToLogin () {
      this.$router.push(`/login?redirect=${this.$route.fullPath}`)
    },
    logout () {
      // auth.logout(this, '/')
      this.$store.dispatch('BLACKLIST_LOGOUT').then(res => {
        this.$store.dispatch('LOGOUT', {
          requiresAuth: this.$route.meta.requiresAuth
        }).then(res => {
          this.$toasted.show((res && res.message) || 'You have been successfully logged out', {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
          this.$store.dispatch('CART_DATA')
          this.$store.dispatch('WISHLIST_DATA')
          $('body').removeClass('_freeze')
          $('.overlay').removeClass('show')
          this.$store.state.auth.phoneNumber = ''
        })
      })
    },
    search: function (e) {
      var regex = new RegExp(/^\s+$/)
      if (regex.test(this.value)) {
        this.value = ''
      } else {
        if (e.keyCode === 13) {
          this.$router.push('/search?q=' + this.value)
        } else if (this.value.length > 2) {
          // this.$router.push('/search/' + this.value)
        }
      }
    },
    goToPreviousPage () {
      window.history.back()
    },
    myWishlistVisitEventHandler (priority) {
      priority === 'default' ? this.$store.commit('GTAG_EVENT', {eventName: `myWishlist_pageview`, payload: {visitFrom: Vue.ls.get('routeObj').current}}) : this.$store.commit('GTAG_EVENT', {eventName: `myWishlist_pageview`, payload: {visitFrom: 'My Account Section'}})
    },
    homeEventHandler (path) {
      this.$store.dispatch('TATVIC_EVENT', {eventName: 'LOGO_CLICK', payload: {}})
      this.$router.push(path)
    },
    cartEventHandler () {
      this.$store.commit('GTAG_EVENT', {eventName: 'CART_ICON_CLICK', payload: {}})
    },
    appOpenHandler: debounce(function (e) {
      const gemderHomeUrl = [
        'https://www.thesouledstore.com/men',
        'https://www.thesouledstore.com/women',
        'https://www.thesouledstore.com/kids'
      ]
      let payloadUrl = gemderHomeUrl.includes(document.URL) ? 'https://www.thesouledstore.com' : document.URL
      this.$store.dispatch('GET_FIREBASE_DYNAMIC_LINK_DATA', {link: payloadUrl}).then(res => {
        res && res.shortLink && res.shortLink.length
        ? window.location.replace(res.shortLink)
        : this.appOpenFallbackHandler()
      })
      this.$store.commit('MOENGAGE_EVENT', {
        eventName: 'OPEN_APP_CLICK',
        payload: {
          UserId: this.user && this.user.user_id ? this.user.user_id : 0,
          Platform: 'WEB'
        }
      })
    }, 800),
    appOpenFallbackHandler () {
      const deviceOs = this.getMobileOperatingSystem()
      if (deviceOs === 'android') {
        const url = 'intent://thesouledstore.com/#Intent;scheme=https;package=com.thesouledstore;end'
        window.location.replace(url)
      } else if (deviceOs === 'ios') {
        window.location.replace('https://bit.ly/appxtss')
      }
    },
    navCategoriesRequestHandler () {
      this.isCategoryRequested = true
    }
  },
  beforeUpdate () {
    this.removeBlackShow()
    $('body').removeClass('_freeze')
  },
  mounted: function () {
    if (this.$route.name === 'search' && this.$route.query && this.$route.query.q) {
      this.$store.dispatch('setSearchPageKey', this.$route.query.q)
    }
    if (this.$route.path === '/autocomplete') {
      this.showHeader = false
    } else {
      this.showHeader = true
    }
    this.ckAuth.checkAuth()
    // $('.toggle-menu').on('click', this.toggleMenu)
  },
  computed: {
    ...mapGetters({
      loginModel: 'loginModelBox',
      authStatus: 'authStatus',
      cartcount: 'cartcount',
      loading: 'loading',
      _products: 'FETCH_PRODUCTS',
      isMystery: 'isMystery',
      user: 'user',
      isExclusive: 'isExclusive',
      exclusiveUser: 'exclusiveUser',
      navMenuData: 'navMenuData',
      webcategory: 'webcategory',
      isComboActive: 'isComboActive',
      wishlistCount: 'wishlistCount',
      disableWishlist: 'disableWishlist',
      exclusiveDetails: 'exclusiveDetails',
      bannerPlcaeHolderData: 'bannerPlcaeHolderData',
      productListingHeader: 'productListingHeader',
      productListingStyle: 'productListingStyle',
      isBirthdayMonth: 'isBirthdayMonth'
    }),
    callerComp () {
      if (this.$route.path.includes('supima-landing')) {
        return 'supimaMenu'
      } else if (this.$route.path.includes('active-wear-landing')) {
        return 'activeWearMenu'
      }
    },
    bannerPlaceHolderForAppDownldPopup: function () {
      return this.bannerPlcaeHolderData && this.bannerPlcaeHolderData.length && this.bannerPlcaeHolderData.find(bannerData =>
      bannerData.placeholder_for.toLowerCase() === 'Others'.toLowerCase() && bannerData.status === true && bannerData.product_type.toLowerCase() === 'SHOW_APP_DOWNLOAD_POPUP_WEB'.toLowerCase())
    },
    bannerPlaceHolderForKidsWebCategory: function () {
      return this.bannerPlcaeHolderData && this.bannerPlcaeHolderData.length && this.bannerPlcaeHolderData.find(bannerData =>
        bannerData.placeholder_for.toLowerCase() === 'Others'.toLowerCase() && bannerData.status === true &&
        bannerData.product_type.toLowerCase() === 'SHOW_KIDSWEAR_WEBCATEGORY_WEB'.toLowerCase())
    },
    bannerPlaceHolderForGoForAppOnlySale: function () {
      return this.bannerPlcaeHolderData && this.bannerPlcaeHolderData.length && this.bannerPlcaeHolderData.find(bannerData =>
        bannerData.placeholder_for.toLowerCase() === 'Others'.toLowerCase() && bannerData.status === true && bannerData.product_type.toLowerCase() === 'GO_APP_ONLY_SALE_WEB'.toLowerCase())
    }
  },
  watch: {
    value () {
      if (this.value.length > 2) {
        this.trigger = true
      }
    },
    $route () {
      setTimeout(function () {
        $('.navbar-collapse').removeClass('activenav')
        // document.getElementsByClassName('navbar-collapse').classList.remove('activenav')
      }, 300)
      if (this.$route.path === '/autocomplete') {
        this.showHeader = false
      } else {
        this.showHeader = true
      }
      if (this.$route.name !== 'search') {
        this.value = ''
        this.togglesearch = false
      }
      this.togglesearch = false
    }
  }
}
</script>

<style lang="css" scoped>
.showmobile{
  box-shadow: 0px -6px 16px rgba(204, 204, 204, 0.8392156862745098);
}
.dropdown-menu {
    position: inherit;
    top: 0;
    padding: 0;
    border: none;
}
.tss-body-wrapper{
  padding-top: 40px;
}
.flex-column{
  padding-bottom: 5px;
}
.nav-item{
  width: 40%;
  background-color: #f6f6f6;
}
.men.active-tab-class:after{
  width: 45px !important;
}
.active-tab-class:after{
  content: '';
  position: absolute;
  bottom: -2px;
  width: 60px;
  height: 3.5px;
  left: 0;
  right: 0;
  margin: auto;
  background-color: #5d979b;
}
.home-active-tab-class:after{
  content: '';
  position: absolute;
  bottom: -4px;
  height: 4px;
  left: 0;
  right: 0;
  margin: auto;
  background-color: #5d979b;
}

.tab-btn{
  text-transform: uppercase;
  font-size: 16px !important;
}
.extra-menu{
  position: inherit;
}
.text-label{
  background-color: #fff;
    font-size: 11px;
    padding: 6px 13px;
    margin: 0;
}
.mobile-menu-collections-section{
  background-color: #f6f6f6;
}
.submenuright{
  position: absolute;
    left: 40%;
    width: 60%;
    top: 0;
    bottom: 0;
    background-color: #fff;
}
.submenucontainer{
  width: 100%;
  position: inherit;
  background-color: #f6f6f6;
  z-index: 999;
  padding: 0;
}
.navopen{
  position: inherit;
}
.iconWrap{
  height: 100px;
    width: 100%;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
}
.subcatInfo{
  text-align: left;
  padding-left: 8px;
  font-size: 11px;
}
.subCathasTag{
  text-align: left;
  padding-left: 8px;
  font-size: 11px;
}
.lefttext.navopen .newnavsubtitle {
background-color: #e9e9e9;
}
.newnavsubtitle{
  padding: 13px !important;
  font-weight: 400;
}

.lefttext{
  padding-left: 0 !important;
}

@media screen and (max-width: 991px){
  .newnavsubtitle:before {
    display: none;
  }
  .dropdown-toggle[aria-expanded="false"]:before {
    display: none;
  }
  .dropdown-toggle[aria-expanded='true']:before {
    display: none;
  }
  .more[aria-expanded="false"]:before {
    display: block !important;
  }
  .more[aria-expanded='true']:before {
    display: block !important;
  }
.navbar-collapse.activenav {
  left: 0 !important;
}
.navbar-collapse {
  width: 100% !important;
  left: -100% !important;
  overflow-x: hidden;
}
.sublevel2{
  margin-bottom: 0px !important;
}
.navbar-toggleable-md .navbar-nav .dropdown-menu {
  padding: 0;
}
.navbar-collapse.activenav ul.navbar-nav li .nav-link {
  font-weight: 400;
  padding: 13px !important;
  line-height: normal;
}
.extra-menu{
}
}

@media screen and (max-width: 992px){
.navbar-light .navbar-nav .nav-link[data-v-906f9a7c]:hover{
  background-color: #f6f6f6 !important;
  position: inherit;
}
.navbar.fixed-top .navbar-brand::before {
          margin-top: -10px;
          width: 12px !important;
          background-size: 80% auto;
          left: 8px;
    }

    .exclusive .navbar.fixed-top .navbar-brand::before {
       margin-top: -8px;
    width: 12px !important;
    background-size: 80% auto;
    left: 13px;
    }

    .navbar.fixed-top .navbar-brand {
    height: 62px !important;;
    width: 60px !important;;
    bottom: 1px;
    position: absolute !important;
    left:0;
    top: -10px;
  }
  .exclusive .navbar.fixed-top .navbar-brand {
    height: 62px !important;;
    width: 60px !important;;
    bottom: 1px;
    position: absolute !important;;
    left:0;
    top: -10px;
  }

}


.menu-title {
  color: #117a7a;
  padding: 0px 20px;
}

.blinking {
  animation: blinkingText 1s infinite;
}
@keyframes blinkingText {
  20% {
    color: #9e0305;
  }
  49% {
    color: transparent;
  }
  70% {
    color: transparent;
  }
  100% {
    color: #ed2d2f;
  }
}

.nav-item:hover {
  background: #ffffff;
}

.mbnav a {
  display: block;
  color: #282d3f;
  padding: 13px;
  font-size: 15px;
  line-height: 22px;
  background-color: #f6f6f6;
}

.submenucontainer .submenu {
  margin: 0;
}

.submenucontainer .submenu li {
  display: block;
}
.section-border-separator {
  background-color: #f6f6f6;
}



.submenucontainer .submenu li a {
  padding: 3px 0;
  color: #282d3f;
  font-size: 15px;
}

.navopen .sublevel2 {
  width: 100%;
}

.trackmap li.active:after {
}

.goAppOnlySale {
  min-height: 2rem;
}


.sbx-google__input-placeholder {
  background: transparent;
}

.authbtn {
  cursor: pointer;
}

.authbtn {
  display: inline-block;
}

.headerRight > div {
  display: flex;
  justify-content: center;
  align-items: center;
}

.fcapital {
  text-transform: capitalize;
}

.navbar {
  box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.2);
  position: relative;
  z-index: 999;
}
.supima-menu .navbar {
  background-color: #e11b23;
  color: #fff
}
.activewear-menu .navbar {
  background-color: #000000;
  color: #fff;
  border-bottom: 4px solid #e93432
}
.navbar.fixed-top {
  position: fixed;
}

.header-background {
  background-color: #ffff;
  margin: 0px !important;
  height: 60px;
}
.exclusive-header {
  background-color: #282d3f;
}


.navbar.fixed-top .navbar-brand {
  width: 70px;
  height: 45px;
  bottom: 5px;
}
.supima-home-logo {
  left: 30%;
}
.activewear-menu .supima-home-logo {
  left: 37%
}
.supima-home-logo img {
  height: 30px;
}
.activewear-menu .supima-home-logo img {
  height: 24px;
}
.topbar {
  background: #E12D2D;
  padding: 3px 0;
  min-height: 53px
}

.topbar a,
.topbar span {
  color: #fff;
  font-size: 13px;
}

.topbar a:hover {
  color: #fff;
}

.navMenu {
  margin-left: 230px;
}

.navicon .noTdropdown {
  padding: 14px 0 13px 0px !important;
}

.navicon a .dropdown-menu {
  padding: 15px !important;
}

.navicon .dropdown-menu a {
  font-size: 15px !important;
}

.dropdown-menu.right {
  right: 0;
  left: inherit;
}


.left-arrow-style {
  top: 8px;
  width: 19px;
  height: auto;
}

.count {
  top: -1px;
  right: -6px;
  font-size: 10px;
  width: 16px;
  height: 16px;
}
.navbar-collapse {
    position: fixed !important;
}

@media screen and (max-width: 1200px) {
  .sidebar-home-img {
    width: 65px;
  }
  .submenucontainer h5,
  .submenucontainer .defaultColor {
    font-family: inherit;
    color: #282d3f;
    padding: 10px 0px;
    font-size: 15px;
  }

  .submenucontainer .navopen h5 {
    font-family: 'Source Sans Pro', sans-serif;
    font-weight: 600;
  }

  .submenucontainer
    .submenu
    li
    a.router-link-exact-active.router-link-active:not(.headercart) {
    color: #282d3f;
    font-family: 'Source Sans Pro', sans-serif;
    font-weight: 600;
  }

  .navbar-collapse.activenav ul.navbar-nav li {
    border-bottom: none;
  }

  .user-order-section {
    margin-top: 20px;
    border-top: 1px solid #eee;
    padding-top: 20px !important;
    padding-bottom: 20px !important;
    border-bottom: 1px solid #eee;
  }

  .navbar-toggleable-md .navbar-nav .nav-link {
    color: #282d3f;
    padding-right: 0.8rem;
    padding-left: 0.8rem;
    font-size: 14px;
    margin-right: 0px;
  }

  .nav-item.non-exc-mem a,
  .nav-item.exc-mem a {
    color: #e66a51 !important;
    font-family: inherit !important;
  }

  .nav-item.track-my-order a {
    color: #148c8d !important;
  }

  .nav-item.my-account a,
  .nav-item.savetheirsouls a,
  .nav-item.my-orders a,
  .nav-item.faqs a,
  .nav-item.track-my-order a,
  .nav-item.contact-us a,
  .nav-item.tnc a {
    font-family: inherit !important;
  }

  .mobilesearch {
    width: 300px;
    margin-right: 8em;
  }
  .dropdown-toggle[aria-expanded='false']:before {
    top: 5px;
  }
}

.notifylogin {
  position: fixed;
  top: 40px;
  background: #ed2d2f;
  width: 240px;
  padding: 10px;
  z-index: 999;
  right: 0px;
  visibility: hidden;
  opacity: 0;
  transition: all 1s ease-out;
  color: #fff;
  box-shadow: 0 0 3px rgba(0, 0, 0, 0.5);
}

.notifylogin.active {
  visibility: visible;
  opacity: 1;
  top: 70px;
  transition: all 0.5s ease-in;
}

.locked-tag {
  color: #58595b;
  padding: 3px 0;
}
@media screen and (max-width: 992px) {
  .navbar-brand:before {
    top: 28px;
    left: 11px;
    width: 15px;
    height: 16px;
  }
  .dropdown-toggle[aria-expanded='true']:before {
    display: block;
    position: absolute;
    right: 15px;
    font: normal normal normal 14px/1.5 FontAwesome;
    font-size: 20px;
    top: 2px;
    color: #000;
    text-rendering: auto;
    -webkit-font-smoothing: antialiased;
    content: '\f106';
  }

  .router-link-exact-active.router-link-active:not(.headercart) {
    font-family: 'Source Sans Pro', sans-serif !important;
font-weight: 600;
  }



  .navbar-nav {
    padding-bottom: 60px;
  }

  .navbar-collapse {
  }
  .supima-menu .navbar-collapse, .activewear-menu .navbar-collapse {
    top: 0px;
  }

  

  .navbar-collapse.activenav {
    box-shadow: 5px 0 8px rgba(0, 0, 0, 0.2);
  }

  .navbar.fixed-top .navbar-collapse {
    top: 0;
  }

  .navbar {
    height: 42px;
  }

  .navMenu {
    margin-left: 0px;
  }

  .navbar-brand {
    width: 80px;
    margin-left: auto;
    margin-right: auto;
    left: 50%;
    margin-left: -40px;
    top: -32px;
    -webkit-transition: unset;
  }

  .navbar-brand.slidemob {
    display: inline-block;
    position: inherit;
    width: 90px;
    margin-left: 0px;
    left: inherit;
    top: inherit;
    margin-right: auto;
    bottom: 0px;
    background: url('/assets/images/newlogosticky.png') center center no-repeat;
    background-size: 75% !important;
  }

  .user-info {
    display: flex;
    justify-content: flex-start;
    align-items: center;
  }
  .user-info .name-arrow-wrapper {
    color: #282d3f;
  }
  .exclusive-header .user-info .name-arrow-wrapper {
    color:#ffffff;
  }
  .login-register {
    width: 122px;
    height: 31px;
    border-radius: 4px;
    border: solid 1px #148c8d;
    position: relative;
  }

  .login-register p {
    position: absolute;
    height: 18px;
    font-size: 13px;
    font-weight: normal;
    font-stretch: normal;
    font-style: normal;
    line-height: 1.38;
    letter-spacing: normal;
    text-align: center;
    color: #148c8d;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  }

  .user-info-slidemob .arrow:before {
    font: normal normal normal 16px/1 FontAwesome;
    content: '\F105';
    font-weight: bolder;
  }
  .user-info-slidemob .name-arrow-wrapper{
    gap: 0.9rem;
  }

  .user-info-slidemob .exclusive-info p {
    margin: 0px;
    padding: 0px;
    color: #e76a52;
    font-size: 11px;
  }
  .user-info-slidemob .exclusive-info hr {
    background-image: linear-gradient(to right, #e76a52, #282d3f);
    margin: 3px 0px !important;
    height: 1px;
  }

  .navbar.fixed-top .navbar-brand {
    position: static;
    height: auto;
    bottom: 0;
    margin-left: 40%;
  }
  /* wwe */
  .headerRight {
    top: 6px;
  }
  .supima-menu .headerRight a, .activewear-menu .headerRight a {
    color: #fff
  }
  .mobilesearch {
    width: 100%;
  }

  #togglesearch {
    display: inline-block;
    text-decoration: none;
  }
  .navbar-collapse {
    border-right: none;
  }

  .mobilesearch {
    position: absolute;
    width: 100%;
    border-radius: 0;
    top: 40px;
    z-index: 9;
    left: 0;

    transition: all 0.3s ease-in;
  }

  .mobilesearch input:focus {
    outline: none;
  }

  .mobilesearch.active {
    visibility: visible;
    opacity: 1;
    transition: all 0.3s ease-out;
  }

  .mobilesearch.active:before {
    content: '';
    width: 0;
    height: 0;
    border-left: 8px solid transparent;
    border-right: 8px solid transparent;
    border-bottom: 8px solid #58595b;
    position: absolute;
    top: -7px;
    right: 55px;
  }

  .searchinput {
    height: 100%;
    width: 85%;
    border: 0;
  }

  .mobilesearch .searchinput {
    padding: 10px;
  }

  .mbinput {
    width: 100%;
    background: #fff;
    box-shadow: 0px 0 5px #a7a9ac;
    padding: 0.3rem 0.5rem 0.3rem 0.2rem;
  }

  .navbar-toggleable-md .navbar-nav .nav-link {
    margin-left: 0;
  }
  .navbar-toggleable-md .navbar-nav .nav-link[aria-expanded='true'] {
    color: #282d3f !important;
  }
  .supima-menu .menu-hamburger, .activewear-menu .menu-hamburger {
    vertical-align: middle;
  }
  .supima-menu .menu-hamburger img, .activewear-menu .menu-hamburger img {
    height: 27px;
  }
  .navbar-light .navbar-nav .nav-link:hover,
  .dropdown.active,
  .navbar-light .navbar-nav .open > .nav-link,
  .navbar-light .navbar-nav .active > .nav-link,
  .navbar-light .navbar-nav .nav-link.open,
  .navbar-light .navbar-nav .nav-link.active {
    background-color: #ffffff;
    color: #282d3f;
    box-shadow: none;
  }
}

.roseAreRed {
  color: #ff0000 !important;
}

.overlay {
  background-color: #000;
  opacity: 0.7;
  width: 100%;
  z-index: 98;
  height: 100vh;
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  display: none;
}

.overlay.show {
  display: block;
}
 /* Header */

  .exclusive .navbar-brand:not(.slidem):before {
  }

  .exclusive .navbar-brand {
    background: url('./assets/images/membership-logo.png') center center no-repeat;
    background-size: contain;
  }

  .birthday-logo .navbar-brand {
    background: url('https://prod-img.thesouledstore.com/public/theSoul/images/Welcome-100-app.png') center center no-repeat;
    background-size: contain;
  }

  .exclusive .navbar.fixed-top .navbar-brand {
    background: url('./assets/images/membership-logo.png') center center no-repeat;
    background-size: contain;
  }

  .birthday-logo .navbar.fixed-top .navbar-brand {
    background: url('https://prod-img.thesouledstore.com/public/theSoul/images/Welcome-100-app.png') center center no-repeat;
    background-size: contain;
  }

  .exclusive-congrats-msg {
    color: #e76a52;
    font-size: 40px;
    font-weight: bold;
    padding: 100px 0px;
  }
  .exclusive .navbar-brand:before {
    filter: brightness(0%);
    -webkit-filter: brightness(0%);
  }

  .exclusive .navbar.fixed-top .navbar-brand {
    height: 60px;
    width: 52px;
    position: absolute;
    left:0;
    top: -10px;
  }
  .exclusive .navbar.fixed-top .navbar-brand:not(.slidem):before {
    width: 11px;
    background-size: 83% auto;
    height: 24px;
    left: 6px;
    top: 18px;
    margin-top: -8px;
  }
  .exclusive .navbar-brand:not(.slidem):before {
    width: 15px;
    background-size: 83% auto;
    height: 24px;
    left: 12px;
    top: 18px;
  }
  .exclusive .search input#search {
    padding-left: 50px;
  }
  .gender-wrapper {
    padding: 4px 0;
    margin: 5px 0;
  }
  .gender-wrapper .tab-btn{
  background: transparent;
  border: unset;
  font-size: 0.9rem;
  height: 90%;
  width: 96%;
  border-radius: 0.5rem;
  color: #2c2d37;
}
.home-gender-wrapper {
    padding: 4px 0;
    left: 0;
    right: 0;
  }
  .home-gender-wrapper .tab-btn{
  background: transparent;
  border: unset;
  font-size: 0.9rem;
  height: 90%;
  width: 96%;
  border-radius: 0.5rem;
  appearance: none;
}
.fixed-top home-gender-wrapper {
  margin: 5px 0 !important;
}

.tab-btn:active{
  outline: none
}
.tab-btn:focus{
  outline: none
}
.active-tab-class{
  position: relative;
  background-color: #fff !important;
  font-weight: 600;
}



/* Hide scrollbar for Chrome, Safari and Opera */
#navbarNavDropdown::-webkit-scrollbar {
    display: none;
}
/* Hide scrollbar for IE, Edge and Firefox */
#navbarNavDropdown {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}
.seperatorGender {
  border-top: 0.3rem #eee solid;
}


.fontTypeBold {
  font-weight: 600 !important;
}
.fontTypeRegular {
  font-weight: normal !important;
}
.fontType-Semibold {
  -webkit-text-stroke: 0.35px #ffffff;
  -webkit-font-smoothing: antialiased;
}
@media screen and (max-width: 768px) {
 .count {
   top: -2px;
   right: 1px;
 }
}
@media screen and (max-width: 415px) {
  .submenucontainer h5,
  .submenucontainer .defaultColor {
    font-family: inherit;
    color: #282d3f;
    padding: 5px 0px;
    font-size: 13px;
  }
  .submenucontainer .submenu li a {
    font-size: 13px;
  }
  .mbnav a {
    font-size: 13px;
  }
}
@media screen and (max-width: 320px) {
  
}
</style>
