import axios from 'axios'
import store from '../store'
import router from '../router'
import Vue from 'vue'

const axiosObj = axios.create({
  baseURL: process.env.APP_URL, // 'http://localhost:8000/api/v2/',
  headers: {
    'Content-Type': 'application/json'
  },
  withCredentials: process.env.ENABLE_COOKIES
})
axiosObj.interceptors.request.use((config) => {
  const countryId = store.state.selectedCountryAddress.countryId
  const countryIsoCode = store.state.selectedCountryAddress.isoCode
  if (countryIsoCode !== 'IND') {
    config.baseURL = process.env.APP_URL_GLOBAL
    config.headers['CountryId'] = countryId
  }
  store.dispatch('LOADING', true)
  return config
})
axiosObj.interceptors.response.use((response) => {
  store.dispatch('LOADING', false)
  return response
}, function (error) {
  store.dispatch('LOADING', false)
  return Promise.reject(error.response)
})

function errorResponseHandler (error) {
    // check for errorHandle config
  if (error.status === 401 && error.request.responseURL !== process.env.APP_URL + 'email-tfa') {
    store.dispatch('LOGOUT', error).then(response => {
      Vue.toasted.clear()
      Vue.toasted.show(error.data.title, {
        theme: 'primary',
        className: 'toasted-customred',
        position: 'top-right',
        duration: 5000
      })
      store.dispatch('CART_DATA')
      store.dispatch('WISHLIST_DATA')
      store.commit('SET_POS_LOGIN_USER', false)
      store.commit('SET_COD_CHECKOUT_LOGIN_USER', false)
      router.push('/login')
    })
    // store.dispatch('SET_LOGINBOX', {flag: true})
  }
  return Promise.reject(error)
}

// apply interceptor on response
axiosObj.interceptors.response.use(
   response => response,
   errorResponseHandler
)

export default axiosObj
