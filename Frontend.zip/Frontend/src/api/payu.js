import axios from 'axios'
import store from '../store'
import Vue from 'vue'

const axiosObj = axios.create({
  baseURL: process.env.PAYU_URL_GLOBAL
})
axiosObj.interceptors.request.use((config) => {
  store.dispatch('LOADING', true)
  return config
})
axiosObj.interceptors.response.use((response) => {
  store.dispatch('LOADING', false)
  return response
}, function (error) {
  store.dispatch('LOADING', false)
  // console.log(JSON.stringify(error))
  Vue.toasted.show(error, {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 5000})
  return Promise.reject(error.response)
})
export default axiosObj
