<template>
  <div>
    <div>
        <span>This is testing data</span>
        <!-- <app-nav-layout v-if="isDesktop"></app-nav-layout> -->
        <!-- <App-nav-new-mobile v-else-if="!isDesktop && bannerPlaceHolderForMenWomenMsite && isComboActive && !bannerPlaceHolderAppLikeSidemenuForMenWomen"></App-nav-new-mobile> -->
        <!-- <App-nav-mobile v-else-if="!isDesktop"></App-nav-mobile> -->
      <!-- <app-footer></app-footer> -->
      <overlay/>
    </div>
  </div>
</template>
<script>
  import './assets/css/bootstrap.css'
  import 'vuejs-dialog/dist/vuejs-dialog.min.css'
  import './assets/css/style.css'
  import '../static/js/bootstrap.min.js'
  import {appMixins} from './assets/js/appMixins'
  import '../static/js/common.js'
  import '../static/js/custome.js'

  export default {
    name: 'app',
    mixins: [appMixins],
    components: {},
    data () {
      return {}
    },
    created: function () {},
    mounted: function () {},
    updated: function () {},
    watch: {},
    computed: {},
    methods: {},
    beforeDestroy () {}
  }
</script>
