<template>
<div class="product-header">
  <div class="d-flex justify-content-between">
    <div class="d-flex align-items-center header-left">
      <div @click="goToPreviousPage">
        <img src="./assets/images/left-icon.svg" alt="Arrow" />
      </div>
      <div class="heading txtTruncate">
        {{productDetailHeader.header}}
      </div>
    </div>
    <div class="d-flex justify-content-end align-items-center header-right">
      <router-link
        :to="'/mywishlist'"
        class="header-icon"
        @click.native="myWishlistVisitEventHandler('default')"
      >
        <img src="./assets/images/wishlist-icon.svg" alt="Wishlist" />
        <div class="header-count" v-if="wishlistCount > 0">{{ wishlistCount }}</div>
      </router-link>
      <router-link :to="'/cart'" class="header-icon">
        <span @click="cartEventHandler">
          <img src="./assets/images/cart-icon.svg" alt="cart" />
          <div class="header-count" v-if="cartcount > 0">{{ cartcount }}</div>
        </span>
      </router-link>
    </div>
  </div>
</div>
</template>
<script>
import { mapGetters } from 'vuex'

export default {
  name: 'app',
  computed: {
    ...mapGetters({
      cartcount: 'cartcount',
      wishlistCount: 'wishlistCount',
      productDetailHeader: 'productDetailHeader'
    })
  },
  methods: {
    goToPreviousPage () {
      window.history.back()
    },
    cartEventHandler () {
      this.$store.commit('GTAG_EVENT', {eventName: 'CART_ICON_CLICK', payload: {}})
    }
  }
}
</script>

<style lang="css" scoped>
@import url('https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap');
.product-header {
  width: 100%;
  padding: 18px 16px 18px 10px;
  height: 60px;
  font-family: 'Lato', sans-serif;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 9;
  background: #fff;
}
.product-header .heading {
  font-size: 16px;
  line-height: 18px;
  font-weight: 700;
  color: #090A0A;
  margin-left: 7px;
}
.header-left {
  flex: 1;
}
.header-right {
  width: 100px;
}
.header-icon {
  position: relative;
  margin-left: 12px;
}
.header-count {
  width: 18px;
  height: 18px;
  background: #ED2D2F;
  color: #fff;
  font-size: 12px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  right: -6px;
  top: -6px;
}

@media screen and (max-width: 479px) {
  .product-header .heading {
    width:220px;
  }
}
</style>
