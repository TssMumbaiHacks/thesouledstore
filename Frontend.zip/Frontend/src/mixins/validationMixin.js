export default {
  methods: {
    validateName (e) {
      const reg = new RegExp("^[a-zA-Z '-]+$")
      const allowedKeys = ['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'Tab', 'Unidentified']
      if (allowedKeys.includes(e.key) || e.ctrlKey || e.metaKey) {
        return
      }
      if (!reg.test(e.key)) {
        e.preventDefault()
      }
    },
    handleInput (event, context, userObject = null) {
      const field = event.target.name
      const value = event.target.value
      const specialCharacters = /[^a-zA-Z\s]/g
      const sanitizedValue = value.replace(specialCharacters, '')
      if (value !== sanitizedValue) {
        if (userObject) {
          context[userObject][field] = sanitizedValue
        } else {
          context[field] = sanitizedValue
        }
        event.target.value = sanitizedValue
      }
    },
    validateAddress (field, value) {
      const specialCharacters = /[^\w\s\-,.&]/g
      const sanitizedValue = value.replace(specialCharacters, '')
      if (value !== sanitizedValue) {
        this[field] = sanitizedValue
      } else {
      }
      return sanitizedValue
    },
    handleNamePaste (e) {
      const pastedData = (e.clipboardData || window.clipboardData).getData('text')
      const reg = /^[a-zA-Z '-]+$/
      const sanitizedData = pastedData.split('').filter(char => reg.test(char)).join('')
      const maxLength = e.target.getAttribute('maxlength') || 16
      const truncatedData = sanitizedData.substring(0, maxLength)
      e.target.value += truncatedData
      const event = new Event('input', { bubbles: true })
      e.target.dispatchEvent(event)
      e.preventDefault()
    },
    handlePostPaste (e, countryId) {
      const pastedData = (e.clipboardData || window.clipboardData).getData('text')
      let reg
      if (countryId && countryId === 222) {
        reg = /^[a-zA-Z0-9 ]$/
      } else {
        reg = /^[0-9]$/
      }
      const sanitizedData = pastedData.split('').filter(char => reg.test(char)).join('')
      const maxLength = e.target.getAttribute('maxlength') || 200
      const truncatedData = sanitizedData.substring(0, maxLength)
      e.target.value = truncatedData
      const event = new Event('input', { bubbles: true })
      e.target.dispatchEvent(event)
      e.preventDefault()
    },
    validatePinCode (e, postcodeLength, countryId) {
      let reg
      if (countryId && countryId === 222) {
        reg = new RegExp('^[a-zA-Z0-9 ]$')
      } else {
        reg = new RegExp('^[0-9]$')
      }
      if ((e.ctrlKey || e.metaKey) && (e.key === 'v' || e.key === 'a' || e.key === 'A' || e.key === 'c' || e.key === 'x')) {
        return
      }
      if ((this.postcode.length > postcodeLength || !reg.test(e.key)) && !(e.key === 'Backspace' || e.key === 'Delete' || e.key === 'ArrowLeft' || e.key === 'ArrowRight')) {
        e.preventDefault()
      }
    }
  }
}
