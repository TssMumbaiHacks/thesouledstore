// src/auth/index.js
// import appLocalStore from '../assets/js/appLocalStore'
// import Vue from 'vue'
// const API_URL = process.env.APP_URL
// URL and endpoint constants
// const LOGIN_URL = API_URL + 'api/v1/authenticate'
// const REGISTER_URL = API_URL + 'api/v1/register'
// const SOCIAL_LOGIN_URL = API_URL + 'api/v1/'
// const LOGOUT_URL = API_URL + 'api/v1/logout'
// const REFRESH_URL = API_URL + 'api/v1/refresh-token'
//  const SIGNUP_URL = API_URL + 'users/'
var $ = require('jquery')
window.jQuery = $

export default {
  // User object will let us check authentication status
  user: {
    authenticated: false,
    isArt: 0,
    loader: false,
    loginBox: false,
    getuserName: '',
    cartCount: 0
  },

  // Send a request to the login URL and save the returned JWT
  login  (context, creds, redirect) {
//    console.log(creds + ' = ' + LOGIN_URL)
//    console.log(context.$route.path)
    // this.user.loader = true
    // context.axios.post(LOGIN_URL, creds, {crossDomain: true, withCredentials: true}).then((response) => {
    //   this.user.loader = false
    //   this.user.loginBox = true
    //   if (response.data.status === 1) {
    //     appLocalStore.setData(response.data.userdata)
    //     appLocalStore.set('userAuth', true)
    //     this.user.authenticated = true
    //     this.user.isArt = response.data.userdata.isArt
    //     this.user.getuserName = appLocalStore.getData('username')
    //     this.user.loginBox = false
    //     this.user.loader = false
    //     $('#notifylogin').addClass('active').append('You have been successfully logged in')
    //     $('.navbar-collapse').removeClass('activenav')
    //     $('.mobilesearch').removeClass('active')
    //     setTimeout(function () {
    //       $('#notifylogin').removeClass('active').empty()
    //     }, 2500)
    //     if (redirect) {
    //       if (redirect !== '/cart') {
    //         context.$router.push(redirect)
    //       } else {
    //         window.location.reload()
    //       }
    //     }
    //   } else {
    //     if (context.$route.path === '/login') {
    //       this.user.loginBox = false
    //     }
    //     this.user.loader = false
    //     context.error = 'Invalid Email or password!'
    //   }
    // }, (response) => {
    //   if (context.$route.path === '/login') {
    //     this.user.loginBox = false
    //   }
    //   this.user.loader = false
    //   context.error = 'Invalid Email or password!'
    //   //  context.error = response
    // })
  },
  socialLogin  (context, res, provider, redirect) {
    // console.log(context + ' = ' + res + ' = ' + provider)
    // this.user.loader = true
    // this.user.loginBox = false
    // context.axios.post(SOCIAL_LOGIN_URL + provider, {'code': res}, {crossDomain: true, withCredentials: true}).then((response) => {
    //   this.user.loader = false
    //   if (response.data.status === 1) {
    //     appLocalStore.setData(response.data.userdata)
    //     appLocalStore.set('userAuth', true)
    //     this.user.authenticated = true
    //     this.user.isArt = response.data.userdata.isArt
    //     this.user.getuserName = appLocalStore.getData('username')
    //     this.user.loginBox = false
    //     $('.navbar-collapse').removeClass('activenav')
    //     $('.mobilesearch').removeClass('active')
    //     $('#notifylogin').addClass('active').html('You have been successfully logged in')
    //     setTimeout(function () {
    //       $('#notifylogin').removeClass('active').empty()
    //     }, 2000)
    //     if (redirect) {
    //       if (redirect !== '/cart') {
    //         context.$router.push(redirect)
    //       } else {
    //         window.location.reload()
    //       }
    //     }
    //   } else {
    //     if (context.$route.path === '/login') {
    //       this.user.loginBox = false
    //     }
    //     context.error = 'Invalid Email or password!'
    //   }
    // }, (response) => {
    //   this.user.loader = false
    //   context.error = 'Invalid Email or password!'
    //   //  context.error = response
    // })
  },
  register  (context, creds, redirect) {
  },

  // To log out, we just need to remove the token
  logout  (context, redirect) {
  },

  checkAuth  () {
    //  console.log('authcheck')
    // var jwt = localStorage.getItem('vue-authenticate.access_token')
    // if (jwt) {
    //   // console.log('loggein')
    //   this.user.authenticated = true
    //   this.user.isArt = appLocalStore.getData('isArt')
    //   this.user.getuserName = appLocalStore.getData('username')
    //   return true
    // } else {
    //   // console.log('NOTloggein')
    //   this.user.authenticated = false
    //   this.user.getuserName = ''
    //   return false
    // }
  },
  refreshAuthToken () {
    //  return Vue.axios.post(REFRESH_URL, {}, {crossDomain: true, withCredentials: true})
    // return new Promise((resolve, reject) => {
    //   return Vue.axios.post(REFRESH_URL, {}, {crossDomain: true, withCredentials: true}).then((response) => {
    //     resolve(response)
    //   }).catch((err) => {
    //     reject(err)
    //   })
    // })
  },
  checkExpiredToken: function (response, request) {
    // console.log(request)
    return new Promise(function (resolve, reject) {
      //  If token is expired, refresh token, resubmit original request & resolve response for original request
      if (response.status === 400 && response.data.error === 'token_expired') {
        this.refreshToken(this, request).then(function (refreshResponse) {
          resolve(refreshResponse)
        })
      }
      //  Otherwise just resolve the current response
      resolve(response)
    }.bind(this))
  },
  refreshToken: function (context, request) {
    // return new Promise(function (resolve, reject) {
    // //  Refresh token
    //   Vue.axios.post(REFRESH_URL, {}, {crossDomain: true, withCredentials: true}).then((response) => {
    //     //  Store refreshed token
    //     if (response.data.status === 'success') {
    //       localStorage.setItem('vue-authenticate.access_token', response.data.token)
    //       //  Resubmit original request and resolve the response (probably shouldn't be the responsibility of the Auth service...)
    //       Vue.axios(request).then(function (newResponse) {
    //         resolve(newResponse)
    //       })
    //     } else {
    //       appLocalStore.unsetData(['vue-authenticate.access_token', 'username', 'userAuth'])
    //       context.$router.push({ name: 'login' })
    //     }
    //   }, (newResponse) => {
    //     reject(newResponse)
    //   })
    // })
  },
  // The object to be passed as a header for authenticated requests
  getAuthHeader  () {
    // return localStorage.getItem('vue-authenticate.access_token')
    // return {
    //   'Authorization': 'Bearer ' + localStorage.getItem('vue-authenticate.access_token')
    // }
  }
}
