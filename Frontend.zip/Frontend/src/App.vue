<template>
  <div id="app">
    <app-nav></app-nav>
    <!-- ***** Header Area End ***** -->
    <!-- <main-banner></main-banner> -->
    <!-- ***** Kids Area Ends ***** -->

    <!-- ***** Social Area Starts ***** -->
    <!-- <section class="section" id="social">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-heading">
                        <h2>Social Media</h2>
                        <span>Details to details is what makes Hexashop different from the other themes.</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row images">
                <div class="col-2">
                    <div class="thumb">
                        <div class="icon">
                            <a href="http://instagram.com">
                                <h6>Fashion</h6>
                                <i class="fa fa-instagram"></i>
                            </a>
                        </div>
                        <img src="../assets/images/instagram-01.jpg" alt="">
                    </div>
                </div>
                <div class="col-2">
                    <div class="thumb">
                        <div class="icon">
                            <a href="http://instagram.com">
                                <h6>New</h6>
                                <i class="fa fa-instagram"></i>
                            </a>
                        </div>
                        <img src="../assets/images/instagram-02.jpg" alt="">
                    </div>
                </div>
                <div class="col-2">
                    <div class="thumb">
                        <div class="icon">
                            <a href="http://instagram.com">
                                <h6>Brand</h6>
                                <i class="fa fa-instagram"></i>
                            </a>
                        </div>
                        <img src="../assets/images/instagram-03.jpg" alt="">
                    </div>
                </div>
                <div class="col-2">
                    <div class="thumb">
                        <div class="icon">
                            <a href="http://instagram.com">
                                <h6>Makeup</h6>
                                <i class="fa fa-instagram"></i>
                            </a>
                        </div>
                        <img src="../assets/images/instagram-04.jpg" alt="">
                    </div>
                </div>
                <div class="col-2">
                    <div class="thumb">
                        <div class="icon">
                            <a href="http://instagram.com">
                                <h6>Leather</h6>
                                <i class="fa fa-instagram"></i>
                            </a>
                        </div>
                        <img src="../assets/images/instagram-05.jpg" alt="">
                    </div>
                </div>
                <div class="col-2">
                    <div class="thumb">
                        <div class="icon">
                            <a href="http://instagram.com">
                                <h6>Bag</h6>
                                <i class="fa fa-instagram"></i>
                            </a>
                        </div>
                        <img src="../assets/images/instagram-06.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- ***** Social Area Ends ***** -->

    <!-- ***** Footer Start ***** -->
    <router-view class="viewContainer"></router-view>
    <footer-app></footer-app>
  </div>
</template>
<script>
  var $ = require('jquery')
  window.jQuery = $
  import './assets/css/bootstrap.min.css'
  import './assets/css/templatemo-hexashop.css'
  import './assets/css/lightbox.css'
  import './assets/css/font-awesome.css'
  import 'vuejs-dialog/dist/vuejs-dialog.min.css'
  import {appMixins} from './assets/js/appMixins'
  import '../static/js/popper.js'
  import '../static/js/bootstrap.min.js'
  import '../static/js/owl-carousel.js'
  import '../static/js/accordions.js'
  import '../static/js/datepicker.js'
  import '../static/js/scrollreveal.min.js'
  import '../static/js/slick.js'
  import '../static/js/lightbox.js'
  import '../static/js/custom.js'
  import AppNav from './components/AppNav.vue'
  import MainBanner from './components/Banner.vue'
  import Search from './components/Search.vue'
  import List from './components/list.vue'
  import FooterApp from './components/footer.vue'
  export default {
    name: 'app',
    mixins: [appMixins],
    components: {AppNav, MainBanner, Search, List, FooterApp},
    data () {
      return {}
    },
    created: function () {},
    mounted: function () {},
    updated: function () {},
    watch: {},
    computed: {},
    methods: {},
    beforeDestroy () {}
  }
</script>
<style>
.toasted-customyellow {
  background-color: #FABC1C !important;
  color: #050404 !important;
  border-radius: 4px !important;
  padding: 8px !important;
  font-size: 15px !important;
  justify-content: center !important;
  width: 100% !important;
  top: -10px !important;
}


.toasted-customred,
.wishlistADD {
  background-color: #ed2d2f !important;
  color: #fff !important;
  border-radius: 4px !important;
  padding: 8px !important;
  font-size: 15px !important;
}
.toasted-customgreen {
  background-color: #4caf50 !important; /* Green for online */
  color: #050404 !important;
  border-radius: 4px !important;
  padding: 8px !important;
  font-size: 15px !important;
  justify-content: center !important;
  width: 100% !important;
  top: -10px !important;
}
.toasted-customblue {
  background-color: #3498db !important;
  color: #fff !important;
  border-radius: 10px !important
}
.toasted-customblack {
  background-color:#0d1f29 !important;
  color: #fff !important;
  border-radius: 8px !important;
  font-weight: bold;
  font-size: 12px;
  padding: 7px 20px !important;
}
.toasted-container.tshirt-customised-toaster {
  top: 50% !important;
}
.toasted-mobileTeal {
  background-color: #148c8d !important;
  color: #fff !important;
  border-radius: 4px !important;
  padding: 8px !important;
  font-size: 15px !important;
}
.toasted-mobileDefault {
  background-color: rgba(104,104,104,0.95) !important;
  color: #fff !important;
  border-radius: 200px !important;
  padding: 8px 10px !important;
  font-size: 15px !important;
}
.toasted-container.bottom-right{
  bottom: 10% !important;
  right: 0 !important;
  text-align: center;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.toasted-container.device-center{
  bottom: 50% !important;
  right: 0 !important;
  text-align: center;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>

