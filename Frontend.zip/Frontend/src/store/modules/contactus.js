import api from '../../api/api'
// import router from '../../router'
import Vue from 'vue'

const order = {
  state: {
    contactUsOptions: [],
    btnLoading: false,
    optionId: false,
    orderId: false
  },
  getters: {
    contactUsOptions: state => state.contactUsOptions,
    btnLoading: state => state.btnLoading,
    getOptionId: state => state.optionId,
    getOrderId: state => state.orderId
  },
  actions: {
    GET_ORDER_STATUS: (state, payload) => {
      let token = Vue.ls.get('tss_token')
      return api.get(`contact-us-order-tracking/${payload.orderId}?page_no=${payload.page_no}&limit=${payload.limit}${payload && payload.status_id ? `&status_id=${payload.status_id}` : ''}${payload && payload.duration ? `&duration=${payload.duration}` : ''}`, {headers: {Authorization: token}}).then((response) => {
        if (response && response.data && Object.keys(response.data).length > 0) {
          return response
        }
        return {}
      }, error => {
        console.log(error)
      })
    },
    CONTACT_US_OPTIONS: (state) => {
      api.get('contact-us-options').then((response) => {
        if (response && response.data && response.data.length) {
          let defaultDisabledOption = {'options_name': 'Please select query', 'id': 0, $isDisabled: true}
          response.data.unshift(defaultDisabledOption)
          state.commit('SET_CONTACT_OPTIONS', response.data)
        }
      }, error => {
        console.log(error)
      })
    },
    SAVE_CONTACT_US_DETAILS: (state, {formData, params}) => {
      state.commit('SET_BTN_LOADING', true)
      let token = Vue.ls.get('tss_token')
      return api.post('contact-us', formData, {headers: {Authorization: token}, params}).then(res => {
        state.commit('UNSET_BTN_LOADING', false)
        let key = res && res.data && res.data.event_id
        state.commit('GTAG_EVENT', {eventName: 'contact_us_pageview', payload: {eventID: key}})
        return res
      }, error => {
        console.log(error)
        state.commit('UNSET_BTN_LOADING', false)
        Vue.toasted.show(error.data.title || error.response.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
        return error
      })
    },
    SAVE_CALLBACK_DETAILS: (state, returnCallbackData) => {
      state.commit('SET_BTN_LOADING', true)
      let token = Vue.ls.get('tss_token')
      return api.post('callback', returnCallbackData, {headers: {Authorization: token}}).then(res => {
        state.commit('UNSET_BTN_LOADING', false)
        return res
      }, error => {
        state.commit('UNSET_BTN_LOADING', false)
        Vue.toasted.show(error.data.title || error.data, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
        return error
      })
    }
  },
  mutations: {
    SET_BTN_LOADING: (state, data) => {
      state.btnLoading = data
    },
    UNSET_BTN_LOADING: (state, data) => {
      state.btnLoading = data
    },
    SET_CONTACT_OPTIONS: (state, data) => {
      state.contactUsOptions = data
    },
    SET_OPTION_ID: (state, data) => {
      state.optionId = data
    },
    SET_ORDER_ID_FORM: (state, data) => {
      state.orderId = data
    }
  }
}

export default order
