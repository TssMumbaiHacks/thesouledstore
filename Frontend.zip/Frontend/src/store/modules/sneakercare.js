import api from '../../api/api'
const sneakercare = {
  actions: {
    GET_SNEAKER_CARE_DETAILS: (state, payload) => {
      return api.get(`${process.env.MOBILE_CMS_URL}care_page?care_page_slug=sneaker_care`).then((response) => {
        console.log('response', response)
        return response
      }, error => {
        console.log(error)
      })
    },
    GET_SNEAKER_DETAILS: (state, payload) => {
      console.log('GET_SNEAKER_DETAILS id', payload)
      return api.get(`${process.env.MOBILE_CMS_URL}care_page_detail?care_page_data_id=${payload.id}`).then((response) => {
        console.log('response', response)
        return response
      }, error => {
        console.log(error)
      })
    }
  }
}

export default sneakercare
