function submitForm (payload) {
  const form = document.createElement('form')
  const baseurl = process.env.PAYU_URL_GLOBAL + '/_payment'
  form.setAttribute('action', baseurl)
  form.setAttribute('method', 'post')
  for (const key in payload) {
    if (payload.hasOwnProperty(key)) {
      const input = document.createElement('input')
      input.setAttribute('type', 'hidden')
      input.setAttribute('name', key)
      input.setAttribute('value', payload[key])
      form.appendChild(input)
    }
  }
  document.body.appendChild(form)
  form.submit()
}

const payu = {
  actions: {
    GLOBAL_CARD_TXN: ({state, getters}, payload) => {
      const geyPayudata = payload.payu
      submitForm(geyPayudata)
    },
    GLOBAL_NB_TXN: ({commit}, payload) => {
      const geyPayudata = payload.payu
      submitForm(geyPayudata)
    },
    GLOBAL_WALLET_TXN: ({commit}, payload) => {
      const geyPayudata = payload.payu
      submitForm(geyPayudata)
    },
    GLOBAL_UPI_TXN: ({commit}, payload) => {
      const geyPayudata = payload.payu
      submitForm(geyPayudata)
    }
  }
}

export default payu
