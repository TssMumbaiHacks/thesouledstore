import api from '../../api/api'
import axios from 'axios'
import router from '../../router'
import Vue from 'vue'

const user = {
  state: {
    user: {},
    orders: [],
    reverse_orders: {},
    hasProducts: {},
    passwordModel: false,
    exclusive_expiry: '',
    earlyAccessForm: {
      submitted: false
    },
    genderDOBModal: false,
    orderTrackingData: {},
    sendOtpProfileDetails: '',
    timezones: [],
    showLogoutModal: false,
    confirmedLogout: false
  },
  getters: {
    user: state => state.user,
    orders: state => state.orders,
    reverse_orders: state => state.reverse_orders,
    hasProducts: state => state.hasProducts,
    exclusive_expiry: state => state.exclusive_expiry,
    earlyAccessStatus: state => state.earlyAccessForm,
    genderDOBModal: state => state.genderDOBModal,
    orderTrackingData: state => state.orderTrackingData,
    sendOtpProfileDetails: state => state.sendOtpProfileDetails,
    timezoneData: state => state.timezones,
    showLogoutModal: state => state.showLogoutModal,
    confirmedLogout: state => state.confirmedLogout
  },
  actions: {
    CHANGE_PASSWORD: (state, userData) => {
      Vue.toasted.clear()
      return new Promise((resolve, reject) => {
        let token = Vue.ls.get('tss_token')
        api.post('changepassword', userData, {headers: {Authorization: token}}).then((response) => {
          Vue.toasted.show('Password changed successfully', {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
          resolve(response)
        }, error => {
          Vue.toasted.show(error.data.title, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
          reject(error)
        })
      })
    },
    HAS_PRODUCTS: (state, orderId) => {
      let token = Vue.ls.get('tss_token')
      return api.get('orderhasproductsnew/' + orderId + '?isNewCancelText=1&isNewTracking=1&is_ab_visible=true', {headers: {Authorization: token}}).then(response => {
        state.commit('HAS_PRODUCTS', {orderId: orderId, product: response.data})
        state.commit('UNSET_LOADING', {rootState: true})
        return response.data
      }, error => {
        state.commit('UNSET_LOADING', {rootState: true})
        console.log(error)
        router.push('/orders')
        return error
      })
    },
    ORDERS: (state, payload) => {
      let token = Vue.ls.get('tss_token')
      return api.get(`ordernew?page=${payload && payload.page || 1}${payload && payload.year ? `&year=${payload.year}` : ''}&is_ab_visible=true`, {headers: {Authorization: token}}).then((response) => {
        state.commit('ORDERS', response.data.order)
        return response.data
      }, error => {
        console.log(error)
        return error
      })
    },
    USER: ({state, commit}) => {
      let token = Vue.ls.get('tss_token')
      let genderDOB = Vue.ls.get('genderDOBModal')
      const getSelectedCountry = Vue.ls.get('selectedCountryAddress')
      const isSelectedCountryIndia = getSelectedCountry ? parseInt(getSelectedCountry.countryId) === 99 : false
      let baseUrl = isSelectedCountryIndia ? process.env.V1_HOST + 'api/v3/' : process.env.APP_URL_GLOBAL
      return api.get(baseUrl + 'profile', {headers: {Authorization: token}, params: {platform: 'web'}}).then((response) => {
        commit('USER', response.data)
        Vue.ls.set('userID', response.data.user_id)
        if (response && response.data && (genderDOB === null) && ((response.data.birthdate === '' || response.data.birthdate === '0000-00-00') ||
          (response.data.gender === '' || !['M', 'F', 'Others'].includes(response.data.gender)))) {
        }
        return response.data
      }, error => {
        commit('UNSET_LOADING', {rootState: true})
        console.log(error)
      })
    },
    OPEN_LOGOUT_MODAL: (state) => {
      state.commit('SET_SHOW_LOGOUT_MODAL', true)
    },
    CLOSE_LOGOUT_MODAL: (state) => {
      state.commit('SET_SHOW_LOGOUT_MODAL', false)
    },
    EXCLUSIVE_EXPIRY: (state) => {
      let token = Vue.ls.get('tss_token')
      return api.get('exclusive', {headers: {Authorization: token}}).then((response) => {
        state.commit('EXCLUSIVE_EXPIRY', response.data)
      }, error => {
        console.log(error)
      })
    },
    USER_SAVE: (state, payload) => {
      Vue.toasted.clear()
      let token = Vue.ls.get('tss_token')
      const getSelectedCountry = Vue.ls.get('selectedCountryAddress')
      const isSelectedCountryIndia = getSelectedCountry ? parseInt(getSelectedCountry.countryId) === 99 : false
      let baseUrl = isSelectedCountryIndia ? process.env.V1_HOST + 'api/v3/' : process.env.APP_URL_GLOBAL
      return api.post(baseUrl + 'profile', payload, {headers: {Authorization: token}}).then((response) => {
        if (response.data) {
          if (response.data.is_otp_sent) {
            state.commit('SET_SEND_OTP_PROFILE_DETAILS', response.data)
          } else {
            const user = response.data
            state.commit('USER', user)
          }
          Vue.toasted.show(response.data.message, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
          return response.data
        }
      }, error => {
        if (error.data) {
          Vue.toasted.show(error.data.title || error.data.message, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
        }
      })
    },
    EARLY_ACCESS: ({commit}, {email, firstName, lastName, phoneNo}) => {
      const body = new FormData()
      if (email) {
        body.set('email', email)
      }
      if (firstName) {
        firstName = firstName[0].toUpperCase() + firstName.slice(1)
        body.set('first_name', firstName)
      }
      if (lastName) {
        lastName = lastName[0].toUpperCase() + lastName.slice(1)
        body.set('last_name', lastName)
      }
      if (phoneNo) {
        body.set('phone_no', phoneNo)
      }
      return api({
        method: 'post',
        url: '/mobile/early_access/user/',
        data: body,
        headers: {'Content-Type': 'multipart/form-data'}
      })
      .then(res => {
        commit('EARLY_ACCESS', true)
        return true
      })
      .catch(() => {
        commit('EARLY_ACCESS', false)
        return false
      })
    },
    RESET_EARLY_ACCESS: ({commit}) => {
      commit('RESET_EARLY_ACCESS')
    },
    CONFIRMED_LOGOUT: (state) => {
      state.commit('SET_CONFIRMED_LOGOUT', true)
    },
    RESET_CONFIRMED_LOGOUT: (state) => {
      state.commit('SET_CONFIRMED_LOGOUT', false)
    },
    GET_ORDER_TRACK_DATA: (state, waybillId) => {
      return axios.get(process.env.CLICKPOST_API_URL + `track-order?waybill=${waybillId}`).then((response) => {
        let currentOrderStatus = null
        let scans = null
        let orderPlacedDate = null
        let courierName = null
        let trackingNo = null
        if (response && response.data) {
          currentOrderStatus = response.data && response.data.result && response.data.result[waybillId] && response.data.result[waybillId].latest_status && response.data.result[waybillId].latest_status.clickpost_status_code || null
          scans = response.data && response.data.result && response.data.result[waybillId] && response.data.result[waybillId].scans || null
          orderPlacedDate = response.data && response.data.result && response.data.result.config && response.data.result.config.order_date || null
          courierName = response.data && response.data.result && response.data.result.cp_name || null
          trackingNo = response.data && response.data.result && response.data.result.waybill || null
        }
        state.commit('SET_ORDER_TRACKING_STATUS', {currentOrderStatus, scans, orderPlacedDate, courierName, trackingNo})
        return response.data
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_TIMEZONE_DATA (state) {
      let token = Vue.ls.get('tss_token')
      return api.get('timezone', {headers: {Authorization: token}}).then((response) => {
        state.commit('TIMEZONE_DATA', response.data)
      }, error => {
        console.log(error)
      })
    },
    POST_TIMEZONE_DATA (state, payload) {
      let token = Vue.ls.get('tss_token')
      api.post('timezone', payload, {headers: {Authorization: token}}).then(response => {}).catch(error => {
        console.log('error=', error)
      })
    }
  },
  mutations: {
    RESET_EARLY_ACCESS: (state, submitted) => {
      state.earlyAccessForm = {
        response: '',
        submitted
      }
    },
    SET_SHOW_LOGOUT_MODAL: (state, payload) => {
      state.showLogoutModal = payload
    },
    SET_CONFIRMED_LOGOUT: (state, payload) => {
      state.confirmedLogout = payload
    },
    EARLY_ACCESS: (state, submitted) => {
      state.earlyAccessForm = {
        response: '',
        submitted
      }
    },
    HAS_PRODUCTS: (state, payloads) => {
      state.hasProducts = {...state.hasProducts, [payloads.orderId]: payloads.product, updatedHasProduct: false}
    },
    UPDATE_HAS_PRODUCTS: (state, payload) => {
      state.hasProducts = { ...state.hasProducts, ...payload }
    },
    ORDERS: (state, orders) => {
      state.orders = orders
    },
    REVERSE_ORDERS: (state, orders) => {
      let revOrder = {}
      for (let item of orders) {
        revOrder[item.order_id] = item
      }
      state.reverse_orders = revOrder
    },
    USER: (state, user) => {
      state.user = user
    },
    EXCLUSIVE_EXPIRY: (state, data) => {
      state.exclusive_expiry = data
    },
    SET_GENDER_DOB_MODAL: (state, data) => {
      state.genderDOBModal = data
    },
    SET_ORDER_TRACKING_STATUS: (state, data) => {
      state.orderTrackingData = data
    },
    SET_SEND_OTP_PROFILE_DETAILS: (state, data) => {
      state.sendOtpProfileDetails = {...data}
    },
    TIMEZONE_DATA (state, payload) {
      state.timezones = payload
    }
  }
}

export default user
