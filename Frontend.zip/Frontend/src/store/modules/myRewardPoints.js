import api from '../../api/api'
import Vue from 'vue'

const myRewardPoints = {
  state: {
    tssMoneypagination: {},
    tssMoneyHistory: [],
    tssPagination: {},
    tssPointsHistory: []
  },
  getters: {
    pagination: state => state.pagination,
    myRewardPoints: state => state.myRewardPoints,
    tssPagination: state => state.tssPagination,
    tssPointsHistory: state => state.tssPointsHistory
  },
  actions: {
    GET_MY_REWARDS_POINTS: ({state, commit}, cPage) => {
      let token = Vue.ls.get('tss_token')
      return api.get(`tss_money_history?page=${cPage}&limit=10`, {headers: {Authorization: token}, params: {platform: 'web'}}).then((response) => {
        commit('GET_MY_REWARDS_POINT', response.data.tss_money_history)
        commit('GET_PAGINATION', response.data.pagination)
        return response.data
      })
      .catch(error => {
        console.log(error)
        commit('GET_MY_REWARDS_POINT', [])
        commit('GET_PAGINATION', {})
      })
    },
    GET_TSS_POINTS_HISTORY: ({state, commit}, cPage) => {
      let token = Vue.ls.get('tss_token')
      return api.get(`tss_point_history?page=${cPage}&limit=10`, {headers: {Authorization: token}, params: {platform: 'web'}}).then((response) => {
        commit('GET_MY_TSS_POINTS', response.data.tss_point_history)
        commit('GET_TSS_PAGINATION', response.data.pagination)
        return response.data
      })
      .catch(error => {
        console.log(error)
        commit('GET_MY_TSS_POINTS', [])
        commit('GET_TSS_PAGINATION', {})
      })
    }
  },
  mutations: {
    GET_PAGINATION: (state, payload) => {
      state.tssMoneypagination = payload
    },
    GET_MY_REWARDS_POINT: (state, payload) => {
      state.tssMoneyHistory = payload
    },
    GET_MY_TSS_POINTS: (state, payload) => {
      state.tssPagination = payload
    },
    GET_TSS_PAGINATION: (state, payload) => {
      state.tssPointsHistory = payload
    }
  }
}
export default myRewardPoints
