import Vue from 'vue'
import api from '../../api/api'
import {getBrowser, isDesktop} from '../../assets/js/common'
const storeEvents = {
  state: () => {
    return {
      navigationWidget: ''
    }
  },
  getters: {
    navigationWidget: state => state.navigationWidget
  },
  actions: {
    TRACK_STORE_EVENT: ({state}, payload) => {
      const routeObj = Vue.ls.get('routeObj')
      const eventPayload = {
        ...payload,
        current_screen: routeObj && routeObj.current,
        previous_screen: routeObj && routeObj.previous,
        widget_name: routeObj && ['PLP Page', 'PDP Page', 'Search Page'].includes(routeObj.current) ? state.navigationWidget : '',
        session_id: Vue.ls.get('session_id'),
        user_id: Vue.ls.get('userID'),
        os: getBrowser(),
        platform: isDesktop() ? 'web' : 'mweb',
        app_id: process.env.STORE_EVENT_APP_ID,
        app_key: process.env.STORE_EVENT_APP_KEY
      }
      api.post(process.env.STORE_EVENT + 'store-event', eventPayload, {headers: {'app_id': process.env.STORE_EVENT_APP_ID, 'app_key': process.env.STORE_EVENT_APP_KEY}})
    }
  },
  mutations: {
    SET_NAVIGATION_WIDGET: (state, widget) => {
      state.navigationWidget = widget
    }
  }
}
export default storeEvents
