import api from '../../api/api'
import Vue from 'vue'
// import router from '../../router'

const giftvoucher = {
  state: {
    giftVoucherData: {},
    myVouchers: []
  },
  getters: {
    giftVoucherData: state => state.giftVoucherData,
    myVouchers: state => state.myVouchers
  },
  actions: {
    GET_VOUCHER_DATA (state) {
      let token = Vue.ls.get('tss_token')
      api.get('get-gift-vouchers', {headers: {Authorization: token}}).then((response) => {
        state.commit('GIFT_VOUCHER_DATA', response.data)
      }, error => {
        console.log(error)
      })
    },
    GET_MY_VOUCHERS (state) {
      let token = Vue.ls.get('tss_token')
      api.get('viewgiftvoucher', {headers: {Authorization: token}, params: {platform: 'web'}}).then((response) => {
        state.commit('GET_MY_VOUCHERS', response.data)
      }, error => {
        console.log(error)
      })
    }
  },
  mutations: {
    GIFT_VOUCHER_DATA (state, payload) {
      state.giftVoucherData = payload
    },
    GET_MY_VOUCHERS (state, payload) {
      state.myVouchers = payload
    }
  }
}
export default giftvoucher
