import axios from 'axios'
import api from '../../api/api'
import Vue from 'vue'

const search = {
  // state
  state: {
    autoSuggest: [],
    newArrival: [],
    recentlyViewed: (localStorage.getItem('recentlyViewed') && JSON.parse(localStorage.getItem('recentlyViewed'))) || [],
    unbxdElasticSearchType: {},
    searchProducts: '',
    searchHistoryList: {},
    autoSuggestRecomProduct: {}
  },
  // getters
  getters: {
    autoSuggest: state => state.autoSuggest,
    newArrival: state => state.newArrival,
    recentlyViewed: state => state.recentlyViewed,
    unbxdElasticSearchType: state => state.unbxdElasticSearchType,
    searchProducts: state => state.searchProducts,
    autoSuggestRecomProduct: state => state.autoSuggestRecomProduct
  },
  // actions
  actions: {
    AUTOSUGGEST_PRODUCTS: (state, {payload, unbxdElasticSearchType}) => {
      if (unbxdElasticSearchType && unbxdElasticSearchType.hasOwnProperty('elasticsearch_unbxd')) {
        const token = Vue.ls.get('tss_token')
        if (unbxdElasticSearchType.elasticsearch_unbxd === 0) {
          return axios
            .get(process.env.ELASTIC_SEARCH_URL + 'autosuggest', {
              headers: {Authorization: token, CountryId: payload.countryId},
              params: {
                keyword: payload.keyword,
                is_exclusive: payload.is_exclusive,
                show_upgrade: payload.show_upgrade,
                is_ab_visible: true,
                gender_type: Vue.ls.get('tss_landingCategory') === 'men' ? 1 : Vue.ls.get('tss_landingCategory') === 'women' ? 2 : 1
              }
            })
            .then((response) => {
              state.commit('AUTOSUGGEST_PRODUCTS', response.data)
            })
            .catch((error) => {
              console.log(error)
            })
        } else {
          return axios
            .get(process.env.UNBXD_URL + 'api/v2/autosuggest', {
              params: {
                q: payload.keyword,
                gender_type: Vue.ls.get('tss_landingCategory') === 'men' ? 1 : Vue.ls.get('tss_landingCategory') === 'women' ? 2 : 1
              }
            })
            .then((response) => {
              state.commit('AUTOSUGGEST_PRODUCTS', response.data)
            })
            .catch((error) => {
              console.log(error)
            })
        }
      }
    },
    GET_SEARCH_PRODUCTS: ({commit, dispatch}, {apiMethod, apiUrl, payload, authToken}) => {
      return api[apiMethod](apiUrl, payload, {headers: {Authorization: authToken}}).then((response) => {
        commit('SET_SEARCH_PRODUCTS', response.data)
        dispatch('TRACK_STORE_EVENT', {
          parent_event_name: 'general_event',
          event_name: 'search',
          search: payload && payload.keyword
        })
        return response.data
      }).catch(error => {
        console.log(error)
      })
    },
    GET_USER_VISITED_PRODUCT: (state, payload) => {
      const getSelectedCountry = Vue.ls.get('selectedCountryAddress')
      const countryId = getSelectedCountry ? getSelectedCountry.countryId : process.env.IND_COUNTRY_ID
      let isKids = Vue.ls.get('tss_landingCategory') === 'kids'
      let genderType = Vue.ls.get('tss_landingCategory') === 'men' ? 1 : Vue.ls.get('tss_landingCategory') === 'women' ? 2 : 3
      let additionalQuery = isKids ? `&isKids=${isKids}` : `&gender_type=${genderType || 1}`
      let apiUrl = process.env.WIDGET_URL + `/trending-products/user-visited-widgets?is_ab_visible=true&country_id=${countryId}` + additionalQuery
      if (payload && !payload.authStatus) {
        const productsIdQuery = encodeURIComponent(JSON.stringify(payload.recentViewProducts))
        apiUrl += `&products_id=${productsIdQuery}`
      }
      let token = Vue.ls.get('tss_token', apiUrl)
      return api.get(apiUrl, {headers: {Authorization: token}}).then((response) => {
        if (response && response.data) {
          return response.data
        }
      }, error => {
        console.log(error)
        return Promise.reject(error)
      })
    },
    NEW_ARRIVAL: ({ commit }, payload) => {
      let query = `
        {
          listing(
              page: 1,
              size: 6,
              category: [],
              sort: LATEST,
              gender: ${payload && payload.genderType},
              filters: {
                price: []
              }
              tags: []
              ){
            products{
              id
              product
              avgRating
              ratingCount
              stock
              prodQty
              artist{name}
              category{name}
              price
              splPrice
              exclusivePrice
              images
              jitValue
              product_slug: productSlug
            }
          }
        }
        `
      return api.post(process.env.APP_URL + 'graphql', { 'query': query, 'is_ab_visible': true }).then((response) => {
        commit('NEW_ARRIVAL', response.data.data.listing)
      }).catch((error) => {
        console.log(error)
      })
    },
    RECENTLY_VIEWED: (state, payload) => {
      state.commit('RECENTLY_VIEWED', payload)
    },
    GET_UNBXD_ELASTIC_SEARCH_TYPE: (state) => {
      // may be used in future
      /*
      return axios.get(process.env.APP_URL + 'elasticsearch_unbxd').then((response) => {
        state.commit('SET_UNBXD_ELASTIC_SEARCH_TYPE', response.data)
      }).catch((error) => {
        console.log(error)
      })
      */
      state.commit('SET_UNBXD_ELASTIC_SEARCH_TYPE', {'elasticsearch_unbxd': 0})
    },
    GET_SEARCH_GENDER_TABS_DATA: (state, payload) => {
      return api.get(process.env.MOBILE_CMS_URL + `banner/page-gender-flag`, payload).then(response => {
        if (response && response.data) {
          Vue.ls.set('genderTabsCache', response.data)
          return response.data
        }
      }).catch((error) => {
        console.log(error)
      })
    },
    SET_SEARCH_HISTORY_LIST: (state, payload) => {
      const token = Vue.ls.get('tss_token')
      api.post(process.env.ELASTIC_SEARCH_URL + 'get-user-search-history', payload, {headers: {Authorization: token}}).then(res => {
        Vue.ls.set('searchHistory', res && res.data && res.data && res.data.searchHistory)
      }, error => {
        console.log(error)
      })
    },
    GET_RECOMMENDED_PRODUCT: (state, payload) => {
      const token = Vue.ls.get('tss_token')
      return axios.get(process.env.SERACH_RECOMMENED_API + 'search-drop-down-suggestion',
        {
          params: {
            user_id: 0,
            gender: 1,
            isKids: false,
            is_ab_visible: true
          },
          headers: {
            Authorization: token
          }
        }).then(response => {
          state.commit('SET_AUTO_SUGGEST_RECOMMENDED_PRODUCTS', response.data.response)
        }).catch((error) => {
          console.log(error)
        })
    }
  },
  // mutations
  mutations: {
    AUTOSUGGEST_PRODUCTS: (state, data) => {
      state.autoSuggest = data
    },
    NEW_ARRIVAL: (state, newArrival) => {
      state.newArrival = newArrival
    },
    RECENTLY_VIEWED: (state, recentlyViewed) => {
      if (recentlyViewed.id) {
        state.recentlyViewed = [recentlyViewed].concat(state.recentlyViewed).slice(0, 10)
        var temp = {}
        state.recentlyViewed.map(autosuggestedName => {
          temp[autosuggestedName.id] = autosuggestedName
        })
        state.recentlyViewed = Object.values(temp)
        localStorage.setItem('recentlyViewed', JSON.stringify(state.recentlyViewed))
      }
    },
    SET_UNBXD_ELASTIC_SEARCH_TYPE: (state, data) => {
      state.unbxdElasticSearchType = {...data}
    },
    SET_SEARCH_PRODUCTS: (state, data) => {
      state.searchProducts = {...data}
    },
    SET_SEARCH_HISTORY_LIST: (state, payload) => {
      state.searchHistoryList = payload
      console.log('SET_SEARCH_HISTORY_LIST', payload)
    },
    SET_AUTO_SUGGEST_RECOMMENDED_PRODUCTS: (state, payload) => {
      state.autoSuggestRecomProduct = payload
    }
  }
}
export default search
