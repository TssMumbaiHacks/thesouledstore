import api from '../../api/api'
import Axios from 'axios'
import Vue from 'vue'

function nth (d) {
  var n = ''
  if (d > 3 && d < 21) return 'th'
  switch (d % 10) {
    case 1:
      n = 'st'
      break
    case 2:
      n = 'nd'
      break
    case 3:
      n = 'rd'
      break
    default:
      n = 'th'
      break
  }
  return n
}

const exclusive = {
  state: {
    isNotifyVisible: false,
    notify: '',
    exclusivePricelist: '',
    exclusiveDetails: {},
    exclusiveProductData: [],
    cartUpsellData: [],
    excPopupData: null
  },
  getters: {
    isNotifyVisible: state => state.isNotifyVisible,
    notify: state => state.notify,
    exclusivePricelist: state => state.exclusivePricelist,
    exclusiveDetails: state => state.exclusiveDetails,
    exclusiveProductData: state => state.exclusiveProductData,
    cartUpsellData: state => state.cartUpsellData,
    excPopupData: state => state.excPopupData
  },
  actions: {
    GET_EXCLUSIVE_PRICELIST: ({ commit }) => {
      return api.get(process.env.MOBILE_CMS_URL + 'product/pricecomparison').then((response) => {
        if (response.data && response.data.data && response.data.data.length) {
          commit('SET_EXCLUSIVE_PRICELIST', response.data.data)
        }
      }, error => {
        Vue.toasted.show(error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      })
    },
    SET_NOTIFY_MODAL: (state, flag) => {
      state.commit('SET_NOTIFY_MODAL', flag)
    },
    NOTIFY_ME: (state, payload) => {
      api.post('exclusive-notify', {email: payload.email}).then((response) => {
        state.commit('SET_NOTIFY_MESSAGE', response.data.msg)
      }, error => {
        console.log(error)
      })
    },
    CHECK_EXCLUSIVE_DETAILS: ({commit}, userid) => {
      let token = Vue.ls.get('tss_token')
      api.get(`lifetime-exclusive-savings`, {headers: {Authorization: token}}).then(response => {
        if (response && response.data && response.data.data && Object.keys(response.data.data).length) {
          if (response.data.data.expiry_date && response.data.data.exclusive_since) {
            response.data.data['expiry_date_sup'] = nth(+(response.data.data.expiry_date.split(' ')[0]))
            response.data.data['exclusive_since_sup'] = nth(+(response.data.data.exclusive_since.split(' ')[0]))
            Vue.ls.set('show_upgrade_plan', response.data.data['show_upgrade_plan'])
          }
          commit('SET_EXCLUSIVE_DETAILS', response.data.data)
          commit('UNSET_LOADING', {rootState: false})
        } else {
          commit('UNSET_LOADING', {rootState: false})
        }
      }, error => {
        console.log(error)
        commit('UNSET_LOADING', {rootState: false})
      })
    },
    RESET_EXCLUSIVE_DETAILS: ({commit}) => {
      commit('RESET_EXCLUSIVE_DETAILS', {})
    },
    GET_EXCLUSIVE_PRODUCTS: ({commit}) => {
      api.get(process.env.MOBILE_CMS_URL + 'exclusive-products').then((response) => {
        if (response && response.data) {
          commit('SET_EXCLUSIVE_PRODUCTS', response.data.products)
        }
      }, error => {
        console.log(error)
      })
    },
    GET_CART_UPSELL_DATA: ({commit}, payload) => {
      const token = Vue.ls.get('tss_token')
      api.get(process.env.MOBILE_CMS_URL + 'cart_upsell_data?is_ab_visible= true', { headers: { Authorization: token } }).then((response) => {
        if (response) {
          commit('SET_CART_UPSELL_DATA', response.data)
        }
      }, error => {
        console.log(error)
      })
    },
    GET_EXC_MEM_DATA_FROM_CMS: (state) => {
      const getSelectedCountry = Vue.ls.get('selectedCountryAddress')
      const countryId = getSelectedCountry ? getSelectedCountry.countryId : process.env.IND_COUNTRY_ID
      return Axios.get(process.env.MOBILE_CMS_URL + `exclusiveCart?platform_type=web&country_id=${countryId}`).then((response) => {
        if (response && response.data && Object.keys(response.data).length) {
          state.commit('SET_EXC_POPUP_DATA', response.data)
          return response.data
        }
      }, error => {
        console.log(error)
        return {}
      })
    }
  },
  mutations: {
    SET_NOTIFY_MODAL: (state, flag) => {
      state.isNotifyVisible = flag
    },
    SET_NOTIFY_MESSAGE: (state, msg) => {
      state.notify = msg
    },
    SET_EXCLUSIVE_PRICELIST: (state, data) => {
      state.exclusivePricelist = data
    },
    SET_EXCLUSIVE_DETAILS: (state, excDetails) => {
      state.exclusiveDetails = excDetails
    },
    SET_EXC_POPUP_DATA: (state, data) => {
      state.excPopupData = data
    },
    SET_EXCLUSIVE_PRODUCTS: (state, data) => {
      state.exclusiveProductData = data
    },
    SET_CART_UPSELL_DATA: (state, data) => {
      state.cartUpsellData = data
    },
    RESET_EXCLUSIVE_DETAILS: (state, data) => {
      state.exclusiveDetails = data
    }
  }
}

export default exclusive
