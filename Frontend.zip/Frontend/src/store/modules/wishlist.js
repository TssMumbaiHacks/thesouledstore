import api from '../../api/api'
import Vue from 'vue'
import {isDesktop, getProductUrl} from '@/assets/js/common'

const wishlist = {
  state: {
    wishlist: {},
    wishlistItemsIDs: [],
    wishlistCount: 0
  },
  getters: {
    wishlist: state => state.wishlist,
    wishlistItemsIDs: state => state.wishlistItemsIDs,
    wishlistCount: function (state) {
      return state.wishlist && state.wishlist.products && state.wishlist.products.items && state.wishlist.products.items.length
    }
  },
  actions: {
    UPDATE_WISHLIST: ({state, commit, dispatch, getters}, payload) => {
      Vue.toasted.clear()
      const token = Vue.ls.get('tss_token')
      const localwishlist = Vue.ls.get('localwishlist')
      const hideToaster = payload.hideToaster
      delete payload.hideToaster
      const updatedPayload = {payload, localwishlist, is_ab_visible: true}
      return api.post('wishlist', updatedPayload, {headers: {Authorization: token}, params: {platform: 'web'}}).then((response) => {
        commit('UPDATE_WISHLIST', {data: response.data, payload})
        switch (updatedPayload.payload.operation) {
          case 'add':
            !hideToaster && Vue.toasted.show('Product Added to your Wishlist', { theme: 'primary', className: isDesktop() ? 'wishlistADD' : 'toasted-mobileTeal', position: isDesktop() ? 'top-right' : 'bottom-right', duration: isDesktop() ? 5000 : 2000 })
            const routeObj = Vue.ls.get('routeObj')
            dispatch('TATVIC_EVENT', {eventName: 'gtm.add.to.wishlist',
              payload: {
                product_added_to_cart: updatedPayload.payload,
                coupon_applied: getters.get_coupon_applied,
                coupon_value: (getters.calculations.coupon_discount || 0),
                reward_points: (getters.calculations.used_reward_points || 0),
                pdp_response: routeObj
              }}
            )
            // commit('GTAG_EVENT', {eventName: 'FB_Add_To_wishlist',
            //   payload: {
            //     product: payload,
            //     pdp_response: Vue.ls.get('routeObj')
            //   }}
            // )
            // commit('GTAG_EVENT', {eventName: 'CT_Added_To_Wishlist',
            //   payload: {
            //     product_added_to_cart: updatedPayload,
            //     coupon_applied: getters.get_coupon_applied,
            //     coupon_value: (getters.calculations.coupon_discount || 0),
            //     reward_points: (getters.calculations.used_reward_points || 0),
            //     category: updatedPayload.payload.data.category,
            //     SKU: updatedPayload.payload.data.parent_prod_id,
            //     quantity: updatedPayload.payload.data.quantity,
            //     product_price: updatedPayload.payload.data.price,
            //     CartEMSaving_Value: updatedPayload.payload.data.spl_price,
            //     Cart_Value: updatedPayload && updatedPayload.localwishlist && updatedPayload.localwishlist.products && updatedPayload.localwishlist.products.items,
            //     pdp_response: Vue.ls.get('routeObj')
            //   }}
            // )
            commit('MOENGAGE_EVENT', {
              eventName: 'ADDED_TO_WISHLIST',
              payload: {
                Product_Category: String(payload.data.category),
                Product_Name: String(payload.data.product),
                Product_ID: String(payload.data.parent_prod_id),
                Product_Price: Number(payload.data.spl_price || payload.data.exclusivePrice ? this.isExclusive ? payload.data.exclusivePrice : payload.data.spl_price : payload.data.price),
                Quantity: Number(payload.data.quantity),
                Product_Artist: String(payload.data.prArtist),
                Product_URL: String(getProductUrl(true, payload.data.url_key, payload.data.gender_type)),
                ProductImage_URL: String(process.env.IMG_BASE_URL + process.env.PRODUCT_DETAIL_IMG + (payload.data.images && payload.data.images[0])),
                Source: String(routeObj && routeObj.previous)
              }
            })
            break
          case 'delete':
            !hideToaster && Vue.toasted.show('Product removed from your Wishlist', { theme: 'primary', className: isDesktop() ? 'wishlistADD' : 'toasted-mobileTeal', position: isDesktop() ? 'top-right' : 'bottom-right', duration: isDesktop() ? 5000 : 2000 })
            commit('GTAG_EVENT', {eventName: 'product.remove_from_wishlist',
              payload: {
                product_remove_from_cart: updatedPayload.payload,
                pdp_response: Vue.ls.get('routeObj')
              }}
            )
            dispatch('TATVIC_EVENT', {eventName: 'REMOVE_FROM_WISHLIST',
              payload: {
                PRODUCT_NAME: updatedPayload.payload.data.product || 'NA',
                PARENT_SKU: updatedPayload.payload.data.prod_id || 'NA',
                PRODUCT_CATEGORY: updatedPayload.payload.data.category || 'NA',
                ARTIST_NAME: updatedPayload.payload.data.artist || 'NA',
                PRODUCT_TAG: updatedPayload.payload.data.category || 'NA'
              }}
            )
            break
          default:
            console.log('DEFAULT CASE TRIGGERED')
        }
        return response
      }).catch(error => {
        if (error && error.data) {
          Vue.toasted.show(error.data.title || error.data.message, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
        }
      })
    },
    WISHLIST_DATA: ({commit}, payload) => {
      const token = Vue.ls.get('tss_token')
      const localwishlist = Vue.ls.get('localwishlist')
      let params = {
        platform: 'web'
      }
      if (payload && payload.isReinit) {
        params = {
          ...params,
          re_init: payload.isReinit
        }
      }
      return api.post('wishlist', {
        localwishlist,
        payload: {operation: 'get', type: 'products'},
        is_ab_visible: true
      }, {headers: {'Authorization': token}, params}).then((response) => {
        commit('WISHLIST_DATA', response.data)
        return response.data
      }).catch(error => {
        console.log(error)
      })
    }
  },
  mutations: {
    WISHLIST_DATA: (state, data) => {
      Vue.ls.set('localwishlist', data)
      state.wishlist = data
      const wishlistIds = {}
      data && data.products && data.products.items && data.products.items.forEach(item => {
        wishlistIds[item.parent_prod_id] = true
      })
      state.wishlistItemsIDs = {...wishlistIds}
    },
    UPDATE_WISHLIST: (state, {data, payload}) => {
      Vue.ls.set('localwishlist', data)
      state.wishlist = data
      if (state.wishlistItemsIDs && payload.data && payload.data.parent_prod_id) {
        let wishlistIds = {...state.wishlistItemsIDs}
        if (wishlistIds[payload.data.parent_prod_id]) {
          wishlistIds = {
            ...wishlistIds,
            [payload.data.parent_prod_id]: false
          }
        } else {
          wishlistIds = {
            ...wishlistIds,
            [payload.data.parent_prod_id]: true
          }
        }
        state.wishlistItemsIDs = {...wishlistIds}
      }
    }
  }
}

export default wishlist
