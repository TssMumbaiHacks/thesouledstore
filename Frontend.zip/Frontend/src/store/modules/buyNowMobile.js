import api from '../../api/api'
import Vue from 'vue'
import * as cTimer from './../../assets/js/stickyPopup.js'

function getMeta (cart, attr) {
  let metaObj = {}
  let meta = cart && cart.meta
  if (meta && (meta.index[attr] || meta.index[attr] === 0)) {
    metaObj = meta.items[meta.index[attr]]
  }
  return metaObj
}
const buyNowCart = {
  state: {
    _cart: {},
    totalSavings: 0,
    giftVoucher: '',
    orderAddress: '',
    address: {
      id: '',
      user_id: '',
      firstname: '',
      lastname: '',
      address1: '',
      address2: '',
      address3: '',
      postcode: '',
      city: '',
      zone_id: '',
      country_id: '',
      phone_no: ''
    },
    validcoupons: [],
    couponError: '',
    togPlaceOrderStatus: false,
    payMethods: [],
    cards: [],
    upis: [],
    wallets: [],
    netbanking: [],
    icon_nb: [],
    processedOrder: {},
    disableCOD: 0,
    isBuyNowPopup: false,
    order: 0,
    isBuyNowCheckout: false,
    cardToken: null,
    isCouponLoading: '',
    isVoucherLoading: false,
    voucherPinAuth: {},
    orderPurchaseReason: [],
    isSouledStoreAccount: false
  },
  getters: {
    isBuyNowCheckout: state => state.isBuyNowCheckout,
    buyNowOrderAddress: state => state.orderAddress,
    buyNowCalculations: function (state) {
      return getMeta(state._cart, 'calculations')
    },
    buyNowAddress: state => state.address,
    _buyNowCart: state => state._cart,
    buyNow_site_config: function (state) {
      return getMeta(state._cart, 'site_config')
    },
    buyNow_exclusiveProduct: function (state) {
      let val = getMeta(state._cart, 'exclusive_user').cart
      return val
    },
    buyNow_isExclusive: function (state) {
      if (getMeta(state._cart, 'exclusive_user')) {
        let val = getMeta(state._cart, 'exclusive_user').active
        return val
      } else return 0
    },
    buyNow_cartcount: function (state) {
      let cart = state._cart
      let keys = ['products', 'giftvouchers', 'complementary_products']
      let count = 0
      for (let key of keys) {
        if (!cart[key]) {
          continue
        }
        let items = cart[key].items
        for (let item of items) {
          if (key !== 'complementary_products') {
            count += (item['quantity'] || 1)
          } else if (item['is_valid']) {
            count++
          }
        }
      }
      return count
    },
    buyNow_coupon: function (state) {
      return getMeta(state._cart, 'coupon')
    },
    buyNow_validcoupons: state => state.validcoupons,
    buyNow_couponError: state => state.couponError,
    buyNow_gift_voucher: function (state) {
      return getMeta(state._cart, 'gift_voucher')
    },
    buyNow_cartvouchers: function (state) {
      if (state._cart && state._cart.giftvouchers) {
        return state._cart.giftvouchers.items
      }
      return []
    },
    buyNow_cart_address: function (state) {
      return getMeta(state._cart, 'address')
    },
    buyNow_togPlaceOrderStatus: state => state.togPlaceOrderStatus,
    buyNow_cod_details: function (state) {
      return getMeta(state._cart, 'cod')
    },
    buyNow_cartwidgets: function (state) {
      if (state._cart && state._cart.widgets) {
        return state._cart.widgets.items
      }
      return []
    },
    buyNow_product_count: function (state) {
      let count = 0
      if (state._cart && state._cart.products) {
        return state._cart.products.items.length
      }
      return count
    },
    buyNow_addedWidgets: function (state) {
      if (state._cart && state._cart.widgets) {
        let checker = {}
        for (let widget of state._cart.widgets.items) {
          checker[widget['id']] = true
        }
        return checker
      }
      return {}
    },
    isBuyNowPopup: state => state.isBuyNowPopup,
    buyNow_cardToken: state => state.cardToken,
    isBuynowCouponLoading: state => state.isCouponLoading,
    isBuynowVoucherLoading: state => state.isVoucherLoading,
    isBuynowVoucherPinAuth: state => state.voucherPinAuth
  },
  actions: {
    BUYNOW_VALIDATE_CHECKOUT: (state) => {
      let token = Vue.ls.get('tss_token')
      Vue.toasted.clear()
      api.post('validatecheckout?is_buy_now_cart=true', {}, {headers: {Authorization: token}}).then((response) => {
        state.commit('SET_BUYNOW_POPUP_VISIBILITY', true)
      }).catch(error => {
        Vue.toasted.show(error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      })
    },
    UPDATE_BUYNOW_CART: ({state, dispatch, commit, getters}, payload) => {
      Vue.toasted.clear()
      return new Promise((resolve, reject) => {
        let token = Vue.ls.get('tss_token')
        const hideToaster = payload.hideToaster
        payload = {payload, is_ab_visible: true}
        api.post('cart', payload, {headers: {Authorization: token}, params: {is_buy_now_cart: true, platform: 'web'}}).then((response) => {
          commit('BUYNOW_CART_DATA', response.data)
          switch (payload.payload.operation) {
            case 'add':
              break
            case 'delete':
              !hideToaster && Vue.toasted.show('Item Removed', { theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 5000 })
              commit('GTAG_EVENT', {eventName: 'product.remove_from_cart.payload', payload: {product_remove_from_cart: payload.payload}})
              commit('GTAG_EVENT', {eventName: 'Remove From Cart',
                payload: {membership_type: getters.getMemberShipType,
                  membership_price: getters.getMemberShipPrice,
                  pdp_response: Vue.ls.get('routeObj')}
              })
              commit('SET_BUYNOW_COUPON_ERROR', '')
              if (payload.payload.data.prod_id === getters.site_config.exclusive_products[2] &&
                getters.site_config.exclusive_products[2].prod_id ||
                payload.payload.data.prod_id === getters.site_config.exclusive_products[1].prod_id ||
                payload.payload.data.prod_id === getters.site_config.exclusive_products[0].prod_id ||
                payload.payload.data.prod_id === getters.site_config.exclusive_products[2].prod_id) {
                // Google Analytics Event
                // commit('GTAG_EVENT', {eventName: 'exclusive.product.removed', payload: {}})
                commit('GTAG_EVENT', {eventName: 'ExclusiveRemovedFromCart', payload: {}})
              }
              break
            case 'set':
              if (payload.payload.name) {
                Vue.toasted.show(payload.payload.name + ' Membership has been added to your cart.', { theme: 'primary', className: 'toasted-customblue', position: 'top-right', duration: 5000 })
              }
              break
            default:
              console.log('DEFAULT CASE TRIGGERED')
          }
          resolve({ animate: true })
          if (payload.payload.type === 'giftvouchers') {
            commit('GTAG_EVENT', {eventName: payload.payload.operation === 'set' ? 'eec.add' : payload.payload.operation === 'delete' ? 'eec.remove' : '',
              payload: {
                ecommerce: {
                  add: {
                    exclusive_user: getters.get_exclusive_user,
                    products: [{
                      id: payload.payload.data.gvamountid,
                      name: 'Gift Voucher ' + payload.payload.data.pay_amt,
                      category: 'Gift Voucher',
                      price: payload.payload.data.pay_amt,
                      quantity: '1'
                    }]
                  }
                }
              }}
            )
          }
          return response
        }, error => {
          Vue.toasted.show(error.data.title, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
          // resolve({animate: false})
        })
      })
    },
    SET_BUYNOW_ORDER_ADDRESS: (state, addressId) => {
      let token = Vue.ls.get('tss_token')
      if (addressId) {
        api.get('setorderaddress/' + addressId + '?is_buy_now_cart=true', {headers: {Authorization: token}}).then((response) => {
          state.commit('SET_BUYNOW_ORDER_ADDRESS', addressId)
          state.dispatch('TRACK_STORE_EVENT', {parent_event_name: 'general_event', event_name: 'set buy now address', address_id: addressId})
        }, error => {
          console.log(error)
        })
      }
    },
    VALIDATE_BUYNOW_COUPON: (state, coupon) => {
      let token = Vue.ls.get('tss_token')
      let localcart = Vue.ls.get('localBuyNowCart')
      Vue.toasted.clear()
      state.commit('SET_BUYNOW_COUPON_LOADING', true)
      api.post('coupon?is_buy_now_cart=true', {coupon: coupon, platform: 'web', localcart}, {headers: {Authorization: token}}).then((response) => {
        // Vue.toasted.show('Coupon applied successfully.', {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 5000})
        state.commit('SET_BUYNOW_COUPON_LOADING', false)
        state.commit('BUYNOW_CART_DATA', response.data)
        state.commit('MODIFY_OFFER_APPEAR_TIMER', cTimer.TIMER.OFFER_APPEAR_TIMER)
        state.commit('MODIFY_OFFER_TIMER', cTimer.TIMER.OFFER_COUNTDOWN_TIMER)
        state.commit('SET_BUYNOW_COUPON_ERROR', '')
        // state.commit('SET_COUPON', coupon)
      }, error => {
        state.commit('SET_BUYNOW_COUPON_LOADING', false)
        state.commit('SET_BUYNOW_COUPON_ERROR', error.data.title)
      })
    },
    REMOVE_BUYNOW_COUPON: (state, coupon) => {
      Vue.toasted.clear()
      state.commit('SET_BUYNOW_COUPON_LOADING', true)
      state.dispatch('UPDATE_BUYNOW_CART', {'type': 'meta', 'operation': 'delete', 'data': {'name': 'coupon'}, hideToaster: true}).then(res => {
        state.commit('SET_BUYNOW_COUPON_LOADING', false)
      })
    },
    APPLY_BUYNOW_GIFT_VOUCHER: (state, payload) => {
      let token = Vue.ls.get('tss_token')
      let localcart = Vue.ls.get('localBuyNowCart')
      state.commit('SET_BUYNOW_VOUCHER_LOADING', true)
      api.post('giftvoucher?is_buy_now_cart=true', {
        ...payload,
        localcart
      }, {headers: {Authorization: token}}).then((response) => {
        state.commit('BUYNOW_CART_DATA', response.data)
        state.commit('SET_BUYNOW_GIFT_VOUCHER', payload.voucher_code)
        state.commit('SET_BUYNOW_VOUCHER_LOADING', false)
      }, error => {
        if (error && error.data && error.data.is_pin_required) {
          state.commit('BUYNOW_SET_GV_PIN_AUTH', error.data)
          Vue.toasted.show(error.data.title, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
        } else {
          state.commit('SET_BUYNOW_VOUCHER_LOADING', false)
          state.dispatch('TATVIC_EVENT', {eventName: 'DISCOUNT_CODE_APPLY',
            payload: {
              VOUCHER_TYPE: 'Gift Voucher',
              STATUS: 'Failure'
            }}
          )
          Vue.toasted.show(error.data.title, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
        }
      })
    },
    REMOVE_BUYNOW_GIFT_VOUCHER: (state) => {
      state.commit('SET_BUYNOW_VOUCHER_LOADING', true)
      state.dispatch('UPDATE_BUYNOW_CART', {operation: 'delete', type: 'meta', data: {'name': 'gift_voucher'}}).then(() => {
        state.commit('SET_BUYNOW_VOUCHER_LOADING', false)
      }).catch(() => {
        state.commit('SET_BUYNOW_VOUCHER_LOADING', false)
      })
    },
    BUYNOW_APPLY_WALLET: ({state, dispatch, commit}, payload) => {
      let token = Vue.ls.get('tss_token')
      let localcart = Vue.ls.get('localBuyNowCart')
      payload.localcart = localcart
      Vue.toasted.clear()
      return api.post('wallet?is_buy_now_cart=true', payload, {headers: {Authorization: token}}).then((response) => {
        commit('BUYNOW_CART_DATA', response.data)
        commit('SET_BUYNOW_REWARD_POINT_FLAG', payload.state)
        dispatch('USER')
        return response
      }, error => {
        Vue.toasted.show(error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
        return error
      })
    },
    PROCESS_ORDER_BUYNOW: ({state, commit, rootState}, _cart) => {
      let token = Vue.ls.get('tss_token')
      Vue.toasted.clear()
      _cart.products.items.forEach(item => { item.is_app = 'desktop' })
      api.post('processorder', _cart, {headers: {Authorization: token}, params: {is_buy_now_cart: true, platform: 'web'}}).then(response => {
        let meta = response.data.meta
        let cod = meta.items[meta.index['cod']]
        let total = meta.items[meta.index['calculations']].total
        if (total > 0 && total <= 4000 && cod.message) {
          Vue.toasted.show(cod.message, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
        }
        commit('SET_PURCHASE_REASON', response.data && response.data.order_purchase_reason)
        commit('SET_IS_SOULED_STORE_ACCOUNT', response.data && response.data.is_souled_store_account)
        commit('PROCESS_ORDER_BUYNOW', response.data)
        commit('BUYNOW_CART_DATA', response.data, {root: true})
      }, error => {
        console.log(error)
        Vue.toasted.show(error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      })
    },
    BUYNOW_PLACE_ORDER: (state, params) => {
      const cartData = params.cartData
      const expiryDetails = params.expiryDetails
      const isGokwik = params.isGokwik
      delete params.isGokwik
      delete params.cartData
      delete params.expiryDetails
      let isBuyNow = true
      let add = params.additional_info
      let cvv = params.card_security_code
      let cardPayType = params.card_pay_type
      let token = Vue.ls.get('tss_token')
      Vue.toasted.clear()
      state.commit('SET_BUYNOW_PLACE_ORDER_STATUS', true)
      state.commit('BUYNOW_SET_CARD_TOKEN', params.additional_info)
      api.post('order', params, {headers: {Authorization: token}, params: {is_buy_now_cart: true, platform: 'web'}}).then(response => {
        if (response.data.isValid) {
          let bingData = cartData && cartData.meta.items.filter((itm) => {
            return itm.name === 'calculations'
          })
          if (bingData && bingData.length > 0) {
            window && window.uetq && window.uetq.push('event', '', {
              'revenue_value': bingData[0].total,
              'currency': 'INR'
            })
          }
          state.commit('BUYNOW_PAYMENT_METHOD_SELECTED', params)
          state.commit('SET_ORDER_ID', response.data.order)
          state.dispatch('PROCESS_PAYMENT', {order: response.data, add: add, cardPayType: cardPayType, cvv: cvv, isBuyNow: isBuyNow, isGokwik})
          state.commit('GTAG_EVENT', {eventName: 'FB_Payment',
            payload: {
              all_cart_product_data: state.getters._cart.products.items,
              price: (state.getters.calculations.total || 0) + (state.getters.calculations.used_reward_points || 0) + (state.getters.calculations.used_tss_points || 0) + (state.getters.calculations.gift_voucher_value || 0),
              payment_method: params.payment_method
            }}
          )
          state.commit('GTAG_EVENT', {eventName: 'eec.checkout_3',
            payload: {
              exclusive_user: state.getters.get_exclusive_user,
              payment_method: params.payment_method,
              ecommerce: {
                checkout: {
                  actionField: {
                    step: 4,
                    option: response.data.order
                  },
                  products: state.getters.cartContent_for_eec
                }
              }
            }}
          )
          if (cartData && cartData.products && cartData.products.items.find(item => item.prod_id === '147501' || item.prod_id === '161509' || item.prod_id === '152694')) {
            state.commit('GTAG_EVENT', {eventName: 'Exclusive_Renewed', payload: {data: {...cartData.products.items.find(item => item.prod_id === '147501' || item.prod_id === '161509' || item.prod_id === '152694'), expiryDetails}}})
          }
        } else {
          state.commit('GTAG_EVENT', {eventName: 'Transaction_Incomplete', payload: {}})
          state.commit('SET_BUYNOW_PLACE_ORDER_STATUS', false)
          Vue.toasted.show(response.data.message, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
        }
      }, error => {
        console.log(error)
        state.commit('SET_BUYNOW_PLACE_ORDER_STATUS', false)
        state.commit('GTAG_EVENT', {eventName: 'Transaction_Incomplete', payload: {}})
        Vue.toasted.show(error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 3000
        })
      })
    },
    BUYNOW_CART_DATA: ({commit, dispatch}) => {
      return new Promise((resolve, reject) => {
        let token = Vue.ls.get('tss_token')
        let localcart = Vue.ls.get('localBuyNowCart')
        // save old active_pricelists
        // commit('OLD_ACTIVE_PRICELISTS', localcart)
        api.post('cart', {
          localcart,
          payload: {operation: 'get'},
          is_ab_visible: true
        }, {headers: {Authorization: token}, params: {is_buy_now_cart: true, platform: 'web'}}).then((response) => {
          resolve(response.data)
          commit('BUYNOW_CART_DATA', response.data)
          return response.data
        }, error => {
          console.log(error)
          return error
        })
      })
    },
    BUYNOW_VALID_COUPONS: (state) => {
      let token = Vue.ls.get('tss_token')
      let localcart = Vue.ls.get('localcart')
      Vue.toasted.clear()
      api.post('validcoupons?is_buy_now_cart=true', {localcart, platform: 'web'}, {headers: {Authorization: token}}).then((response) => {
        state.commit('BUYNOW_VALID_COUPONS', response.data)
      }, error => {
        Vue.toasted.show(error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 3000
        })
      })
    }
  },
  mutations: {
    BUYNOW_CART_DATA: (state, cart) => {
      Vue.ls.set('localBuyNowCart', cart)
      state._cart = cart
      // FIXME: add to a getter
      let totalSavings = 0
      state.totalSavings = parseInt(totalSavings)
      state.totalSavings = 0
      state.coupon = cart.coupon
      state.giftVoucher = cart.giftvoucher
      state.isGiftVoucher = cart.isGiftVoucher
    },
    SET_BUYNOW_ORDER_ADDRESS: (state, address) => {
      state.orderAddress = address
    },
    SET_BUYNOW_COUPON_ERROR: (state, data) => {
      state.couponError = data
    },
    SET_BUYNOW_GIFT_VOUCHER: (state, voucher) => {
      state.giftVoucher = voucher
    },
    SET_BUYNOW_PLACE_ORDER_STATUS: (state, data) => {
      state.togPlaceOrderStatus = data
    },
    SET_BUYNOW_REWARD_POINT_FLAG: (state, flag) => {
      state.rewardPoints = flag
    },
    PROCESS_ORDER_BUYNOW: (state, order) => {
      state.processedOrder = order
      state.disableCOD = order.is_cod
    },
    BUYNOW_SET_CARD_TOKEN: (state, cardToken) => {
      state.cardToken = cardToken
    },
    BUYNOW_PAYMENT_METHOD_SELECTED: (state, payload) => {
      state.user_selected_payment_method = payload.payment_method
    },
    SET_BUYNOW_POPUP_VISIBILITY: (state, flag) => {
      state.isBuyNowPopup = flag
    },
    IS_BUYNOW_CHECKOUT: (state, flag) => {
      state.isBuyNowCheckout = flag
    },
    BUYNOW_VALID_COUPONS: (state, data) => {
      state.validcoupons = data
    },
    SET_BUYNOW_COUPON_LOADING: (state, payload) => {
      state.isCouponLoading = payload
    },
    SET_BUYNOW_VOUCHER_LOADING: (state, payload) => {
      state.isVoucherLoading = payload
    },
    BUYNOW_SET_GV_PIN_AUTH: (state, payload) => {
      state.voucherPinAuth = payload
    },
    SET_PURCHASE_REASON: (state, data) => {
      state.orderPurchaseReason = data
    },
    SET_IS_SOULED_STORE_ACCOUNT: (state, data) => {
      state.isSouledStoreAccount = data
    }
  }

}

export default buyNowCart

