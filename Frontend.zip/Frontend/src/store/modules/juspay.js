import api from '../../api/juspay'
// import api1 from '../../api/payment'
import router from '../../router'
import Vue from 'vue'

function xwwwfurlenc (srcjson) {
  if (typeof srcjson !== 'object') {
    if (typeof console !== 'undefined') {
      return null
    }
  }
  let u = encodeURIComponent
  var urljson = ''
  var keys = Object.keys(srcjson)
  for (var i = 0; i < keys.length; i++) {
    urljson += u(keys[i]) + '=' + u(srcjson[keys[i]])
    if (i < (keys.length - 1)) urljson += '&'
  }
  return urljson
}

const juspay = {
  state: {
    token: process.env.JUSPAY_TOKEN,
    cardToken: '',
    transaction: '',
    upiIntentDetail: { show_qr: false, value: {}, process_mweb_intent: false }
  },
  getters: {
    // add getters heres
    cardToken: state => state.cardToken,
    upiIntentDetail: function (state) {
      return state.upiIntentDetail
    }
  },
  actions: {
    CREATE_TOKEN: (state, card) => {
      return api.post('card/tokenize', card, {headers: {'Content-Type': 'multipart/form-data'}}).then((response) => {
        // Vue.toasted.show('Card token created.' + response.data.token, {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 3000})
        state.commit('CARD_TOKEN', response.data.token)
        return response.data.token
      }, error => {
        console.log(error)
        // Vue.toasted.show(error, {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 3000})
        router.push({name: 'cart'})
        state.commit('GTAG_EVENT', {eventName: 'Transaction_Failure', payload: {}})
      })
    },
    CARD_TXN: ({state, getters}, payload) => {
      Vue.toasted.clear()
      let order = payload.order
      let cardPayType = payload.cardPayType
      const y = new FormData()
      y.set('order_id', order)
      y.set('payment_method_type', 'dcc')
      if (cardPayType === 'sc') {
        y.set('card_security_code', payload.cvv)
        y.set('tokenize', getters.cardTokeniseSupport)
      } else {
        y.set('save_to_locker', getters.cardTokeniseSupport)
      }
      payload.isBuyNow ? y.set('card_token', getters.buyNow_cardToken) : y.set('card_token', getters.cardToken)
      y.set('redirect_after_payment', 'true')
      y.set('format', 'json')
      y.set('merchant_id', process.env.JUSPAY_MERCHANT)
      api.post('txns', y, {headers: {'Content-Type': 'multipart/form-data'}}).then((response) => {
        if (response.data.payment.authentication.method === 'GET') {
          window.location = response.data.payment.authentication.url
        }
        // Vue.toasted.show('Card token created.' + response.data.token, {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 3000})
        // state.commit('CARD_TOKEN', response.data.token)
      }, error => {
        console.log(error)
        Vue.toasted.show('Please enter valid card details', {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 3000
        })
        router.push({name: 'cart'})
        state.commit('GTAG_EVENT', {eventName: 'Transaction_Failure', payload: {}})
      })
    },
    NB_TXN: (state, payload) => {
      Vue.toasted.clear()
      let order = payload.order
      let add = payload.add
      const y = new FormData()
      y.set('order_id', order)
      y.set('payment_method_type', 'NB')
      y.set('payment_method', add)
      y.set('redirect_after_payment', 'true')
      y.set('format', 'json')
      y.set('merchant_id', process.env.JUSPAY_MERCHANT)
      api.post('txns', y, {headers: {'Content-Type': 'multipart/form-data'}}).then((response) => {
        if (response.data.payment.authentication.method === 'GET') {
          window.location = response.data.payment.authentication.url
        } else {
          const x = new FormData()
          x.append('action', response.payment.authentication.url)
          for (var key in response.payment.authentication.params) {
            x.set(key, response.payment.authentication.params[key])
          }
          x.submit()
        }
      }, error => {
        console.log(error)
        Vue.toasted.show(error.data.error_message, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 6000
        })
        router.push({name: 'cart'})
        state.commit('GTAG_EVENT', {eventName: 'Transaction_Failure', payload: {}})
      })
    },
    WALLET_TXN: ({commit, dispatch}, payload) => {
      Vue.toasted.clear()
      let order = payload.order
      let add = payload.add
      const phNo = Vue.ls.get('tss_cred_phn')
      let x = {'order_id': order, 'payment_method_type': 'WALLET', 'payment_method': add, 'redirect_after_payment': 'true', 'format': 'json', 'merchant_id': process.env.JUSPAY_MERCHANT}
      if (add === 'CRED') {
        let sdkParams = {
          platform: 'web',
          os: Vue.ls.get('tss_cred_os'),
          device: Vue.ls.get('tss_cred_device'),
          countryCode: '+91',
          credAppPresent: false
        }
        phNo && phNo.length ? Object.assign(sdkParams, {phoneNumber: phNo}) : ''
        Object.assign(x, {'sdk_pg_params': JSON.stringify(sdkParams), 'sdk_params': true})
      }
      // const y = new FormData()
      // y.set('order_id', order)
      // y.set('payment_method_type', 'WALLET')
      // y.set('payment_method', add)
      // y.set('redirect_after_payment', 'true')
      // y.set('format', 'json')
      // y.set('merchant_id', process.env.JUSPAY_MERCHANT)
      api.post('txns', xwwwfurlenc(x), {headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}}).then((response) => {
        if (response.data.payment.authentication.method === 'GET') {
          window.location = response.data.payment.authentication.url
        } else {
          const x = new FormData()
          x.append('action', response.data.payment.authentication.url)
          for (var key in response.data.payment.authentication.params) {
            x.set(key, response.data.payment.authentication.params[key])
          }
          x.submit()
        }
      }, error => {
        console.log(error)
        Vue.toasted.show(error.data.error_message, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 6000
        })
        router.push({name: 'cart'})
        commit('GTAG_EVENT', {eventName: 'Transaction_Failure', payload: {}})
      })
    },
    UPI_TXN: ({commit}, payload) => {
      Vue.toasted.clear()
      let x = {}
      switch (payload.add.payment_value) {
        case 'GOOGLEPAY':
          x = {'merchant_id': process.env.JUSPAY_MERCHANT, 'order_id': payload.order, 'payment_method_type': 'WALLET', 'format': 'json', 'payment_method': payload.add.payment_value, 'mobile_number': payload.add.value, 'txn_type': 'PUSH_PAY', 'redirect_after_payment': 'true'}
          break
        case 'PAYTMUPI':
          x = {'merchant_id': process.env.JUSPAY_MERCHANT, 'order_id': payload.order, 'payment_method_type': 'UPI', 'format': 'json', 'payment_method': 'UPI', 'upi_vpa': payload.add.value, 'txn_type': 'UPI_COLLECT', 'redirect_after_payment': 'true'}
          break
        case 'INTENTUPIFLOW':
          x = {'merchant_id': process.env.JUSPAY_MERCHANT, 'order_id': payload.order, 'payment_method_type': 'UPI', 'payment_method': 'UPI', 'txn_type': 'UPI_PAY', 'format': 'json', 'redirect_after_payment': true, 'sdk_params': true}
          break
      }
      api.post('txns', xwwwfurlenc(x), {headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}}).then((response) => {
        if (payload.add.payment_value === 'INTENTUPIFLOW') {
          if (response && response.data && response.data.payment) {
            response.data.process_mweb_intent = false
            if (payload.orderDevice === 'android') {
              response.data.process_mweb_intent = true
            } else {
              response.data.show_qr = true
            }
            commit('UPI_INTENT_QR_DATA', response.data)
          }
        } else if (response.data.payment.authentication.method === 'GET') {
          window.location = response.data.payment.authentication.url
        } else {
          const x = new FormData()
          x.append('action', response.data.payment.authentication.url)
          for (var key in response.data.payment.authentication.params) {
            x.set(key, response.data.payment.authentication.params[key])
          }
          x.submit()
        }
      }, error => {
        console.log(error)
        Vue.toasted.show(error.data.error_message, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 6000
        })
        router.push({name: 'cart'})
        commit('GTAG_EVENT', {eventName: 'Transaction_Failure', payload: {}})
      })
      // api.post('txns', JSON.stringify(y), {headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}}).then((response) => {
      //   console.log(response)
      //   if (response.data.payment.authentication.method === 'GET') {
      //     window.location = response.data.payment.authentication.url
      //   } else {
      //     const x = new FormData()
      //     x.append('action', response.data.payment.authentication.url)
      //     for (var key in response.data.payment.authentication.params) {
      //       x.set(key, response.data.payment.authentication.params[key])
      //     }
      //     x.submit()
      //   }
      // }, error => {
      //   console.log(error)
      //   Vue.toasted.show(error.data.error_message, {
      //     theme: 'primary',
      //     className: 'toasted-customred',
      //     position: 'top-right',
      //     duration: 6000
      //   })
      //   router.push({name: 'cart'})
      // })
    },
    TWID_PAY_TXN: ({commit}, payload) => {
      let order = payload.order
      let add = payload.add
      let x = {'order_id': order, 'payment_method_type': 'REWARD', 'payment_method': add, 'redirect_after_payment': 'true', 'format': 'json', 'merchant_id': process.env.JUSPAY_MERCHANT}
      api.post('txns', xwwwfurlenc(x), {headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}}).then((response) => {
        if (response.data && response.data.payment && response.data.payment.authentication && response.data.payment.authentication.method && response.data.payment.authentication.url && response.data.payment.authentication.method === 'GET') {
          window.location = response.data.payment.authentication.url
        } else if (response.data && response.data.payment && response.data.payment.authentication && response.data.payment.authentication.params) {
          const x = new FormData()
          x.append('action', response.data.payment.authentication.url)
          for (var key in response.data.payment.authentication.params) {
            x.set(key, response.data.payment.authentication.params[key])
            x.submit()
          }
        }
      }, error => {
        Vue.toasted.show(error.data.error_message, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 6000
        })
        router.push({name: 'cart'})
        // commit('GTAG_EVENT', {eventName: 'Transaction_Failure', payload: {}})
      })
    },
    SNAPMINT_PAY_TXN: ({commit}, payload) => {
      let order = payload.order
      let x = {'order_id': order, 'payment_method_type': 'CONSUMER_FINANCE', 'payment_method': 'SNAPMINT', 'redirect_after_payment': 'true', 'format': 'json', 'merchant_id': 'thesouledstore'}
      api.post('txns', xwwwfurlenc(x), {headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}}).then((response) => {
        if (response.data && response.data.payment && response.data.payment.authentication && response.data.payment.authentication.method && response.data.payment.authentication.url && response.data.payment.authentication.method === 'GET') {
          window.location = response.data.payment.authentication.url
        } else if (response.data && response.data.payment && response.data.payment.authentication && response.data.payment.authentication.params) {
          const x = new FormData()
          x.append('action', response.data.payment.authentication.url)
          for (var key in response.data.payment.authentication.params) {
            x.set(key, response.data.payment.authentication.params[key])
            x.submit()
          }
        }
      }, error => {
        Vue.toasted.show(error.data.error_message, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 6000
        })
        router.push({name: 'cart'})
      })
    }
  },
  mutations: {
    // mutations goes here
    CARD_TOKEN: (state, token) => {
      state.cardToken = token
    },
    ORDER_TRANSACTION: (state, form) => {
      state.transaction = form
    },
    UPI_INTENT_QR_DATA: (state, payload) => {
      let valueData = {}
      if (payload && payload.payment && payload.payment.sdk_params && payload.payment.sdk_params.tr) {
        if (payload.payment.sdk_params.tr) {
          valueData.tr = payload.payment.sdk_params.tr
        }
        if (payload.payment.sdk_params.tid) {
          valueData.tid = payload.payment.sdk_params.tid
        }
        if (payload.payment.sdk_params.merchant_vpa) {
          valueData.pa = payload.payment.sdk_params.merchant_vpa
        }
        if (payload.payment.sdk_params.merchant_name) {
          valueData.pn = payload.payment.sdk_params.merchant_name
        }
        if (payload.payment.sdk_params.amount) {
          valueData.am = payload.payment.sdk_params.amount
        }
        valueData.cu = 'INR'
        valueData.tn = 'UPI Intent'
        if (payload.payment.sdk_params.mcc) {
          valueData.mc = payload.payment.sdk_params.mcc
        }
        valueData = xwwwfurlenc(valueData)
      }
      if (payload && payload.process_mweb_intent) {
        state.upiIntentDetail = { show_qr: payload.show_qr, value: valueData, process_mweb_intent: payload.process_mweb_intent }
        window.location.href = `upi://pay?${valueData}`
      } else {
        state.upiIntentDetail = { show_qr: payload.show_qr, value: valueData, process_mweb_intent: payload.process_mweb_intent }
      }
    }
  }
}

export default juspay
