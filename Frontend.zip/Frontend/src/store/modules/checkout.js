import api from '../../api/api'
import router from '../../router'
import Vue from 'vue'
import {isDesktop, getCookie} from '@/assets/js/common'

const checkout = {
  state: {
    addresses: [],
    address: {
      id: '',
      user_id: '',
      firstname: '',
      lastname: '',
      address1: '',
      address2: '',
      address3: '',
      postcode: '',
      city: '',
      zone_id: '',
      country_id: '',
      phone_no: ''
    },
    countries: [],
    countryId: 99,
    defaultAddress: '',
    payMethods: [],
    processedOrder: {},
    zones: [],
    order: 0,
    orderAddress: '',
    cardToken: null,
    disableCOD: 0,
    wallets: [],
    netbanking: [],
    icon_nb: [],
    upis: [],
    user_selected_payment_method: '',
    togPlaceOrderStatus: false,
    areaServiceableData: {},
    payMethodsOutage: [],
    country_detail_data: [],
    orderPurchaseReason: [],
    isSouledStoreAccount: false,
    cartCleared: true
  },
  getters: {
    address: state => state.address,
    addresses: state => state.addresses,
    countries: state => state.countries,
    country_detail_data: state => state.country_detail_data,
    countryId: state => state.countryId,
    defaultAddress: state => state.defaultAddress,
    payMethods: state => state.payMethods,
    processedOrder: state => state.processedOrder,
    zones: state => state.zones,
    order: state => state.order,
    cardToken: state => state.cardToken,
    orderAddress: state => state.orderAddress,
    disableCOD: state => state.disableCOD,
    wallets: state => state.wallets,
    netbanking: state => state.netbanking,
    icon_nb: state => state.icon_nb,
    upis: state => state.upis,
    user_selected_payment_method: state => state.user_selected_payment_method,
    togPlaceOrderStatus: state => state.togPlaceOrderStatus,
    areaServiceableData: state => state.areaServiceableData,
    payMethodsOutage: state => state.payMethodsOutage,
    getPurchaseReason: state => state.orderPurchaseReason,
    getIsSouledStore: state => state.isSouledStoreAccount,
    cartCleared: state => state.cartCleared
  },
  actions: {
    ADDRESS: (state, address) => {
      const getSelectedCountry = Vue.ls.get('selectedCountryAddress')
      return new Promise((resolve, reject) => {
        let token = Vue.ls.get('tss_token')
        api.post(`address?country_id=${getSelectedCountry.countryId}`, address, {headers: {Authorization: token}, params: {platform: 'web'}}).then(response => {
          // Vue.toasted.show('Address saved successfully.', {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 5000})
          state.commit('GET_ADDRESSES', response.data)
        // #TODO Removed as per tatvic recommendation
        // state.commit('GTAG_EVENT', {eventName: 'Address_Added', payload: {}})
          state.dispatch('TATVIC_EVENT', {eventName: 'ADD_ADDRESS', payload: {}})
          state.commit('GTAG_EVENT', {eventName: 'select_address', payload: {}})
          resolve(response.data)
        }, error => {
          reject(error)
        })
      })
    },
    COUNTRY_DETAIL: (state) => {
      const getSelectedCountry = Vue.ls.get('selectedCountryAddress')
      api.get(`countries?country_id=${getSelectedCountry.countryId}`).then((response) => {
        const filterdCountry = response.data.filter((item) => parseInt(item.id) === parseInt(getSelectedCountry.countryId))
        state.commit('COUNTRY_DETAIL_DATA', filterdCountry)
      }, error => {
        console.log(error)
      })
    },
    COUNTRIES: (state) => {
      api.get('countries').then((response) => {
        state.commit('COUNTRIES', response.data)
      }, error => {
        console.log(error)
      })
    },
    DELETE_ADDRESS: (state, addressId) => {
      return new Promise((resolve, reject) => {
        let token = Vue.ls.get('tss_token')
        const getSelectedCountry = Vue.ls.get('selectedCountryAddress')
        api.post('address?address_id=' + addressId + `&country_id=${getSelectedCountry.countryId}`, {action: 'delete'}, {headers: {Authorization: token}, params: {platform: 'web'}}).then((response) => {
          // Vue.toasted.show('Address deleted successfully.', {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 5000})
          state.commit('GET_ADDRESSES', response.data)
          if (!isDesktop()) {
            Vue.toasted.show('Address deleted successfully.', {
              theme: 'primary',
              className: 'toasted-mobileDefault',
              position: 'bottom-right',
              duration: 2000
            })
          }
          resolve(response.data)
        }, error => {
          console.log(error)
          resolve({addresses: false})
        })
      })
    },
    GET_ADDRESSES: (state) => {
      const getSelectedCountry = Vue.ls.get('selectedCountryAddress')
      return new Promise((resolve, reject) => {
        let token = Vue.ls.get('tss_token')
        api.get(`address?country_id=${getSelectedCountry.countryId}`, {headers: {Authorization: token}, params: {platform: 'web'}}).then((response) => {
          state.commit('GET_ADDRESSES', response.data)
          resolve(response.data)
        }, error => {
          console.log(error)
          resolve({addresses: false})
        })
      })
    },
    GET_ADDRESS: (state, addressId) => {
      let token = Vue.ls.get('tss_token')
      return new Promise((resolve, reject) => {
        api.get('address/' + addressId, {headers: {Authorization: token}}).then(response => {
          state.commit('GET_ADDRESS', response.data)
          resolve(response)
        }, error => {
          reject(error)
        })
      })
    },
    GET_PAYMETHODS: (state) => {
      api.get('paymethods?platform=web').then((response) => {
        state.commit('GET_PAYMETHODS', response.data)
      }, error => {
        console.log(error)
      })
    },
    PLACE_ORDER: (state, params) => {
      const cartData = params.cartData
      const expiryDetails = params.expiryDetails
      const isGokwik = params.isGokwik
      let orderDevice = null
      if (params && params.orderDevice) {
        orderDevice = params.orderDevice
        delete params.orderDevice
      }
      delete params.isGokwik
      delete params.cartData
      delete params.expiryDetails
      let isBuyNow = false
      let add = params.additional_info
      let cvv = params.card_security_code
      let cardPayType = params.card_pay_type
      let token = Vue.ls.get('tss_token')
      let isPosLogin = Vue.ls.get('pos_login')
      let isCodCheckoutLogin = Vue.ls.get('cod_checkout_login')
      params['is_pos_order'] = isPosLogin
      params['is_abandon_cart_order'] = isCodCheckoutLogin
      params['is_ab_visible'] = true
      params['fbp'] = getCookie('_fbp')
      params['external_id'] = state.getters.user.user_id
      if (isPosLogin) {
        params['pos_store_id'] = Vue.ls.get('pos_store_id')
        params['pos_user_id'] = Vue.ls.get('pos_user_id')
      }
      Vue.toasted.clear()
      state.commit('SET_PLACE_ORDER_STATUS', true)
      state.commit('SET_CARD_TOKEN', params.additional_info)
      api.post('order', params, {headers: {Authorization: token}, params: {platform: 'web'}}).then(response => {
        if (response.data.isValid) {
          let bingData = cartData && cartData.meta.items.filter((itm) => {
            return itm.name === 'calculations'
          })
          if (bingData && bingData.length > 0) {
            window && window.uetq && window.uetq.push('event', '', {
              'revenue_value': bingData[0].total,
              'currency': 'INR'
            })
          }
          state.commit('PAYMENT_METHOD_SELECTED', params)
          state.commit('SET_ORDER_ID', response.data.order)
          state.dispatch('PROCESS_PAYMENT', {order: response.data, add: add, cardPayType: cardPayType, cvv: cvv, isBuyNow: isBuyNow, isGokwik, orderDevice, payment_method: params.payment_method})
          state.commit('GTAG_EVENT', {eventName: 'FB_Payment',
            payload: {
              all_cart_product_data: state.getters._cart.products.items,
              price: (state.getters.calculations.total || 0) + (state.getters.calculations.used_reward_points || 0) + (state.getters.calculations.used_tss_points || 0) + (state.getters.calculations.gift_voucher_value || 0),
              payment_method: params.payment_method
            }}
          )
          state.commit('GTAG_EVENT', {eventName: 'eec.checkout_3',
            payload: {
              exclusive_user: state.getters.get_exclusive_user,
              payment_method: params.payment_method,
              ecommerce: {
                checkout: {
                  actionField: {
                    step: 4,
                    option: response.data.order
                  },
                  products: state.getters.cartContent_for_eec
                }
              }
            }}
          )
          if (cartData && cartData.products && cartData.products.items.find(item => item.prod_id === '147501' || item.prod_id === '161509' || item.prod_id === '152694')) {
            state.commit('GTAG_EVENT', {eventName: 'Exclusive_Renewed', payload: {data: {...cartData.products.items.find(item => item.prod_id === '147501' || item.prod_id === '161509' || item.prod_id === '152694'), expiryDetails}}})
          }
        } else {
          state.commit('GTAG_EVENT', {eventName: 'Transaction_Incomplete', payload: {}})
          state.commit('SET_PLACE_ORDER_STATUS', false)
          Vue.toasted.show(response.data.message, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
        }
      }, error => {
        Vue.toasted.show(error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 3000
        })
        state.commit('SET_PLACE_ORDER_STATUS', false)
        this.$store.commit('GTAG_EVENT', {eventName: 'Transaction_Incomplete', payload: {}})
      })
    },
    CLEAR_CART: async (state) => {
      await state.dispatch('UPDATE_CART', {operation: 'clear'})
      state.commit('SET_CLEAR_CART_BOOL', true)
    },
    CHECK_AREA_SERVICEABLE: ({state, commit}, pincode) => {
      return api.get(`delivery-estimate/${pincode}`).then(response => {
        commit('SET_AREA_SERVICEABLE_DATA', response.data && response.data.data)
        return response.data
      }, error => {
        Vue.toasted.show(error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      })
    },
    PROCESS_ORDER: ({state, commit, rootState, getters}, _cart) => {
      let token = Vue.ls.get('tss_token')
      Vue.toasted.clear()
      _cart.products.items.forEach(item => { item.is_app = 'desktop' })
      return api.post('processorder', _cart, {headers: {Authorization: token}, params: {platform: 'web'}}).then(response => {
        let meta = response.data.meta
        let cod = meta.items[meta.index['cod']]
        let total = meta.items[meta.index['calculations']].total
        if (total > 0 && total > 4000 && cod && cod.message && cod.message.includes('location') && !cod.valid) {
          Vue.toasted.show(cod.message, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
        }
        const getSelectedCountry = Vue.ls.get('selectedCountryAddress')
        const isSelectedCountryIndia = getSelectedCountry ? parseInt(getSelectedCountry.countryId) === 99 : false
        if (total > 0 && total <= 4000 && cod.message && isSelectedCountryIndia) {
          Vue.toasted.show(cod.message, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
        }
        commit('SET_PURCHASE_REASON', response.data && response.data.order_purchase_reason)
        commit('SET_IS_SOULED_STORE_ACCOUNT', response.data && response.data.is_souled_store_account)
        commit('PROCESS_ORDER', response.data)
        commit('CART_DATA', response.data, {root: true})
        // commit('UNSET_LOADING', {rootState: true})
        // router.push({name: 'cart'})
        // commit('GTAG_EVENT', {eventName: 'eec.checkout_2',
        //   payload: {
        //     ecommerce: {
        //       checkout: {
        //         actionField: {
        //           step: 3
        //         },
        //         exclusive_user: getters.get_exclusive_user,
        //         products: getters.cartContent_for_eec
        //       }
        //     }
        //   }}
        // )
        return response.data
      }, error => {
        console.log(error)
        commit('UNSET_LOADING', {rootState: true})
        Vue.toasted.show(error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
        router.push({name: 'cart'})
      })
    },
    SET_DEFAULT_ADDRESS: (state, address) => {
      state.commit('SET_DEFAULT_ADDRESS', address)
    },
    UPDATE_ADDRESS: (state, address) => {
      const getSelectedCountry = Vue.ls.get('selectedCountryAddress')
      return new Promise((resolve, reject) => {
        let token = Vue.ls.get('tss_token')
        api.post(`address?country_id=${getSelectedCountry.countryId}`, address, {headers: {Authorization: token}, params: {platform: 'web'}}).then((response) => {
          state.commit('GET_ADDRESSES', response.data)
          state.commit('GTAG_EVENT', {eventName: 'Address_Edited', payload: {}})
          state.commit('GTAG_EVENT', {eventName: 'Edited Address', payload: {}})
          resolve(response)
        }, error => {
          reject(error)
        })
      })
    },
    SET_ORDER_ADDRESS: (state, addressId) => {
      let token = Vue.ls.get('tss_token')
      // let cartItems = Vue.ls.get('localcart')
      return api.get('setorderaddress/' + addressId, {headers: {Authorization: token}}).then((response) => {
        state.commit('SET_ORDER_ADDRESS', addressId)
        state.commit('GTAG_EVENT', {eventName: 'Address_Selected', payload: {address: addressId}})
        state.commit('GTAG_EVENT', {eventName: 'Address Selected',
          payload: { Selected_Gift_Wrap: state.getters.calculations.gift_wrap_amount,
            Used_Tss_Money: state.getters.calculations.used_tss_money,
            Used_Tss_Points: state.getters.calculations.used_tss_money,
            Coupon_amount: state.getters.calculations.coupon_discount,
            Coupon_Name: null
          }}
        )
        state.dispatch('TRACK_STORE_EVENT', {parent_event_name: 'general_event', event_name: 'set address', address_id: addressId})
        return true
      }, error => {
        console.log(error)
      })
    },
    ZONES: (state, countryId) => {
      api.get('zones/' + countryId).then((response) => {
        state.commit('ZONES', response.data)
      }, error => {
        console.log(error)
      })
    },
    GET_CRED_ELIGIBILITY: (state, payload) => {
      let token = Vue.ls.get('tss_token')
      return api.post(process.env.APP_URL + 'payment/eligibility/cred', payload, {headers: {Authorization: token}}).then(response => {
        // const data = (response && response.data) || {}
        return response.data
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_PAYMETHODS_OUTAGE: (state) => {
      let token = Vue.ls.get('tss_token')
      api.get('payment/payment-methods?add_outage=true', {headers: {Authorization: token}}).then((res) => {
        state.commit('SET_PAYMETHODS_OUTAGE', res.data && res.data.object && res.data.object.outage)
      }, error => {
        console.log(error)
      })
    }
  },
  mutations: {
    COUNTRIES: (state, countries) => {
      state.countries = countries
    },
    COUNTRY_DETAIL_DATA: (state, countries) => {
      state.country_detail_data = countries
    },
    GET_ADDRESSES: (state, address) => {
      state.addresses = address
    },
    CLEAR_ADDRESSES: (state, address) => {
      state.addresses = []
    },
    GET_ADDRESS: (state, address) => {
      state.address = address
    },
    GET_PAYMETHODS: (state, paymethods) => {
      state.wallets = paymethods.filter(item => item.payment_type === 'WALLET')
      state.upis = paymethods.filter(item => item.payment_type === 'UPI')
      state.netbanking = paymethods.filter(item => item.payment_type === 'NETBANKING' || item.payment_type === 'ICON_NB')
      state.icon_nb = paymethods.filter(item => item.payment_type === 'ICON_NB')
      state.payMethods = paymethods
    },
    PROCESS_ORDER: (state, order) => {
      state.processedOrder = order
      state.disableCOD = order.is_cod
    },
    SET_DEFAULT_ADDRESS: (state, address) => {
      state.defaultAddress = address
    },
    SET_PROCESSING_ORDER: (state, order) => {
      state.processedOrder = order
    },
    SET_ORDER_ADDRESS: (state, address) => {
      state.orderAddress = address
    },
    ZONES: (state, zones) => {
      state.zones = zones
    },
    PAYMENT_METHOD_SELECTED: (state, payload) => {
      state.user_selected_payment_method = payload.payment_method
    },
    SET_ORDER_ID: (state, order) => {
      state.order = order
    },
    SET_CARD_TOKEN: (state, cardToken) => {
      state.cardToken = cardToken
    },
    SET_PLACE_ORDER_STATUS: (state, data) => {
      state.togPlaceOrderStatus = data
    },
    SET_AREA_SERVICEABLE_DATA: (state, data) => {
      state.areaServiceableData = data
    },
    SET_PAYMETHODS_OUTAGE: (state, data) => {
      state.payMethodsOutage = data
    },
    SET_PURCHASE_REASON: (state, data) => {
      state.orderPurchaseReason = data
    },
    SET_IS_SOULED_STORE_ACCOUNT: (state, data) => {
      state.isSouledStoreAccount = data
    },
    SET_CLEAR_CART_BOOL: (state, payload) => {
      state.cartCleared = payload
    }
  }
}

export default checkout
