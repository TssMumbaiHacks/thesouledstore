import api from '../../api/payment'
// import api1 from '../../api/payment'
import router from '../../router'
import Vue from 'vue'

const payment = {
  state: {
    payment1: process.env.PAYMENT_MS,
    cards: [],
    eligibility_flag: {},
    eligibility_flag_simpl: {},
    gokwikOrderDetails: {},
    noSavedCardsToDisplay: false,
    cardTokeniseSupport: false,
    upiNumberVerify: {},
    twidInfo: {},
    juspayOrderStatus: {},
    paymentInitiateLoader: false
  },
  getters: {
    // add getters heres
    cards: state => state.cards,
    card_token: state => state.cardToken,
    eligibility_flag: state => state.eligibility_flag,
    eligibility_flag_simpl: state => state.eligibility_flag_simpl,
    gokwikOrderDetails: state => state.gokwikOrderDetails,
    noSavedCardsToDisplay: state => state.noSavedCardsToDisplay,
    cardTokeniseSupport: state => state.cardTokeniseSupport,
    upiNumberVerify: state => state.upiNumberVerify,
    twidInfo: state => state.twidInfo,
    juspayOrderStatus: state => state.juspayOrderStatus,
    paymentInitiateLoader: state => state.paymentInitiateLoader
  },
  actions: {
    STORED_CARDS: (state, card) => {
      let token = Vue.ls.get('tss_token')
      api.get('/cards/all', {headers: {Authorization: token}}).then((response) => {
        if (response.data.status === 200) {
          state.commit('STORED_CARDS', response.data.data.cards)
        }
      }, error => {
        console.log(error)
        // Vue.toasted.show('Error connecting to Juspay' + error, {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 3000})
        // router.push({name: 'checkout'})
      })
    },
    ADD_CARD: (state, card) => {
      let token = Vue.ls.get('tss_token')
      api.post('/cards', card, {headers: {Authorization: token}}).then((response) => {
        // Vue.toasted.show('Card Added.', {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 3000})
      }, error => {
        console.log(error)
        // Vue.toasted.show('Error Saving Card' + error, {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 3000})
        // router.push({name: 'checkout'})
      })
    },
    REMOVE_CARD: (state, cardTkn) => {
      let token = Vue.ls.get('tss_token')
      api.post('/card/delete', cardTkn, {headers: {Authorization: token}}).then((response) => {
        Vue.toasted.show('Card Removed Sucessfully.', {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 3000})
      }, error => {
        console.log(error)
        // Vue.toasted.show('Error Saving Card' + error, {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 3000})
        // router.push({name: 'checkout'})
      })
    },
    ADD_CUSTOMER: (state, customer) => {
      let token = Vue.ls.get('tss_token')
      api.get('/customers', {headers: {Authorization: token}}).then((response) => {
        // Vue.toasted.show('Card Added.', {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 3000})
      }, error => {
        console.log(error)
        // Vue.toasted.show('Error Saving Card' + error, {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 3000})
        // router.push({ name: 'home' })
      })
    },
    CHECK_ELIGIBILITY: (state, amount) => {
      let token = Vue.ls.get('tss_token')
      api.post('/eligibility', amount, {headers: {Authorization: token}}).then((response) => {
        if (response.status === 200) {
          state.commit('SET_ELIGIBILITY', response.data.eligibility)
          state.commit('SET_TWID_DATA', {redeemable_info: response.data.redeemable_info, offers: response.data.offers})
        }
      }, error => {
        console.log(error)
      })
    },
    GET_SIMPL_ELIGIBILITY: (state, payload) => {
      let token = Vue.ls.get('tss_token')
      api.post('/eligibility/simpl', payload, {headers: {Authorization: token}}).then(response => {
        if (response.status === 200) {
          state.commit('SET_ELIGIBILITY_SIMPL', response.data.eligibility)
        }
      }, error => {
        console.log(error)
      })
    },
    PROCESS_PAYMENT: ({ state, commit, dispatch, rootState }, payload) => {
      let order = payload.order
      const paymentMethod = payload.payment_method
      order.is_ab_visible = true
      const isGokwik = payload.isGokwik
      // delete payload.isGokwik
      let token = Vue.ls.get('tss_token')
      if (order.method === 12) {
        order.payment_method = payload.add
      }
      let apiUrl = isGokwik ? process.env.PAYMENT_URL + 'orders' : process.env.PAYMENT_URL + 'orders'
      const getSelectedCountry = Vue.ls.get('selectedCountryAddress')
      const isSelectedCountryGlobal = getSelectedCountry ? parseInt(getSelectedCountry.countryId) !== 99 : false
      if (isSelectedCountryGlobal) {
        if (order.method === 10 && payload.add !== 'PAYUHOSTED') {
          order = { ...order, ...payload.add }
        } else if (order.method === 10) {
          order.payment_method = payload.add
        }
        /** Checking Payment Global Option  */
        let globalApiUrl = process.env.PAYMENT_V2_GLOBAL
        if (order.method === 10 && order.payment_method !== 'PAYUHOSTED') {
          /** PayU Merchant Hosted */
          globalApiUrl = globalApiUrl + 'orders'
        } else if (order.method === 12 && order.payment_method === 'PAYPAL') {
          /** PayPal Payment Option */
          globalApiUrl = globalApiUrl + 'create_paypal_order'
        } else if (order.method === 12 && order.payment_method === 'RAZORPAY') {
          /** Razorpay Payment Option */
          globalApiUrl = globalApiUrl + 'create_razorpay_order'
          commit('SET_PAYMENT_INITIATE_LOADER', true)
        } else {
          /** PayU Hosted Checkout */
          globalApiUrl = globalApiUrl + 'orders-hosted'
        }
        let payloadData = (order.method === 12 && (order.payment_method === 'PAYPAL' || order.payment_method === 'RAZORPAY')) ? { order: order.order } : order
        api.post(globalApiUrl, payloadData, {headers: {Authorization: token}}).then((response) => {
          if (order.method === 12 && order.payment_method === 'PAYPAL') {
            const resData = response.data
            if (resData.links[1].rel === 'payer-action') {
              window.location.href = resData.links[1].href
            }
          } else if (order.method === 12 && order.payment_method === 'RAZORPAY') {
            commit('SET_PAYMENT_INITIATE_LOADER', true)
            let url = process.env.PAYMENT_V2_GLOBAL + `verify_razorpay_payment`
            const resData = response.data
            let options = {
              'key': resData.key,
              'amount': resData.amount,
              'currency': resData.currency,
              'name': resData.name,
              'description': resData.description,
              'image': resData.image,
              'order_id': resData.order_id,
              'handler': function (response) {
                fetch(url, {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json'
                  },
                  body: JSON.stringify({
                    order_id: response.razorpay_order_id,
                    payment_id: response.razorpay_payment_id,
                    signature: response.razorpay_signature
                  })
                }).then(res => {
                  if (!res.ok) {
                    commit('SET_PAYMENT_INITIATE_LOADER', false)
                    payload.isBuyNow ? commit('SET_BUYNOW_PLACE_ORDER_STATUS', false, {rootState: true}) : commit('SET_PLACE_ORDER_STATUS', false, {rootState: true})
                    throw new Error('Verification request failed')
                  }
                  return res.json()
                })
                .then(data => {
                  window.location.href = data.verified && data.redirect_url
                  payload.isBuyNow ? commit('SET_BUYNOW_PLACE_ORDER_STATUS', false, {rootState: true}) : commit('SET_PLACE_ORDER_STATUS', false, {rootState: true})
                })
                .catch(error => {
                  console.error('Verification Error:', error)
                  router.push({name: 'cart'})
                  payload.isBuyNow ? commit('SET_BUYNOW_PLACE_ORDER_STATUS', false, {rootState: true}) : commit('SET_PLACE_ORDER_STATUS', false, {rootState: true})
                  commit('SET_PAYMENT_INITIATE_LOADER', false)
                })
              },
              modal: {
                ondismiss: function () {
                  commit('SET_PAYMENT_INITIATE_LOADER', false)
                  payload.isBuyNow ? commit('SET_BUYNOW_PLACE_ORDER_STATUS', false, {rootState: true}) : commit('SET_PLACE_ORDER_STATUS', false, {rootState: true})
                }
              },
              'prefill': {
                'name': resData.firstname || '',
                'email': resData.email || '',
                'contact': resData.telephone || ''
              },
              'notes': {
                'address': resData.address || ''
              },
              'theme': {
                'color': '#3399cc'
              }
            }
            var rzp1 = new Razorpay(options)
            rzp1.open()
          } else {
            payload.order = order.order
            payload.payu = response.data
            payload.isBuyNow ? commit('SET_BUYNOW_PLACE_ORDER_STATUS', true, {rootState: true}) : commit('SET_PLACE_ORDER_STATUS', true, {rootState: true})
            switch (order.method) {
              case 3:
                router.push('/thank-you')
                break
              case 10:
                dispatch('GLOBAL_CARD_TXN', payload)
                break
              case 11:
                dispatch('GLOBAL_NB_TXN', payload)
                break
              case 12:// 9 is db value
                dispatch('GLOBAL_WALLET_TXN', payload)
                break
              case 13:// UPI
                dispatch('GLOBAL_UPI_TXN', payload)
                break
              default:
                break
            }
          }
        }, error => {
          console.log('Error', error)
          commit('GTAG_EVENT', {eventName: 'Transaction_Incomplete', payload: {}})
          commit('SET_PAYMENT_INITIATE_LOADER', false)
          payload.isBuyNow ? commit('SET_BUYNOW_PLACE_ORDER_STATUS', false, {rootState: true}) : commit('SET_PLACE_ORDER_STATUS', false, {rootState: true})
          // Vue.toasted.show('Error connecting to Juspay' + error, {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 3000})
          router.push({name: 'cart'})
        })
      } else {
        let ua = navigator.userAgent.toLowerCase()
        let isAndroid = ua.indexOf('android') > -1
        let isIphone = ua.indexOf('iphone') > -1
        const isPlacedOrder = (isAndroid && paymentMethod && paymentMethod === 'upi')
        order.platform = 'WEB'
        order.os = isAndroid ? 'android' : isIphone ? 'ios' : 'web'
        api.post(apiUrl, order, {headers: {Authorization: token}}).then((response) => {
          payload.order = order.order
          // payload.isBuyNow ? commit('SET_BUYNOW_PLACE_ORDER_STATUS', true, {rootState: true}) : commit('SET_PLACE_ORDER_STATUS', true, {rootState: true})
          payload.isBuyNow ? commit('SET_BUYNOW_PLACE_ORDER_STATUS', true, {rootState: true}) : commit('SET_PLACE_ORDER_STATUS', !isPlacedOrder, {rootState: true})
          switch (order.method) {
            case 3:
              router.push('/thank-you')
              break
            case 1:
              // if (isGokwik && response.data && response.data.gokwik_data) {
              //   commit('SET_GOKWIK_ORDER_DETAILS', {...response.data.gokwik_data})
              // } else {
              router.push('/thank-you')
              // }
              break
            case 10:
              dispatch('CARD_TXN', payload)
              break
            case 11:
              dispatch('NB_TXN', payload)
              break
            case 12:// 9 is db value
              dispatch('WALLET_TXN', payload)
              break
            case 13:// UPI
              dispatch('UPI_TXN', payload)
              break
            case 14:
              // if (response.data && response.data.gokwik_data) {
              //   commit('SET_GOKWIK_ORDER_DETAILS', {...response.data.gokwik_data})
              // }
              router.push('/thank-you')
              break
            case 17:
              dispatch('TWID_PAY_TXN', payload)
              break
            case 18:
              dispatch('SNAPMINT_PAY_TXN', payload)
              break
            default:
              break
          }
        }, error => {
          console.log('Error', error)
          commit('GTAG_EVENT', {eventName: 'Transaction_Incomplete', payload: {}})
          commit('SET_PAYMENT_INITIATE_LOADER', false)
          payload.isBuyNow ? commit('SET_BUYNOW_PLACE_ORDER_STATUS', false, {rootState: true}) : commit('SET_PLACE_ORDER_STATUS', false, {rootState: true})
          // Vue.toasted.show('Error connecting to Juspay' + error, {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 3000})
          router.push({name: 'cart'})
        })
      }
    },
    GOKWIK_PAYMENT_VERIFY: (state, payload) => {
      let token = Vue.ls.get('tss_token')
      const apiUrl = payload.isGokwik ? process.env.PAYMENT_URL_V3 + 'gokwik-payment-verify' : process.env.PAYMENT_URL + 'ordersgokwik-payment-verify'
      api.post(apiUrl, {gokwik_oid: payload.gokwik_oid}, {headers: {Authorization: token}}).then((response) => {
        if (response.data && response.data.status === 200) {
          router.push('thank-you')
        }
      }, error => {
        // router.push({name: 'cart'})
        Vue.toasted.show('Error in placing the order ' + error.data.message, {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 3000})
      })
    },
    PUSH_PAYMENT_EVENT: (state, payload) => {
      const token = Vue.ls.get('tss_token')
      api.get(process.env.PAYMENT_URL + `push-fb-event/${payload.orderId}`, {headers: {Authorization: token}}).then(response => {
        return response.data
      }).catch(error => {
        console.log('error=', error)
      })
    },
    CHECK_TOKENISE_SUPPORT: (state, card) => {
      const token = Vue.ls.get('tss_token')
      const params = {
        cardbins: card
      }
      return api.get('card/info', {headers: {Authorization: token}, params}).then((response) => {
        if (response && response.data && response.data.data) {
          state.commit('SET_CARD_TOKENISE_SUPPORT', response.data.data.tokenize_support)
        } else {
          state.commit('SET_CARD_TOKENISE_SUPPORT', false)
        }
      }, error => {
        state.commit('SET_CARD_TOKENISE_SUPPORT', false)
        console.log(error)
      })
    },
    UPI_NUMBER_VERIFY: (state, payload) => {
      let token = Vue.ls.get('tss_token')
      const apiUrl = process.env.PAYMENT_URL + 'verify-upi-account'
      return api.post(apiUrl, payload, {headers: {Authorization: token}}).then((response) => {
        if (response.data) {
          return response.data
        }
      }).catch((error) => {
        console.log(error)
        throw error
      })
    },
    CUSTOMER_UPDATE: (state) => {
      let token = Vue.ls.get('tss_token')
      return api.post('customers/update', null, {headers: {Authorization: token}}).then((response) => {
        response ? Vue.ls.set('customer_update', true) : ''
      }).catch((error) => {
        console.log(error)
      })
    },
    CHECK_ORDER_STATUS: (state, payload) => {
      let token = Vue.ls.get('tss_token')
      api.post('chk-jp-order-status', payload, {headers: {Authorization: token}}).then((response) => {
        if (response && response.data) {
          state.commit('SET_JUSPAY_ORDER_STATUS', response.data)
        }
      })
    }
  },
  mutations: {
    // mutations goes here
    STORED_CARDS: (state, cards) => {
      state.cards = cards
      if (cards && cards.length < 1) {
        state.noSavedCardsToDisplay = true
      }
    },
    SET_ELIGIBILITY: (state, flag) => {
      state.eligibility_flag = flag
    },
    SET_ELIGIBILITY_SIMPL: (state, flag) => {
      state.eligibility_flag_simpl = flag
    },
    SET_PAYMENT_INITIATE_LOADER: (state, flag) => {
      state.paymentInitiateLoader = flag
    },
    SET_TWID_DATA: (state, payload) => {
      var points = 0
      var offerMsg = ''
      if (payload.redeemable_info.hasOwnProperty('TWID') && payload.redeemable_info.TWID && payload.redeemable_info.TWID.length > 0) {
        let pointData = payload.redeemable_info.TWID.filter((item) => item.type === 'POINTS')
        points = pointData.length > 0 ? pointData[0].value : 0
      }
      if (payload.offers.hasOwnProperty('TWID') && payload.offers.TWID && payload.offers.TWID.length > 0) {
        offerMsg = payload.offers.TWID[0].description
      }
      state.twidInfo = {offerMsg, points}
    },
    SET_GOKWIK_ORDER_DETAILS: (state, payload) => {
      state.gokwikOrderDetails = {...payload}
    },
    SET_NOSAVEDCARDSTODISPLAY: (state, payload) => {
      state.noSavedCardsToDisplay = payload
    },
    SET_CARD_TOKENISE_SUPPORT: (state, flag) => {
      state.cardTokeniseSupport = flag
    },
    SET_UPI_NUMBER_VERIFY: (state, payload) => {
      state.upiNumberVerify = payload
    },
    SET_JUSPAY_ORDER_STATUS: (state, paylod) => {
      state.juspayOrderStatus = paylod
    }
  }
}

export default payment
