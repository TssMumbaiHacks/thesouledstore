import store from '../../store'
import Vue from 'vue'

const tagsManager = {
  state: {
    gtm_cart_data_response: {},
    product_id: '',
    productsArray: [],
    cart_operation: '',
    productDetailsPrevRoute: '',
    email_id: '',
    moengageImpressionData: {},
    listingLandingDate: ''
  },
  getters: {
    get_coupon_applied: function () {
      let metaObj = {}
      let meta = store.getters._cart.meta
      if (meta && (meta.index['coupon'] || meta.index['coupon'] === 0)) {
        metaObj = meta.items[meta.index['coupon']]
      }
      return metaObj
    },
    cartContent_for_criteo: function () {
      let productCartData = []
      let cartContents = store.getters._cart && store.getters._cart.products && store.getters._cart.products.items
      if (cartContents && Object.keys(cartContents).length) {
        for (let cartContent of Object.keys(cartContents)) {
          let prodData = {
            id: cartContents[cartContent].parent_prod_id,
            price: cartContents[cartContent].spl_price > 0 ? cartContents[cartContent].spl_price : cartContents[cartContent].price,
            quantity: cartContents[cartContent].quantity
          }
          productCartData.push(prodData)
        }
        return productCartData
      }
    },
    cartContent_for_eec: function () {
      let productCartData = []
      let cartContents = store.getters._cart.products && store.getters._cart.products.length && store.getters._cart.products.items
      if (cartContents && cartContents.length) {
        for (let cartContent of Object.keys(cartContents)) {
          let prodData = {
            id: cartContents[cartContent].parent_prod_id,
            name: cartContents[cartContent].product,
            category: cartContents[cartContent].category,
            ...cartContents[cartContent].prod_id !== cartContents[cartContent].parent_prod_id && { variantID: cartContents[cartContent].prod_id },
            quantity: cartContents[cartContent].quantity,
            ...cartContents[cartContent].size && { variant: cartContents[cartContent].size },
            price: cartContents[cartContent].spl_price > 0 ? cartContents[cartContent].spl_price : cartContents[cartContent].price,
            brand: cartContents[cartContent].artist
          }
          productCartData.push(prodData)
        }
      }
      return productCartData
    },
    analytics_cartContent: function (state) {
      var cartProd = []
      let cartContents = store.getters._cart && store.getters._cart.products && store.getters._cart.products.items
      if (cartContents && Object.keys(cartContents).length) {
        for (let cartContent of Object.keys(cartContents)) {
          let prodData = {
            'Product ID': cartContents[cartContent].prod_id,
            'Product': cartContents[cartContent].product,
            'Product Image URL':
              process.env.IMG_BASE_URL +
              process.env.PRODUCT_DETAIL_IMG +
              cartContents[cartContent].images[0],
            'Price': cartContents[cartContent].price,
            'Category': cartContents[cartContent].category,
            'Quantity': cartContents[cartContent].quantity,
            'Currency': 'INR'
          }
          cartProd.push(prodData)
        }
        return cartProd
      }
    },
    get_user_id: function () {
      return store.getters.user && store.getters.user.user_id ? store.getters.user.user_id : ''
    },
    get_exclusive_user: function () {
      if (store.getters.exclusiveUser) {
        return 'Exclusive'
      } else {
        return 'Non-Exclusive'
      }
    },
    get_email_id: function () {
      if (store && store.getters && store.getters.user && store.getters.user.email) {
        return store.getters.user.email
      } else {
        return ''
      }
    },
    cart_content_for_admitad: function () {
      var cartItem = []
      let cartContents = store.getters._cart && store.getters._cart.products && store.getters._cart.products.items
      if (cartContents && Object.keys(cartContents).length) {
        for (let cartContent of Object.keys(cartContents)) {
          let prodData = {
            'Product': {
              'productID': cartContents[cartContent].prod_id.toString(),
              'category': '1',
              'price': cartContents[cartContent].spl_price > 0 ? cartContents[cartContent].spl_price : cartContents[cartContent].price,
              'priceCurrency': 'INR'
            },
            'orderQuantity': cartContents[cartContent].quantity.toString(),
            'additionalType': 'sale'
          }
          cartItem.push(prodData)
        }
        return cartItem
      }
    },
    getMemberShipType: function () {
      let cartContents = store.getters._cart && store.getters._cart.products && store.getters._cart.products.items
      let exclusiveProducts = store.getters._cart && store.getters._cart.meta && store.getters._cart.meta.items[store.getters._cart.meta.index.site_config].exclusive_products
      let memberShipObj = exclusiveProducts && exclusiveProducts.find(excProd => cartContents.find(item => {
        if (parseInt(excProd.prod_id) === parseInt(item.prod_id)) {
          return excProd
        }
      }))
      return memberShipObj && memberShipObj.name
    },
    getMemberShipPrice: function () {
      let cartContents = store.getters._cart && store.getters._cart.products && store.getters._cart.products.items
      let exclusiveroducts = store.getters._cart && store.getters._cart.meta && store.getters._cart.meta.items[store.getters._cart.meta.index.site_config].exclusive_products
      let memberShipObj = cartContents && cartContents.find(item => exclusiveroducts.find(excProd => {
        if (parseInt(excProd.prod_id) === parseInt(item.prod_id)) {
          return item
        }
      }))
      return memberShipObj && memberShipObj.price
    },
    moengageImpressionData: state => state.moengageImpressionData,
    listingLandingDate: state => state.listingLandingDate
  },
  actions: {
    TATVIC_EVENT: (state, {eventName, payload}) => {
      const routeObj = Vue.ls.get('routeObj')
      const tatvicDefaultPayload = {
        USER_ID: store.getters.get_user_id || 'NA',
        USER_TYPE: store.getters.get_exclusive_user,
        SOURCE: routeObj.previous || 'NA',
        PAGE_NAME: routeObj.current,
        UPDATED_SCHEMA: 'Yes',
        LOGGED_IN_STATUS: store.getters.authStatus ? 'Logged In' : 'Non Logged In'
      }
      state.commit('GTAG_EVENT', {eventName, payload: {...tatvicDefaultPayload, ...payload}})
    }
  },
  mutations: {
    GTAG_EVENT: (state, {eventName, payload}) => {
      const countryId = parseInt(store.state.selectedCountryAddress.countryId)
      payload.Country_Id = countryId
      let eventsList = ['product.add_to_cart.payload']
      if (eventsList.includes(eventName)) {
        window.dataLayer.push({ ecommerce: null })
        window.dataLayer.push({
          event: eventName,
          ...payload
        })
      } else {
        const routeObj = Vue.ls.get('routeObj')
        const defaultPayload = {
          USER_ID: store.getters.get_user_id || 'NA',
          USER_TYPE: store.getters.get_exclusive_user,
          SOURCE: routeObj.previous || 'NA',
          PAGE_NAME: routeObj.current,
          UPDATED_SCHEMA: 'Yes',
          LOGGED_IN_STATUS: store.getters.authStatus ? 'Logged In' : 'Non Logged In'
        }
        let eventsList = ['PAYMENT_METHOD_SELECT', 'add_shipping_info', 'CART_ICON_CLICK']
        if (eventsList.includes(eventName)) {
          window.gtag('event', eventName, payload = {...defaultPayload, ...payload})
        } else {
          window.gtag('event', eventName, payload)
        }
      }
    },
    MOENGAGE_EVENT: (state, {eventName, payload}) => {
      const countryId = parseInt(store.state.selectedCountryAddress.countryId)
      payload.Country_Id = countryId
      window.Moengage.track_event(eventName, payload)
    },
    MOENGAGE_SET_USER: (state, user) => {
      window.Moengage.add_unique_user_id(user.user_id)
      window.Moengage.add_first_name(user.firstname)
      window.Moengage.add_last_name(user.lastname)
      window.Moengage.add_email(user.email)
      window.Moengage.add_mobile(user.telephone)
      window.Moengage.add_user_name(user.firstname + user.lastname)
      window.Moengage.add_gender(user.gender)
      window.Moengage.add_birthday(user.birthdate ? new Date(user.birthdate) : '')
    },
    MOENGAGE_CUSTOM_ATTRIBUTES: (state, {attName, payload}) => {
      window.Moengage.add_user_attribute(attName, payload)
    },
    MOENGAGE_CLEAR_USER: () => {
      window.Moengage.destroy_session()
    },
    MOENGAGE_PLP_PROD_VIEW_RESET: (state, payload) => {
      state.moengageImpressionData = {}
    },
    MOENGAGE_PLP_PROD_VIEW_PUSH: (state, payload) => {
      let timeSpent = ''
      if (state.listingLandingDate) {
        const currentTime = new Date()
        timeSpent = Math.floor((currentTime.getTime() - state.listingLandingDate.getTime()) / 1000)
      }
      state.moengageImpressionData = {
        Product_Category: String(payload.item_category),
        Product_Name: String(payload.item_name),
        Product_ID: Number(payload.item_id),
        Product_Price: Number(payload.price),
        Product_Artist: String(payload.item_artist),
        PLP_index: Number(payload.index),
        Product_URL: String(payload.item_url),
        Product_Image_URL: String(payload.item_image_url),
        PLP_URL: String(payload.plp_url),
        Time_Spent: String(timeSpent)
      }
    },
    SET_LISTING_LANDING_DATE: (state, date) => {
      state.listingLandingDate = date
    }
  }
}
export default tagsManager
