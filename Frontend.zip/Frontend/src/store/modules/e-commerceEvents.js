import store from '../../store'
import Vue from 'vue'
const eCommerceEvents = {
  state: {
    currency: 'INR',
    tatvicProductImpression: {
      data: []
    }
  },
  getters: {
    currency: (state) => state.currency,
    getUserTatvicCartItems () {
      let tatvicData = store.getters._cart && store.getters._cart.products && store.getters._cart.products.items && store.getters._cart.products.items.length && store.getters._cart.products.items.map((itm, index) => {
        return {
          item_name: itm.product,
          item_id: itm.prod_id,
          price: store.getters.isExclusive && itm.exclusive_price ? itm.exclusive_price : ((itm.splPrice || itm.spl_price) && (itm.splPrice > 0 || itm.spl_price > 0)) ? itm.splPrice || itm.spl_price : itm.price,
          item_category: itm.category,
          index: index + 1,
          quantity: itm.quantity,
          discount: itm.price - (store.getters.isExclusive && itm.exclusive_price ? itm.exclusive_price : ((itm.splPrice || itm.spl_price) && (itm.splPrice > 0 || itm.spl_price > 0)) ? itm.splPrice || itm.spl_price : itm.price),
          currency: 'INR',
          item_brand: 'The Souled Store',
          coupon: itm.coupon_discount || 'NA',
          item_category2: itm.size || 'NA'
        }
      })
      return tatvicData
    },
    getUserTatvicBuyNowItem () {
      let buynowTatvicData = store.getters._buyNowCart && store.getters._buyNowCart.products && store.getters._buyNowCart.products.items && store.getters._buyNowCart.products.items.length && store.getters._buyNowCart.products.items.map((itm, index) => {
        return {
          item_name: itm.product,
          item_id: itm.prod_id,
          price: store.getters.isExclusive && itm.exclusive_price ? itm.exclusive_price : ((itm.splPrice || itm.spl_price) && (itm.splPrice > 0 || itm.spl_price > 0)) ? itm.splPrice || itm.spl_price : itm.price,
          item_category: itm.category,
          index: index + 1,
          quantity: itm.quantity,
          discount: itm.price - (store.getters.isExclusive && itm.exclusive_price ? itm.exclusive_price : ((itm.splPrice || itm.spl_price) && (itm.splPrice > 0 || itm.spl_price > 0)) ? itm.splPrice || itm.spl_price : itm.price),
          currency: 'INR',
          item_brand: 'The Souled Store',
          coupon: itm.coupon_discount || 'NA',
          item_category2: itm.size || 'NA'
        }
      })
      return buynowTatvicData
    },
    tatvicProductImpression: state => state.tatvicProductImpression
  },
  actions: {
    ECOMMERCE_EVENT: (state, {eventName, payload}) => {
      const routeObj = Vue.ls.get('routeObj')
      const ecommDefaultPayload = {
        USER_ID: store.getters.get_user_id ? store.getters.get_user_id : 'NA',
        USER_TYPE: store.getters.get_exclusive_user ? store.getters.get_exclusive_user : 'NA',
        SOURCE: routeObj.previous ? routeObj.previous : 'NA',
        PAGE_NAME: routeObj.current ? routeObj.current : 'NA',
        LOGGED_IN_STATUS: store.getters.authStatus ? 'Logged In' : 'Non Logged In'
      }
      state.commit('GTAG_EVENT', {eventName, payload: {...ecommDefaultPayload, ...payload}})
    }
  },
  mutations: {
    EC_PLP_PROD_VIEW_RESET: (state, payload) => {
      state.tatvicProductImpression.data = []
    },
    EC_PLP_PROD_VIEW_PUSH: (state, payload) => {
      state.tatvicProductImpression.data.push(payload)
    }
  }
}
export default eCommerceEvents
