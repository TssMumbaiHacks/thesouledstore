import api from '../../api/api'
import Vue from 'vue'
import Axios from 'axios'

// function getGenderType (category) {
//   let gender = 1
//   const GenderDefination = {
//     1: [149, 704, 598, 638, 703, 512, 635, 622, 166, 737],
//     2: [710, 665, 531, 620, 657, 619, 724, 713, 731, 732, 733, 734, 738, 748]
//   }
//   if (GenderDefination[1].includes(category)) {
//     gender = 1
//     return gender
//   } else if (GenderDefination[2].includes(category)) {
//     gender = 2
//     return gender
//   }
//   return gender
// }

function getValidPLPTimer (plpTimerData, payload) {
  let plpMainTimer = plpTimerData && plpTimerData.length > 0 && plpTimerData.find(item => item.url === 'PLP')
  let plpCategoryTimer = plpTimerData && plpTimerData.length > 0 && plpTimerData.filter(item => item.url === 'CATEGORY')
  let plpArtistTimer = plpTimerData && plpTimerData.length > 0 && plpTimerData.filter(item => item.url === 'ARTIST')
  let plpTagTimer = plpTimerData && plpTimerData.length > 0 && plpTimerData.filter(item => item.url === 'TAG')
  if (plpMainTimer) {
    return plpMainTimer
  } else if (plpCategoryTimer && plpCategoryTimer.length > 0 && payload && payload.category && payload.category.length) {
    let AvailableItem = null
    plpCategoryTimer.map((item, index) => {
      let timerCategoryList = item.category_id && item.category_id.length > 0 &&
        item.category_id.split(',').map(Number)
      let isCategoryMatched = payload.category && payload.category.length > 0 &&
        payload.category.some(categoryIds => timerCategoryList && timerCategoryList.length > 0 && timerCategoryList.includes(categoryIds))
      if (isCategoryMatched) {
        AvailableItem = item
      }
    })
    return AvailableItem
  } else if (plpArtistTimer && plpArtistTimer.length > 0 && payload && payload.artist && payload.artist.length) {
    let AvailableItem = null
    plpArtistTimer.map((item, index) => {
      let isArtistMatched = payload.artist && payload.artist.length > 0 &&
      payload.artist.some(artistName => item.artist && item.artist === artistName)
      if (isArtistMatched) {
        AvailableItem = item
      }
    })
    return AvailableItem
  } else if (plpTagTimer && plpTagTimer.length > 0 && payload && payload.tags && payload.tags.length) {
    let AvailableItem = null
    plpTagTimer.map((item, index) => {
      let isTagMatched = payload.tags && payload.tags.length > 0 &&
        payload.tags.some(tagName => item.tag && item.tag === tagName)
      if (isTagMatched) {
        AvailableItem = item
      }
    })
    return AvailableItem
  } else {
    return null
  }
}

function initialState () {
  const state = {
    all: [],
    artist: {},
    tag: {},
    busy: false,
    category: {},
    currentPage: 1,
    listing: { 'sort': 'POPULARITY' },
    _filters: {
      'color': [],
      'size': [],
      'tags': [],
      'genre': [],
      'sort': 'POPULARITY',
      'cats': [],
      'sort_order': 'wwe_sort'
    },
    footerText: '',
    footerTextTitle: '',
    popularSearch: '',
    shopNow: '',
    listbox: 'hello',
    metadata: { 'totalPages': 1, 'currentPage': 1, 'items': 1 },
    pageno: 0,
    products: [],
    product_slug: '',
    productState: 'listing',
    prod_type: '',
    prod_id: '',
    product: {},
    searchData: { data: {}, total: 0 },
    searchPageNo: 1,
    searchKey: '',
    totalPages: 0,
    gqlQuery: {},
    isLoading: true,
    notFound: false,
    colorOptions: [],
    homeScreenData: {},
    pincodeDeliveryDetails: {}
  }
  return state
}

const state = {
  all: [],
  artist: {},
  tag: {},
  busy: false,
  category: {},
  currentPage: 1,
  _filters: { 'color': [], 'size': [], 'tags': [], 'genre': [], 'sort': 0, 'cats': [] },
  footerText: '',
  footerTextTitle: '',
  popularSearch: '',
  shopNow: '',
  listbox: 'hello',
  metadata: { 'totalPages': 1, 'currentPage': 1, 'items': 1 },
  pageno: 1,
  products: [],
  product_slug: '',
  productState: 'listing',
  prod_type: '',
  prod_id: '',
  product: {},
  searchData: { data: {}, total: 0 },
  searchPageNo: 1,
  searchKey: '',
  totalPages: 0,
  relatedProducts: [],
  alsoAvailable: [],
  isLoading: true,
  notFound: false,
  colorOptions: [],
  productId: '',
  crossSellProducts: [],
  plpTimer: null,
  plpMockUpTags: [],
  pdpMockUpTag: {},
  banners: [],
  dailyDropObj: {},
  homeScreenData: {},
  pincodeDeliveryDetails: {},
  donation: {},
  pdpProductRecommData: {},
  recommNewArrivalsData: [],
  recommTopSellingData: [],
  backProductPricing: {
    price: 0,
    exclusive_price: 0,
    spl_price: 0
  },
  crossSellPdpListing: {},
  frequentlyBoughtPdpListing: {},
  noProductDataList: [],
  personalizedWidgetListing: {},
  ratingsData: [],
  topSellingThakyouListing: {},
  recentViewProducts: [],
  overlayFreeze: false
}

// getters
const getters = {
  allProducts: state => state.all,
  artist: state => state.artist,
  tag: state => state.tag,
  artistProduct: state => state.artistProduct,
  busy: state => state.busy,
  category: state => state.category,
  _filters: state => state._filters,
  footerText: state => state.footerText,
  footerTextTitle: state => state.footerTextTitle,
  popularSearch: state => state.popularSearch,
  shopNow: state => state.shopNow,
  FETCH_PRODUCTS: state => state.all,
  FETCH_PRODUCT: state => state.product,
  pageno: state => state.pageno,
  productState: state => state.productState,
  totalPages: state => state.totalPages,
  gqlQuery: state => state.gqlQuery,
  relatedProducts: state => state.relatedProducts,
  alsoAvailable: state => state.alsoAvailable,
  isLoading: state => state.isLoading,
  notFound: state => state.notFound,
  colors: state => state.colorOptions,
  product: state => state.product,
  scrollingOnPlp: state => state.scrollingOnPlp,
  isSamePlp: state => state.isSamePlp,
  productId: state => state.productId,
  crossSellProducts: state => state.crossSellProducts,
  plpTimer: state => state.plpTimer,
  plpMockUpTags: state => state.plpMockUpTags,
  pdpMockUpTag: state => state.pdpMockUpTag,
  banners: state => state.banners,
  dailyDropObj: state => state.dailyDropObj,
  homeScreenData: state => state.homeScreenData,
  pincodeDeliveryDetails: state => state.pincodeDeliveryDetails,
  donation: state => state.donation,
  pdpProductRecommData: state => state.pdpProductRecommData,
  recommNewArrivalsData: state => state.recommNewArrivalsData,
  recommTopSellingData: state => state.recommTopSellingData,
  crossSellPdpListing: state => state.crossSellPdpListing,
  frequentlyBoughtPdpListing: state => state.frequentlyBoughtPdpListing,
  noProductDataList: state => state.noProductDataList,
  personalizedWidgetListing: state => state.personalizedWidgetListing,
  getRatings: state => state.ratingsData,
  topSellingThakyouListing: state => state.topSellingThakyouListing,
  getRecentViewProducts: state => state.recentViewProducts,
  overlayFreeze: state => state.overlayFreeze
}

// actions
const actions = {
  SHOW_COLOR_OPTIONS: ({ state, commit }, payload) => {
    // state.isLoading = true
    api.get(process.env.SOUL_V2 + `product/productlist?name=${payload.category}`).then((response) => {
      payload.tags.map((tag) => {
        if (response.data && response.data.length) {
          if (tag.tag_name in response.data[0]) {
            let colorPayload = response.data[0][tag.tag_name]
            commit('SET_COLORS', colorPayload)
            // state.isLoading = false
          }
        } else if (response.data && response.data.length === 0) {
          commit('SET_COLORS', [])
          // state.isLoading = false
        }
      })
    })
  },
  FETCH_PRODUCTS: (context, payload) => {
    payload = JSON.parse(JSON.stringify(payload))
    let genderType = payload['gender']
    let filterCategories = {}
    filterCategories = payload.filters.category ? payload.filters.category.map(item => parseInt(item)) : []
    let filterFabric = {}
    filterFabric = payload.filters.fabric ? payload.filters.fabric.map(item => parseInt(item)) : []
    let filterSneaker = {}
    filterSneaker = payload.filters.sneaker ? payload.filters.sneaker.map(item => parseInt(item)) : []
    let filterDiscount = {}
    filterDiscount = payload.filters.discount ? payload.filters.discount.map(item => parseInt(item)) : []
    payload.filters.price = payload.filters.price && payload.filters.price.length && payload.filters.price.map(price => parseInt(price))
    let query = `
        {
          listing(
              page:${payload.page || 1},
              size:${payload.size || 24},
              gender:${genderType},
              isKids:${payload.isKids},
              isWeb: true,
              sort:${payload.filters.sort},
              category: ${JSON.stringify(payload['category_merge'] || [])},
              artist: ${JSON.stringify(payload.artist || [])},
              tags: ${JSON.stringify(payload.tags || [])}
              filters:{
                category: ${JSON.stringify(filterCategories || [])},
                artist: ${JSON.stringify(payload.filters.artist || [])},
                tags: ${JSON.stringify(payload.filters.tags || [])},
                size: ${JSON.stringify(payload.filters.size || [])},
                price: ${JSON.stringify(payload.filters.price || [])}
                gender: ${payload.filters.gender || JSON.stringify([])},
                fabric: ${JSON.stringify(filterFabric || [])},
                color: ${JSON.stringify(payload.filters.color || [])},
                discount: ${JSON.stringify(filterDiscount || [])},
                pattern: ${JSON.stringify(payload.filters.pattern || [])},
                sleeve: ${JSON.stringify(payload.filters.sleeve || [])},
                neck: ${JSON.stringify(payload.filters.neck || [])},
                fittype: ${JSON.stringify(payload.filters.fittype || [])},
                sneaker: ${JSON.stringify(filterSneaker || [])},
              },
              includefilter:["Age Group", "Sneakers"],
              ${payload.showTipTiles ? 'tiptile:1' : ''}
              ){
            products{
              id
              product
              artist{name,slug}
              category{name}
              price
              genderType
              stock
              avgRating
              ratingCount
              prodQty
              prodType
              splPrice
              exclusivePrice
              sortOrder
              images
              imagesNew
              extraPrice
              isPrintable
              jitValue
              product_slug: productSlug
              isBlurOnPlp
              plpCoverImage
              targetDate
              isProductLocked
              ${payload.showTipTiles ? 'tiptiles {id type name navLink image mobileImage colWidth isClickable promotionName}' : ''}
              ${payload.showVariants ? 'variants {id, attributes {name, value}}' : ''}
            }
            pagination {
              currentPage
              totalPages
              totalProduct
            }
            filters{
              options{
                name
                slug
                count
              }
              alias
              field
            }
            isMaleDataAvailable
            isFemaleDataAvailable
            isKidDataAvailable
          }
        }
        `
    let token = Vue.ls.get('tss_token')
    let localcart = Vue.ls.get('localcart')
    // context.commit('RESET_LISTING')
    let queryData = { 'query': query, localcart, is_ab_visible: true }
    if (payload && payload.routeName) {
      queryData.page_url = payload.routeName
    }
    return api.post('graphql', queryData, { headers: { Authorization: token } }).then((response) => {
      context.commit('SET_PRODUCTS', response.data.data.listing)
      Vue.ls.set('listCache', response.data.data.listing)
      context.commit('SET_PAGE_NO')
      return response.data.data
    }, error => {
      Vue.toasted.show(error.data.title, {
        theme: 'primary',
        className: 'toasted-customred',
        position: 'top-right',
        duration: 5000
      })
    })
  },
  FETCH_DONATIONS: (content, payload) => {
    let token = Vue.ls.get('tss_token')
    let localcart = Vue.ls.get('localcart')
    let query = `
    {
      listing(
          page: 1,
          size:72,
          gender: 1,
          sort: DEFAULT,
          category: [${JSON.stringify(payload)}],
          artist: [],
          tags: []
          filters:{
            category: [],
            artist: [],
            tags: [],
            size: [],
            price: []
          }
          ){
        products{
          id
          product
          artist{name,slug}
          category{name}
          price
          genderType
          stock
          prodQty
          prodType
          splPrice
          exclusivePrice
          sortOrder
          images
          imagesNew
          extraPrice
          isPrintable
          jitValue
          product_slug: productSlug
        }
        pagination {
          currentPage
          totalPages
        }
        filters{
          options{
            name
            slug
          }
          alias
          field
        }
      }
    }
    `
    return api.post('graphql', { 'query': query, localcart, 'is_ab_visible': true }, { headers: { Authorization: token } }).then((response) => {
      content.commit('GET_DONATIONS', response.data.data.listing)
      return response.data
    }, error => {
      Vue.toasted.show(error.data.title, {
        theme: 'primary',
        className: 'toasted-customred',
        position: 'top-right',
        duration: 5000
      })
    })
  },
  GET_THANK_YOU_PAGE_SIMILER_PRODUCT_LIST: ({ commit }, payload) => {
    let query = `{
      listing(
          page: 1,
          size: 20,
          category: [${payload.categoryList.join(', ')}],
          sort: POPULARITY,
          artist: []
          tags: [],
          filters:{
            price: []
          }
          ){
        products{
          id
          product
          artist{name,slug}
          category{name}
          price
          genderType
          stock
          avgRating
          ratingCount
          prodQty
          prodType
          splPrice
          exclusivePrice
          sortOrder
          images
          imagesNew
          extraPrice
          isPrintable
          jitValue
          product_slug: productSlug
          isBlurOnPlp
          plpCoverImage
          targetDate
          isProductLocked
        }
      }
    }`

    let token = Vue.ls.get('tss_token')
    let localcart = Vue.ls.get('localcart')
    let productId = payload && payload.productIds || []

    return api.post('graphql', {'query': query, localcart, 'is_ab_visible': true, 'exclude_products': productId}, { headers: { Authorization: token } }).then((response) => {
      console.log('GET_THANK_YOU_TOPSELLING_LIST', response.data.data.listing.products)
      let data = {
        data: response.data.data.listing.products,
        name: 'you may also like'
      }
      commit('SET_THANKYOU_PAGE_SUGGESTIN_LISTING', data)
      return response
    }, error => {
      Vue.toasted.show(error.data.title, {
        theme: 'primary',
        className: 'toasted-customred',
        position: 'top-right',
        duration: 5000
      })
    })
  },
  GET_PLP_TIMER: (state, payload) => {
    if (Vue.ls.get('listCacheTimer') && Object.keys(Vue.ls.get('listCacheTimer')).length) {
      state.commit('SET_PLP_TIMER_DATA', Vue.ls.get('listCacheTimer'))
    }
    Axios.get(process.env.MOBILE_CMS_URL + `product/web/data?platform_type=web`).then((response) => {
      if (response && response.data && response.data.length) {
        if (response && response.data && response.data.length && Object.keys(response.data[0]).length) {
          let plpTimer = getValidPLPTimer(response.data, payload)
          state.commit('SET_PLP_TIMER_DATA', null)
          Vue.ls.set('listCacheTimer', plpTimer)
          state.commit('SET_PLP_TIMER_DATA', plpTimer)
        }
      }
    }, error => {
      console.log(error)
    })
  },
  GET_PLP_MOCK_TAG: (state, payload) => {
    state.commit('SET_PLP_MOCKUP_TAGS', [])
    Axios.get(process.env.MOBILE_CMS_URL + `product/mockuptag?platform_type=web`).then((response) => {
      if (response && response.data && response.data.length) {
        Vue.ls.set('listCacheMockupTag', response.data)
        state.commit('SET_PLP_MOCKUP_TAGS', response.data)
      }
    }, error => {
      console.log(error)
    })
  },
  FETCH_PRODUCT: ({ commit, dispatch, getters }, payload) => {
    let localcart = Vue.ls.get('localcart')
    commit('RESET_PRODUCT_DETAIL')
    commit('SET_COLORS', [])
    return api.post('product/' + payload.slug + `?gender_type=${payload.gender_type || 1}`, { localcart, 'is_ab_visible': true }, { headers: { Authorization: Vue.ls.get('tss_token') }, params: {platform: 'web'} }).then((response) => {
      let product = response.data
      if (!getters.authStatus) {
        commit('ADD_PRODUCT_ID', {
          newId: product && product.id,
          product: product
        })
      }
      commit('SET_PRODUCT', product)
      /* let routeObj = Vue.ls.get('routeObj')
      window && window.fbq && window.fbq('track', 'viewcontent', {
        'payload': routeObj
      }, {
        'eventID': response && response.data && response.data.viewcontent_event_id,
        'country_code': 'in',
        'event': 'ViewContent'
      })
      window && window.fbq && window.fbq('track', 'pageview', {
        'payload': routeObj
      }, {
        'eventID': response && response.data && response.data.pageview_event_id,
        'country_code': 'in',
        'event': 'PageView'
      }) */
      // commit('GTAG_EVENT', {eventName: 'response.pdp.product', payload: {pdp_response: product}})
      // commit('GTAG_EVENT', {eventName: 'ct_page_viewed_custom', payload: {pdp_response: {...product, routeObj: Vue.ls.get('routeObj')}}})
      // commit('GTAG_EVENT', {eventName: 'Page_Viewed', payload: {pdp_response: {...product, routeObj: Vue.ls.get('routeObj')}}})
      // commit('GTAG_EVENT', {eventName: 'FB_View_Product',
      //   payload: {
      //     product_id: product.id,
      //     product_name: product.product,
      //     product_cat: product.category,
      //     price:
      //       product.spl_price > 0
      //         ? parseInt(product.spl_price)
      //         : parseInt(product.price)
      //   }}
      // )
      // commit('GTAG_EVENT', {eventName: 'eec.product.detail.view',
      //   payload: {
      //     exclusive_user: getters.get_exclusive_user,
      //     channel_signature: 'The_Souled_Store ' + product.firstname,
      //     ecommerce: {
      //       detail: {
      //         actionField: {
      //           list: getters.productDetailsPrevRoute && getters.productDetailsPrevRoute.path   // here it should come as from where the data is product detail is coming
      //         },
      //         products: [{
      //           id: product.id,
      //           name: product.product,
      //           category: product.category,
      //           brand: product.firstname,
      //           price: product.spl_price > 0 ? product.spl_price : product.price
      //         }]
      //       }
      //     }
      //   }}
      // )
      // commit('GTAG_EVENT', {eventName: 'Product_Viewed',
      //   payload: {
      //     productDetail: {
      //       Artist_Name: product.artist_slug,
      //       Tag_Name: product.tags,
      //       Product_Name: product.product,
      //       Product_Price: product.price,
      //       category: product.category,
      //       SKU: product.parent_cat
      //     }
      //   }}
      // )
      // commit('GTAG_EVENT', {eventName: 'crto_productpage',
      //   payload: {crto: {
      //     email: getters.user && getters.user.email,
      //     pdp_products: product && product.id
      //   }}}
      // )
      // let relatedPayload = { 'productSlug': response.data.product_slug, 'productName': (response.data.product).replace(/"/g, '\\"'), 'productArtist': response.data.added_by }
      // DOWNTIME!
      // dispatch('GET_RELATED_PRODUCTS', relatedPayload)
      // meta data
      dispatch('SHOW_COLOR_OPTIONS', product)
      dispatch('GET_PDP_MOCK_TAG', payload.slug)
      payload._this.metaTitle = product.meta_title
      payload._this.metaDescription = product.meta_desc
      payload._this.ogTitle = product.og_title || product.meta_title
      payload._this.ogDescription = product.og_description || product.meta_desc
      payload._this.metaKeywords = product.meta_keys
      payload._this.metaUrl = window.location.href
      payload._this.metaTwitterTitle = product.twitter_title || product.meta_title
      payload._this.metaTwitterDescription = product.twitter_description || product.meta_desc
      payload._this.metaTwitterImage = product.images[0] ? (process.env.IMG_BASE_URL + process.env.PRODUCT_DETAIL_IMG + product.images[0]) : 'https://www.thesouledstore.com/static/img/newlogosticky.f7f01f0.png'
      payload._this.metaImage = product.images[0] ? (process.env.IMG_BASE_URL + process.env.PRODUCT_DETAIL_IMG + product.images[0]) : 'https://www.thesouledstore.com/static/img/newlogosticky.f7f01f0.png'
      return product
    }, error => {
      console.log(error)
      commit('SET_NOT_FOUND')
      return {}
    })
  },
  GET_PDP_MOCK_TAG: (state, slug) => {
    state.commit('SET_PDP_MOCKUP_TAG', {})
    Axios.get(process.env.MOBILE_CMS_URL + `product/mockuptag?product_slug=${slug}&platform_type=web`).then((response) => {
      if (response && response.data && response.data.length) {
        state.commit('SET_PDP_MOCKUP_TAG', response.data[0])
      }
    }, error => {
      console.log(error)
    })
  },
  GET_EXC_BAND_DATA: ({ commit, dispatch }) => {
    return Axios.get(process.env.MOBILE_CMS_URL + 'banner/banner').then((response) => {
      if (response && response.data && response.data.length) {
        commit('SET_BANNER_DATA', response.data)
        return response.data
      }
    }, error => {
      console.log(error)
      return {}
    })
  },
  CROSS_SELL_DATA: ({ commit, dispatch }, category) => {
    return Axios.get(process.env.MOBILE_CMS_URL + `product/productrecommed?category=${category}`).then((response) => {
      if (response && response.data &&
        response.data && response.data.data &&
        response.data.data.length) {
        let crossSellProduct = response.data.data.find(item => item.cross_sell === true && item.category)
        return crossSellProduct
      }
    }, error => {
      console.log(error)
      commit('SET_NOT_FOUND')
      return {}
    })
  },
  GET_TICKER_POINTS: (state, {prodID, isExclusive}) => {
    return Axios.get(process.env.APP_URL + `tss-point-ticker?product_id=${prodID}&is_exclusive_users=${isExclusive}`).then((response) => {
      if (response && response.data) {
        return response.data
      }
    }, error => {
      console.log(error)
      return {}
    })
  },
  GET_PDP_PRODUCT_RECOMMENDATION: ({ commit, dispatch }, params) => {
    const token = Vue.ls.get('tss_token')
    return Axios.get(process.env.ELASTIC_SEARCH_URL + 'pdp-suggest', { headers: { Authorization: token }, params }).then((response) => {
      if (response && response.data) {
        return commit('SET_PDP_PRODUCT_RECOMMENDATION', response.data)
      }
    }, error => {
      console.log(error)
      // commit('SET_NOT_FOUND')
      return {}
    })
  },
  FETCH_CROSS_SELL_PRODUCTS: (context, payload) => {
    // let genderType = getGenderType((payload.category) ? payload.category.length ? payload.category[0] : payload.category : 1)

    let query = `
        {
          listing(
              page:1,
              size:72,
              gender:${payload && payload.genderType},
              sort: POPULARITY,
              category: ${payload && JSON.stringify(payload.category)},
              artist: ${JSON.stringify([])},
              tags: ${JSON.stringify([])}
              filters:{
                category: ${JSON.stringify([])},
                artist: ${JSON.stringify([])},
                tags: ${JSON.stringify([])},
                size: ${JSON.stringify([])},
                price: ${JSON.stringify([])}
              }
              ){
            products{
              id
              product
              artist{name,slug}
              category{name}
              price
              genderType
              stock
              prodQty
              prodType
              splPrice
              exclusivePrice
              sortOrder
              images
              imagesNew
              extraPrice
              isPrintable
              jitValue
              product_slug: productSlug
            }
            pagination {
              currentPage
              totalPages
            }
            filters{
              options{
                name
                slug
              }
              alias
              field
            }
          }
        }
        `
    let token = Vue.ls.get('tss_token')
    let localcart = Vue.ls.get('localcart')
    // context.commit('RESET_LISTING')
    return api.post('graphql', { 'query': query, localcart, 'is_ab_visible': true }, { headers: { Authorization: token } }).then((response) => {
      context.commit('CROSS_SELL_PRODUCTS', response.data.data.products)
      context.commit('SET_PAGE_NO')
      return response.data.data.listing.products
    }, error => {
      Vue.toasted.show(error.data.title, {
        theme: 'primary',
        className: 'toasted-customred',
        position: 'top-right',
        duration: 5000
      })
      return {}
    })
  },
  GET_GENDER_WISE_PRODUCT_CATEGORIES: ({commit, dispatch}) => {
    return Axios.get(process.env.MOBILE_CMS_URL + 'product/gender').then((response) => {
      if (response && response.data && response.data.data) {
        return response.data.data
      }
    }, error => {
      console.log(error)
      return {}
    })
  },
  GET_DONATION_AND_MEALS: ({ commit, dispatch }, payload) => {
    // return api.post(process.env.V1_HOST + '/api/v1/donation-tracking')
    return api.post(process.env.V1_HOST + '/api/v1/donation-tracking').then((response) => {
      if (response.data &&
        response.data.status &&
        response.data.status.toLowerCase() !== 'fail'.toLowerCase()) {
        return response.data.data
      }
    }, error => {
      console.log(error)
    })
  },
  GET_LISTING_META: (state, meta) => {
    let typeMapping = {
      'tags': ['tag', 'SET_TAG'],
      'artists': ['artist', 'SET_ARTIST'],
      'explore': ['category', 'SET_CATEGORY'],
      'men': ['category', 'SET_CATEGORY'],
      'women': ['category', 'SET_CATEGORY'],
      'kids': ['category', 'SET_CATEGORY']
    }
    let slug = meta.slug
    switch (meta.slug) {
      case 'polo-tshirts':
        slug = meta.type === 'men' ? 'polos' : 'womens-polo-tshirt'
        break
      case 'tank-tops':
        slug = 'womens-tank-tops'
        break
      case 'joggers':
        slug = meta.type === 'men' ? 'joggers' : 'womens-joggers'
        break
      case 'shorts':
        slug = 'womens-shorts'
        break
      case 'sweat-shirts':
        slug = 'sweatshirts'
        break
      case 't-shirts':
        slug = meta.type === 'men' ? 't-shirts' : 'unisex-t-shirts'
        break
      case 'hoodies-and-sweatshirts':
        slug = meta.type === 'men' ? 'hoodies' : 'unisex-hoodies'
        break
      case 'sweatshirts':
        slug = meta.type === 'men' ? 'unisex-sweatshirts' : 'women-sweatshirts'
        break
      case 'sweaters':
        slug = meta.type === 'men' ? 'sweaters' : 'unisex-knitted-sweat'
        break
      case 'jackets':
        slug = meta.type === 'men' ? 'jackets' : 'unisex-jackets'
        break
      case 'sweat-shorts':
        slug = 'sweatshorts'
        break
      case 'printedsocks':
        slug = 'printed-socks'
        break
      case 'printed-socks':
        slug = meta.type === 'women' ? 'women-socks' : 'accessories-socks'
        break
      case 'backpacks':
        slug = meta.type === 'men' ? 'men-backpacks' : meta.type === 'women' ? 'women-backpacks' : 'accessories-backpack'
        break
      case 'winter-wear':
        slug = meta.type === 'men' ? 'mens-winter-wear' : 'womens-winter-wear'
        break
      case 'shirts':
        slug = meta.type === 'women' ? 'womens-shirts' : 'shirts'
        break
      case 'chinos-shorts':
        slug = 'chino-shorts'
        break
      case 'dropcut-tshirt':
        slug = 'women-dropcut-tshirt'
        break
      case 'full-sleeve-shirts':
        slug = meta.type === 'women' ? 'women-full-sleeve-tshirt' : 'full-sleeve-shirts'
        break
      case 'hawaiian-shirt':
        slug = 'women-hawaiian-shirt'
        break
      case 'polo-tshirt':
        slug = 'womens-polo-tshirt'
        break
      case 'Women-full-sleeve-tshirtdresses':
        slug = 'Women-full-sleeve-tshirt-dressess'
        break
      case 'full-sleeve-tshirt-dresses':
        slug = 'Women-full-sleeve-tshirt-dressess'
        break
      case 'oversized-tshirt-dresses':
        slug = 'women-oversized-tshirt-dresses'
        break
      case 'cotton-pants':
        slug = meta.type === 'women' ? 'unisex-denim-joggers' : 'mens-cotton-pants'
        break
      case 'full-sleeve-tshirt':
        slug = meta.type === 'women' ? 'women-full-sleeve-tshirt' : 'full-sleeve-tshirts'
        break
      case 'supima-collection':
        slug = meta.type === 'women' ? 'womens-supima-collection' : 'mens-supima-collection'
        break
      case 'hooper-joggers':
        slug = meta.type === 'women' ? 'women-hooper-joggers' : 'hopper-joggers'
        break
      case 'pajamas':
        slug = meta.type === 'women' ? 'womens-pajamas' : 'pajamas'
        break
      case 'co-ord-sets':
        slug = meta.type === 'women' ? 'women-co-ord-sets' : 'men-co-ord-sets'
        break
      case 'tshirts':
        slug = meta.type === 'women' ? 'womens-tshirts' : 't-shirts'
        break
      case 'layered-tshirts':
        slug = 'layered-t-shirts'
        break
      case 'half-sleeve-henley-tshirts':
        slug = 'half-sleeve-henley'
        break
      case 'mystery-tshirts':
        slug = meta.type === 'women' ? 'mystery-womens-t-shirts' : 'mystery-t-shirts'
        break
      case 'supima-full-sleeve-henleys-tshirts':
        slug = 'supima-full-sleeve-henleys'
        break
      case 'supima-tshirts':
        slug = 'supima-t-shirts'
        break
      case 'supima-drop-cut-tshirts':
        slug = 'supima-drop-cut-t-shirts'
        break
      case 'supima-half-sleeve-henley-tshirts':
        slug = 'supima-half-sleeve-henleys'
        break
      case 'half-sleeve-shirts':
        slug = 'halfsleeve-shirts'
        break
      case 'supima-pants':
        slug = meta.type === 'women' ? 'womens-supima-pants' : 'mens-supima-pants'
        break
      // case 'tshirt-dresses':
      //   slug = 't-shirt-dresses'
      //   break
      case 'dolman-sleeve-tshirts':
        slug = meta.type === 'women' ? 'womens-dolman-sleeve-tshirts' : 'dolman-sleeve-tshirts'
        break
      case 'oversized-crop-tops':
        slug = meta.type === 'women' ? 'womens-oversized-crop-top' : 'oversized-crop-top'
        break
      case 'drop-shoulder-tshirt':
        slug = meta.type === 'women' ? 'womens-drop-shoulder-tshirt' : 'drop-shoulder-tshirt'
        break
      case 'supima-women-t-shirts':
        slug = 'supima-tshirts'
        break
      case 'henley-tshirts':
        slug = meta.type === 'women' ? 'womens-henley' : 'henley'
        break
      case 'oversized-tshirts':
        slug = meta.type === 'women' ? 'women-oversized-tshirts' : 'oversized-tshirts'
        break
      case 'hawaiian-shirts':
        slug = meta.type === 'women' ? 'women-hawaiian-shirt' : 'hawaiian-shirt'
        break
      case 'mandarin-shirts':
        slug = meta.type === 'women' ? 'women-mandarin-shirt' : 'mandarin-shirt'
        break
      case 'shirt-dresses':
        slug = meta.type === 'women' ? 'womens-shirt-dress' : 'shirt-dress'
        break
      case 'hoodies':
        slug = meta.type === 'women' ? 'women-hoodies' : 'hoodies'
        break
      default:
        slug = meta.slug
    }
    if (Vue.ls.get('listing_meta_info') && Vue.ls.get('listing_meta_locator') === typeMapping[meta.type][0] + '/' + slug) {
      state.commit(typeMapping[meta.type][1], Vue.ls.get('listing_meta_info').data)
      return Vue.ls.get('listing_meta_info')
    } else {
      let isKids = false
      if (meta.type === 'kids') {
        isKids = true
      }
      return api.get(typeMapping[meta.type][0] + '/' + slug, {params: {platform: 'web', isKids: isKids}}).then(response => {
        state.commit(typeMapping[meta.type][1], response.data)
        Vue.ls.set('listing_meta_locator', typeMapping[meta.type][0] + '/' + slug)
        Vue.ls.set('listing_meta_info', response)
        return response
      })
    }
  },
  GET_SALE_DETAILS: (state, slug) => {
    return Axios.get(process.env.MOBILE_CMS_URL + `product/data?sale_url=${slug}`).then((response) => {
      if (response && response.data && response.data.length) {
        return response.data[0]
      }
    }, error => {
      console.log(error)
      return {}
    })
  },
  GET_SALE_PRODUCT_DETAILS: (state, productSlug) => {
    return Axios.get(process.env.MOBILE_CMS_URL + `product/data?sale_url=${productSlug}&platform_type='web'`).then((response) => {
      if (response && response.data && response.data.length) {
        return response.data[0]
      }
    }, error => {
      console.log(error)
      return {}
    })
  },
  RESET_FILTERS: (state) => {
    state.commit('RESET_FILTERS')
  },
  RESET_FOOTER_TEXT: (state) => {
    state.commit('RESET_FOOTER_TEXT')
  },
  SET_HOME_FOOTER_TEXT: (state) => {
    if (Vue.ls.get('tss_footerText')) {
      state.commit('RESET_FOOTER_TEXT')
      state.commit('SET_FOOTER_TEXT', { text: Vue.ls.get('tss_footerText') })
    } else {
      api.get('wwehome').then(response => {
        this.wwehome = response.data
        Vue.ls.set('tss_footerText', response.data.footer_text, 30 * 60 * 1000)
        state.commit('SET_FOOTER_TEXT', { text: response.data.footer_text })
      })
    }
  },
  SET_FILTERS: (state, payload) => {
    state.commit('SET_FILTERS', payload)
  },
  SET_FOOTER_TEXT: (state, payload) => {
    state.commit('SET_FOOTER_TEXT', payload)
  },
  SET_PRODUCTS_TO_DEFALUT: ({ state, commit }) => {
    commit('SET_PRODUCTS_TO_DEFAULT')
    Object.assign(state.all, [])
    state.totalPages = 0
  },
  SET_DEFAULT_BUSY: (state) => {
    state.commit('SET_DEFAULT_BUSY')
  },
  SET_DEFAULT_CATALOG: (state) => {
    state.commit('SET_DEFAULT_CATALOG')
  },
  SET_PAGE_NO: (state, pageno) => {
    state.commit('SET_PAGE_NO', pageno)
  },
  SET_PRODUCT_STATE: (state, productState) => {
    state.commit('SET_PRODUCT_STATE', productState)
  },
  GET_RELATED_PRODUCTS: (state, payload) => {
    // var pricelists = []
    // var pricelistquery = ''
    // var currentDate = new Date()
    // currentDate = currentDate.toISOString()
    // if (state.getters.active_pricelists['pricelists'] && state.getters.active_pricelists['pricelists'].length > 0) {
    //   pricelists = state.getters.active_pricelists['pricelists']
    //   pricelistquery = `product_pricelists @filter(eq(is_active, 1) AND eq(pricelist_id, ${pricelists}) AND le(start_date, "${currentDate}") AND ge(expiry_date, "${currentDate}")) (orderasc: priority) (first: 1)
    //   {
    //     price
    //     pricelist_id
    //   }`
    // }
    //
    // var query = `
    //   {
    //           A as var(func: eq(product, "${payload.productName}")) @filter(has(product) AND NOT eq(url_key, "${payload.productSlug}") AND NOT eq(primary_category_id, 153) AND gt(stock,0)) {
    //             exact_product_score as math(100)
    //           }
    //           categories as var(func: has(name), first: 20, orderasc: search_sort) @filter(eq(is_nav,1) AND NOT eq(category_id,153)) @cascade {
    //             uid
    //             name
    //              ~product_categories (first: 2) @filter(eq(added_by,${payload.productArtist}) AND NOT eq(url_key, "${payload.productSlug}") AND gt(stock,0)) {
    //               product_id as id
    //             }
    //           }
    //           result as var(func: uid(A))
    //            {
    //              primary_category_sort_order as primary_category_sort_order
    //              product_sort_order as product_sort_order
    //              sorter as math((primary_category_sort_order) * -1 * 10000000000000 + (exact_product_score) * 10000000 + (product_sort_order) * -1)
    //            }
    //            related_result as var(func: uid(product_id, categories)) @filter(has(product))
    //             {
    //               primary_category_sort_order1 as primary_category_sort_order
    //               product_sort_order1 as product_sort_order
    //               sorter1 as math((primary_category_sort_order1) * -1 * 10000000000000 + (1) * 10000000 + (product_sort_order1) * -1)
    //
    //             }
    //            also(func: uid(result), orderdesc: val(sorter), offset: 0, first: 20) @filter(eq(is_avail,1) AND eq(is_del,0)) {
    //              id
    //              product
    //              url_key
    //              price
    //              images
    //              spl_price
    //              ${pricelistquery}
    //              category: primary_category
    //              stock
    //            }
    //            related(func: uid(related_result), orderdesc: val(sorter1), offset: 0, first: 20) @filter(eq(is_avail,1) AND eq(is_del,0)) {
    //              id
    //              product
    //              url_key
    //              price
    //              images
    //              spl_price
    //              ${pricelistquery}
    //              category: primary_category
    //              stock
    //            }
    //   }
    // `
    // var data = { 'alsoAvailable': {}, 'relatedProducts': {} }
    // var payloadData = { 'query': query }
    // api.post('related-products', payloadData).then((response) => {
    //   if (response.data) {
    //     var alsoData = response.data.also
    //     var relatedData = response.data.related
    //     var item
    //     for (var i = 0; i < alsoData.length; i++) {
    //       item = alsoData[i]
    //       alsoData[i]['discounted_price'] = item['spl_price']
    //       if (item['product_pricelists']) {
    //         alsoData[i]['discounted_price'] = item['product_pricelists'][0]['price']
    //       }
    //       alsoData[i]['images'] = item['images'] !== '' ? JSON.parse(item['images']) : {}
    //     }
    //     for (i = 0; i < relatedData.length; i++) {
    //       item = relatedData[i]
    //       relatedData[i]['discounted_price'] = item['spl_price']
    //       if (item['product_pricelists']) {
    //         relatedData[i]['discounted_price'] = item['product_pricelists'][0]['price']
    //       }
    //       relatedData[i]['images'] = item['images'] !== '' ? JSON.parse(item['images']) : {}
    //     }
    //     data = { 'alsoAvailable': alsoData, 'relatedProducts': relatedData }
    //     // let randomDatafornow = { data: relatedData, route: location.pathname }
    //   }
    //   // DOWNTIME!
    //   state.commit('GET_RELATED_PRODUCTS', data)
    // }).catch((error) => {
    //   // DOWNTIME!
    //   state.commit('GET_RELATED_PRODUCTS', data)
    //   console.log(error)
    // })
  },
  GET_HOME_SCREEN_DATA: (state, payload) => {
    let apiUrl = payload.isComboActive ? 'homescreenweb/v3' : 'homescreenweb'
    const getSelectedCountry = Vue.ls.get('selectedCountryAddress')
    const countryId = getSelectedCountry ? getSelectedCountry.countryId : process.env.IND_COUNTRY_ID
    apiUrl = apiUrl + '?country_id=' + countryId
    const token = Vue.ls.get('tss_token') || null
    api.get(process.env.MOBILE_CMS_URL + apiUrl + '&is_ab_visible=true', { headers: { Authorization: token } }).then(response => {
      if (response && response.data) {
        state.commit('SET_HOME_SCREEN_DATA', payload.isComboActive ? response.data : response.data && response.data['Home Screen'])
      }
    })
    .catch((error) => {
      console.log(error)
    })
  },
  GET_RECOMMENDED_NEW_ARRIVALS_DATA: ({commit, getters}, payload) => {
    const params = {
      gender: getters.webcategory === 'women' ? 2 : 1,
      user_id: Vue.ls.get('userID')
    }
    const token = Vue.ls.get('tss_token')
    api.get(process.env.ELASTIC_SEARCH_URL + 'get-new-arrivals', { headers: { Authorization: token }, params }).then(response => {
      if (response && response.data) {
        const data = response.data['new_arrivals'] && response.data['new_arrivals'].response && response.data['new_arrivals'].response.products
        commit('SET_RECOMMENDED_NEW_ARRIVALS_DATA', data)
      }
    })
    .catch((error) => {
      console.log(error)
    })
  },
  GET_DELIVERY_DETAILS_FROM_PINCODE: (state, payload) => {
    return api.get(`delivery-estimate/${payload.pincode}${payload.id ? '?product_id=' + payload.id : ''}`).then(response => {
      state.commit('SET_DELIVERY_DETAILS_FROM_PINCODE', response.data)
      return response.data
    })
    .catch((error) => {
      console.log(error)
    })
  },
  SET_PRODUCT_STOCK_NOTIFICATION: ({ commit, dispatch }, payload) => {
    return api.post(process.env.APP_URL + 'stock-notify', payload).then((response) => {
      if (response.data && response.data.status) {
        Vue.toasted.show(response.data.message, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 3000
        })
        return response
      }
    })
    .catch((error) => {
      console.log(error)
    })
  },
  SET_PRODUCT_LAUNCH_NOTIFICATION: ({ commit, dispatch }, payload) => {
    return api.post(process.env.APP_URL + 'launch-notify', payload).then((response) => {
      if (response.data && response.data.status) {
        Vue.toasted.show(response.data.message, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 3000
        })
        return response
      }
    })
    .catch((error) => {
      console.log(error)
    })
  },
  GET_RECOMMENDED_TOP_SELLING_DATA: ({commit, getters}, payload) => {
    const params = {
      gender: getters.webcategory === 'women' ? 2 : 1
    }
    api.get(process.env.ELASTIC_SEARCH_URL + 'get-top-products', { params }).then(response => {
      if (response && response.data) {
        const data = response.data['top_products'] && response.data['top_products'].response && response.data['top_products'].response.products
        commit('SET_RECOMMENDED_TOP_SELLING_DATA', data)
      }
    })
    .catch((error) => {
      console.log(error)
    })
  },
  COMBO_PRICE_CHANGE_UPDATE: ({commit, getters}, payload) => {
    return api.post(process.env.APP_URL + 'product/combo', payload).then(response => {
      return response && response.data
    })
    .catch((error) => {
      console.log(error)
    })
  },
  GET_PLP_GENDER_TABS_DATA: (state, payload) => {
    return api.get(process.env.MOBILE_CMS_URL + `banner/page-gender-flag`, payload).then(response => {
      if (response && response.data) {
        Vue.ls.set('genderTabsCache', response.data)
        return response.data
      }
    }).catch((error) => {
      console.log(error)
    })
  },
  GET_NO_PRODUCT_DATA_LIST: (state, payload) => {
    return api.post(process.env.ELASTIC_SEARCH_URL + `no-result-found?platform=web`, payload).then(response => {
      if (response && response.data && response.data.response) {
        return response.data.response
      }
    }).catch((error) => {
      console.log(error)
      throw error
    })
  },
  GET_CROSS_SELL_PDP_LISTING: ({commit}, payload) => {
    let token = Vue.ls.get('tss_token')
    return api.post(process.env.SERACH_RECOMMENED_API + `category-cross-sell-data`, payload, {headers: {Authorization: token}}).then(response => {
      if (response && response.data) {
        commit('SET_CROSS_SELL_PDP_LISTING', response.data)
      }
    }).catch((error) => {
      console.log(error)
      throw error
    })
  },
  GET_FREQUENT_BOUGHT_PDP_LISTING: ({commit}, payload) => {
    const token = Vue.ls.get('tss_token')
    return api.get(process.env.SERACH_RECOMMENED_API + 'frequently_bought_data?gender=' + payload.gender + '&gte=' + payload.gte + '&is_ab_visible=true', { headers: { Authorization: token } }).then(response => {
      if (response && response.data) {
        commit('SET_FREQUENT_BOUGHT_PDP_LISTING', response.data)
      }
    }).catch((error) => {
      console.log(error)
      throw error
    })
  },
  GET_PERSONALIZED_WIDGET_LISTING: ({commit}, payload) => {
    return api.post(process.env.SERACH_RECOMMENED_API + 'personalized_user_data', payload).then(response => {
      if (response && response.data) {
        commit('SET_PERSONALIZED_WIDGET_LISTING', response.data)
      }
    }).catch((error) => {
      console.error(error)
      throw error
    })
  },
  VOTE_SOLD_OUT_PRODUCT: (state, payload) => {
    return api.post(process.env.APP_URL + `vote-if-product-not-available`, payload).then((response) => {
      return response && response.data
    }).catch(error => {
      console.log(error)
      throw error
    })
  },
  FETCH_RATINGS: ({ state, commit }, payload) => {
    return api.post(`${process.env.APP_URL}product-detail-ratings/${payload.id}`).then(response => {
      commit('SET_RATINGS', response.data.ratings)
    }).catch((error) => {
      console.log(error)
      throw error
    })
  }
}

// mutations
const mutations = {
  SET_PRODUCT_INFO: (state, pId) => {
    state.productId = pId
  },
  SET_COLORS: (state, colors) => {
    state.colorOptions = colors
  },
  ADD_PRODUCT_ID: (state, payload) => {
    const newId = payload && payload.newId
    if (!newId) return
    let recentViewProducts = Vue.ls.get('recentViewProducts', [])
    if (recentViewProducts.length >= 10) {
      recentViewProducts.pop()
    }
    if (!recentViewProducts.includes(newId)) {
      recentViewProducts = recentViewProducts.filter(obj => +obj.id !== newId)
      recentViewProducts.unshift({
        id: String(newId),
        gender_type: payload.product.gender_type,
        platform: payload.product.platform
      })
    }
    Vue.ls.set('recentViewProducts', recentViewProducts)
  },
  RESET_FILTERS: (state) => {
    state._filters = { 'color': [], 'size': [], 'tags': [], 'genre': [], 'sort': 'POPULARITY', 'cats': [] }
  },
  RESET_FOOTER_TEXT: (state) => {
    state.footerText = ''
    state.footerTextTitle = ''
    state.popularSearch = ''
    state.shopNow = ''
  },
  setProducts: (state, products) => {
    state.all = products
  },
  SET_ARTIST_PRODUCTS: (state, data) => {
    // state.all.push.apply(state.all, data.products)
    state.all = data.products
    state.totalPages = data.totalPages
    if (!data.products) {
      state.busy = true
    }
  },
  SET_ARTIST: (state, artist) => {
    state.artist = artist
    state.footerText = artist.description
    state.footerTextTitle = artist.firstname
    state.popularSearch = artist.popular_search
    state.shopNow = artist.shop_now
  },
  SET_TAG: (state, tag) => {
    state.tag = tag
    state.footerTextTitle = tag.name
    state.footerText = tag.footer_text
    state.popularSearch = tag.popular_search
    state.shopNow = tag.shop_now
  },
  SET_CATEGORY: (state, category) => {
    state.category = category
    state.footerText = category.footer_text
    state.footerTextTitle = category.breadcrum_title
    state.popularSearch = category.popular_search
    state.shopNow = category.shop_now
  },
  SET_DEFAULT_CATALOG: (state) => {
    state.all = []
    state.busy = false
    state._filters = { 'color': [], 'size': [], 'tags': [], 'genre': [], 'sort': 'DEFAULT', 'cats': [] }
    state.pageno = 1
    state.totalPages = 0
  },
  SET_FILTERS: (state, filters) => {
    state._filters = filters
  },
  SET_FOOTER_TEXT: (state, payload) => {
    state.footerText = payload.text
    state.footerTextTitle = payload.title
    state.popularSearch = payload.popular_search
    state.shopNow = payload.shop_now
  },
  SET_PAGE_NO: (state, pageno) => {
    state.pageno = pageno
  },
  SET_PRODUCTS: (state, data) => {
    // state.all.push.apply(state.all, data.products)
    state.all = data.products
    state.totalPages = data.pagination.totalPages
    // let prod = []
    // prod.push(data.products)
    // state.all = prod
    if (!data.products) {
      state.busy = true
    }
  },
  SET_QUERY: (state, payload) => {
    state.gqlQuery = payload
  },
  SET_PRODUCT: (state, product) => {
    localStorage.setItem('you may be interested', product.id)
    state.product = product
    state.product_slug = product.product_slug
    state.prod_type = product.prod_type
    state.prod_id = product.id
    state.backProductPricing.price = product.price
    state.backProductPricing.exclusive_price = product.exclusive_price
    state.backProductPricing.spl_price = product.spl_price
    state.notFound = false
    state.isLoading = false
  },
  RESET_PRODUCT_DETAIL: state => {
    state.product = {}
    state.product_slug = ''
    state.prod_type = ''
    state.prod_id = ''
  },
  RESET_LISTING: state => {
    state.all = ''
    state.totalPages = ''
    state.product.listbox = ''
    state.product.metadata = ''
  },
  SET_PRODUCT_STATE: (state, productState) => {
    state.productState = productState
  },
  SET_PRODUCTS_TO_DEFAULT: (state) => {
    let newstate = Object.assign({}, state.all)
    state.all = newstate.all = []
    state.totalPages = 0
    state = Object.assign(state, initialState())
  },
  SET_DEFAULT_BUSY: (state) => {
    state.busy = false
  },
  GET_RELATED_PRODUCTS: (state, data) => {
    state.relatedProducts = data.relatedProducts
    state.alsoAvailable = data.alsoAvailable
  },
  SET_NOT_FOUND: (state) => {
    state.notFound = true
    state.isLoading = false
  },
  SET_NOT_FOUND_FALSE: (state) => {
    state.notFound = false
  },
  SET_LOADING: (state) => {
    state.isLoading = true
  },
  UNSET_LOADING: (state) => {
    state.isLoading = false
  },
  CROSS_SELL_PRODUCTS: (state, data) => {
    state.crossSellProducts = data
  },
  SET_PLP_TIMER_DATA: (state, data) => {
    state.plpTimer = data
  },
  SET_PLP_MOCKUP_TAGS: (state, data) => {
    state.plpMockUpTags = data
  },
  SET_PDP_MOCKUP_TAG: (state, data) => {
    state.pdpMockUpTag = data
  },
  SET_BANNER_DATA: (state, data) => {
    state.banners = data
  },
  SET_HOME_SCREEN_DATA: (state, data) => {
    state.homeScreenData = data
  },
  SET_DELIVERY_DETAILS_FROM_PINCODE: (state, data) => {
    state.pincodeDeliveryDetails = data
  },
  GET_DONATIONS: (state, data) => {
    state.donation = data
  },
  SET_PDP_PRODUCT_RECOMMENDATION: (state, data) => {
    state.pdpProductRecommData = data
  },
  SET_RECOMMENDED_NEW_ARRIVALS_DATA: (state, data) => {
    state.recommNewArrivalsData = [...data]
  },
  SET_RECOMMENDED_TOP_SELLING_DATA: (state, data) => {
    state.recommTopSellingData = [...data]
  },
  MODIFY_COMBO_PRICE: (state, data) => {
    state.product.price = data.price
    state.product.exclusive_price = data.exclusive_price
    state.product.spl_price = data.spl_price
  },
  MODIFY_COMBO_PRICE_RESET: (state) => {
    state.product.price = state.backProductPricing.price
    state.product.exclusive_price = state.backProductPricing.exclusive_price
    state.product.spl_price = state.backProductPricing.spl_price
  },
  SET_NO_PRODUCT_DATA_LIST: (state, payload) => {
    state.noProductDataList = payload
  },
  SET_CROSS_SELL_PDP_LISTING: (state, payload) => {
    state.crossSellPdpListing = payload
  },
  SET_THANKYOU_PAGE_SUGGESTIN_LISTING: (state, payload) => {
    state.topSellingThakyouListing = payload
  },
  SET_FREQUENT_BOUGHT_PDP_LISTING: (state, payload) => {
    state.frequentlyBoughtPdpListing = payload
  },
  SET_PERSONALIZED_WIDGET_LISTING: (state, payload) => {
    state.personalizedWidgetListing = payload
  },
  SET_RATINGS: (state, payload) => {
    state.ratingsData = payload
  },
  SET_OVERLAY_FREEZE: (state, option) => {
    state.overlayFreeze = option
  }
}

export default {
  state,
  getters,
  actions,
  mutations
}
