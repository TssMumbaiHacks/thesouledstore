import api from '../../api/api'
import router from '../../router'
import Vue from 'vue'
import Axios from 'axios'

const order = {
  state: {
    orderDetail: [],
    userInfo: {},
    reasons: [],
    returnResponse: {},
    trackData: [],
    returnModeForStatic: '',
    popupratingdetails: {},
    orderRefundModes: [],
    refundModeForStatic: '',
    orderRefundBankList: [],
    orderInvoice: '',
    isPromoteExchangeClick: false,
    orderProductVariantData: []
  },
  getters: {
    orderDetail: state => state.orderDetail,
    userInfo: state => state.userInfo,
    reasons: state => state.reasons,
    returnResponse: state => state.returnResponse,
    trackData: state => state.trackData,
    returnModeForStatic: state => state.returnModeForStatic,
    popupratingdetails: state => state.popupratingdetails,
    orderRefundModes: state => state.orderRefundModes,
    refundModeForStatic: state => state.refundModeForStatic,
    orderRefundBankList: state => state.orderRefundBankList,
    orderInvoice: state => state.orderInvoice,
    isPromoteExchangeClick: state => state.isPromoteExchangeClick,
    orderProductVariantData: state => state.orderProductVariantData
  },
  actions: {
    GET_ORDER_DETAIL: (state, orderID) => {
      let token = Vue.ls.get('tss_token')
      state.commit('SET_LOADING', {rootState: true})
      api.post('order/cancel/' + orderID + '?isNewCancelText=1', {'is_ab_visible': true}, { headers: { Authorization: token } }).then((response) => {
        if (response && response.data && response.data.orders) {
          state.commit('SET_ORDER_DETAIL', response.data.orders)
        }
        if (response && response.data && response.data.userDetails) {
          state.commit('SET_USER_DETAIL', response.data.userDetails)
        }
        if (response && response.data && response.data.reasons) {
          state.commit('SET_REASONS', response.data.reasons)
        }
        if (response.data && response.data.orders && response.data.orders.length && response.data.orders[0].refund_modes) {
          state.commit('SET_ORDER_REFUND_MODES', response.data.orders[0].refund_modes)
        }
        state.commit('UNSET_LOADING', {rootState: true})
      }, error => {
        state.commit('UNSET_LOADING', {rootState: true})
        console.log(error)
      })
    },
    CANCEL_ORDER: (state, params) => {
      let token = Vue.ls.get('tss_token')
      api.post('cancel-order', params.order, { headers: { Authorization: token } }).then((response) => {
        params.vm.$dialog.alert(response.data.msg)
        if (response.data.delete_exclusive) {
          state.dispatch('CART_DATA')
        }
        router.push('/orders')
      }, error => {
        Vue.toasted.show((error && error.data && error.data.title) || (error && error.response && error.response.data && error.response.data.title), {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
        router.push('/orders')
        console.log(error)
      })
    },
    CANCEL_PRODUCT: (state, params) => {
      let token = Vue.ls.get('tss_token')
      api.post('cancel-order-line-item', params.order, { headers: { Authorization: token } }).then((response) => {
        params.vm.$dialog.alert(response.data.msg)
        if (response.data.delete_exclusive) {
          state.dispatch('CART_DATA')
        }
        router.push('/orders')
      }, error => {
        Vue.toasted.show((error && error.data && error.data.title) || (error && error.response && error.response.data && error.response.data.title), {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
        router.push('/orders')
        console.log(error)
      })
    },
    FETCH_RETURNABLE_PRODUCTS: ({ state, commit, rootState }, orderId) => {
      let token = Vue.ls.get('tss_token')
      Axios.post(process.env.APP_URL + 'orderrefund/return_status_check_new/', { order_id: orderId.toString(), isNewReturnExchangeText: true }, { headers: { Authorization: token }, params: {platform: 'WEB'} }).then((response) => {
        if (
          response &&
          response.data &&
          response.data.orders &&
          response.data.orders.length &&
          response.data.orders[0]
        ) {
          if (
            rootState &&
            rootState.user &&
            rootState.user &&
            rootState.user.hasProducts &&
            rootState.user.hasProducts.hasOwnProperty(orderId) &&
            rootState.user.hasProducts[orderId].orders
          ) {
            let updatedProducts = (rootState.user.hasProducts[orderId].orders).map(order => ({
              ...order,
              ...response.data.orders[0].products.find((orderReturn) => (order.product_id === orderReturn.prod_id))
            }))
            let existingHasProduct = rootState.user.hasProducts
            let updatedOrderObj = { ...rootState.user.hasProducts[orderId], orders: updatedProducts }
            let updatedHasProductData = { ...existingHasProduct, [orderId]: updatedOrderObj }
            commit('UPDATE_HAS_PRODUCTS', {...updatedHasProductData, updatedHasProduct: true}, { rootState: true })
          }
          commit('SET_ORDER_REFUND_MODES', response.data.orders && response.data.orders.length && response.data.orders[0].products)
          commit('SET_ORDER_REFUND_BANK_LIST', response.data.orders && response.data.orders.length && response.data.orders[0].bank_list)
        }
      }, error => {
        console.log(error)
      })
    },
    GET_RETURN_ORDER: (state, orderId) => {
      let token = Vue.ls.get('tss_token')
      state.commit('SET_RETURN_DATA', {})
      api.get(`orderrefund/order_return/?order_id=${orderId}`, {headers: {Authorization: token}}).then((response) => {
        if (response && response.data && response.data.status === 'SUCCESS') {
          state.commit('SET_RETURN_DATA', response.data)
        }
      }, error => {
        console.log(error)
      })
    },
    RETURN_ORDER: (state, returnReverseData) => {
      let token = Vue.ls.get('tss_token')
      return api.post(`orderrefund/order_return/`, returnReverseData, {headers: {Authorization: token}}).then((response) => {
        if (response && response.data && response.data.status) {
          Vue.toasted.show(response.data.message, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
        }
        return response.data
      }, error => {
        console.log(error)
        return error.response.data
      })
    },
    EXCHANGE_ORDER: (state, payload) => {
      let token = Vue.ls.get('tss_token')
      return api.post(`orderrefund/order_exchange/`, payload, {headers: {Authorization: token}}).then((response) => {
        if (response && response.data && response.data.status) {
          Vue.toasted.show(response.data.message, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
        }
        return response.data
      }, error => {
        console.log(error)
        if (error && error.data) {
          Vue.toasted.show(error.data.message || error.data.title, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
        }
      })
    },
    REVERSE_PICKUP_TRACKING: (state, reverseTrackData) => {
      let token = Vue.ls.get('tss_token')
      state.commit('SET_RETURN_TRACK_DATA', [])
      api.post(`orderrefund/track_return_order/`, {...reverseTrackData, isNewReturnExchangeText: true, isNewReturnExchangeTracking: true}, { headers: { Authorization: token } }).then((response) => {
        state.commit('SET_RETURN_TRACK_DATA', response.data)
      }, error => {
        console.log(error)
        Vue.toasted.show((error && error.data && error.data.title) || (error && error.response && error.response.data && error.response.data.title), {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      })
    },
    GET_REFUND_LINK: (state, orderPayload) => {
      let token = Vue.ls.get('tss_token')
      return api.post(`orderrefund/cashgram_resend_link/`, orderPayload, { headers: { Authorization: token } }).then((response) => {
        if (response && response.data && response.data.status) {
          Vue.toasted.show(response.data.message, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
        }
        return response.data
      }, error => {
        console.log(error)
        Vue.toasted.show(error.data.title || error.response.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      })
    },
    RETURN_REASON: (state, payload) => {
      api.get(`orderrefund/list_of_reason/?cat_id=${payload.categoryId}&reason_type=${payload.reasonType}`).then(res => {
        state.commit('SET_RETURN_REASON', res.data)
      }, error => {
        console.log(error)
        Vue.toasted.show(error.data.title || error.response.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      })
    },
    GET_PRODUCT_RATING_DETAILS: (state, product) => {
      let popupDetails = {
        'rating': product.rating,
        'id': product.id,
        'images': product.images,
        'name': product.name
      }
      state.commit('SET_PRODUCT_RATING', popupDetails)
    },
    GET_ORDER_INVOICE: (state, params) => {
      state.commit('SET_LOADING')
      let token = Vue.ls.get('tss_token')
      api.get(process.env.SOUL_V2 + 'invoicer/show', {headers: {Authorization: token}, params: {order_id: params.order_id}}).then(res => {
        state.commit('UNSET_LOADING')
        state.commit('SET_ORDER_INVOICE', res.data)
      }).catch(error => {
        state.commit('UNSET_LOADING')
        console.log(error)
      })
    },
    ORDER_PRODUCT_VARIANT_INFO: (state, payload) => {
      api.get(`orderrefund/get-prod-variants/${payload}`).then(res => {
        state.commit('SET_ORDER_PRODUCT_VARIANT_DATA', res && res.data)
      }, error => {
        console.log(error)
      })
    }
  },
  mutations: {
    SET_ORDER_DETAIL: (state, data) => {
      state.orderDetail = data
    },
    SET_USER_DETAIL: (state, data) => {
      state.userInfo = data
    },
    SET_REASONS: (state, data) => {
      state.reasons = data
    },
    SET_RETURN_DATA: (state, data) => {
      state.returnResponse = data
    },
    SET_RETURN_TRACK_DATA: (state, data) => {
      state.trackData = data
    },
    SET_RETURN_REASON: (state, data) => {
      state.reasons = data
    },
    SET_RETURN_MODE: (state, data) => {
      state.returnModeForStatic = data
    },
    SET_REFUND_MODE: (state, data) => {
      state.refundModeForStatic = data
    },
    SET_PRODUCT_RATING: (state, data) => {
      state.popupratingdetails = data
    },
    SET_ORDER_REFUND_MODES: (state, payload) => {
      state.orderRefundModes = payload
    },
    SET_ORDER_REFUND_BANK_LIST: (state, payload) => {
      state.orderRefundBankList = payload
    },
    SET_ORDER_INVOICE: (state, payload) => {
      state.orderInvoice = payload
    },
    PROMOTE_EXCHANGE_OVER_RETURN: (state, payload) => {
      state.isPromoteExchangeClick = payload
    },
    SET_ORDER_PRODUCT_VARIANT_DATA: (state, payload) => {
      state.orderProductVariantData = payload
    }
  }
}

export default order
