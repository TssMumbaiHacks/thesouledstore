import api from '../../api/api'
import Axios from 'axios'
import Vue from 'vue'

const prodColors = {
  170193: {
    color: '#b2737d'
  },
  170196: {
    color: '#393941'
  },
  170195: {
    color: '#979eaa'
  },
  170194: {
    color: '#b5d2dc'
  },
  170197: {
    color: '#ee9d32'
  },
  170700: {
    color: '#768980'
  },
  170192: {
    color: '#768980'
  }
}

const various = {
  state: {
    artistFilter: [],
    loading: false,
    disable: false,
    btnDisable: false,
    ourArtists: [],
    stores: [],
    ward_list: [],
    assitant: '',
    search_products: [],
    search_type: '',
    search_sumarry: '',
    search_input: '',
    artistSales: [],
    hideFooter: false,
    survey: {},
    userCategory: '',
    topsellingList: '',
    exclusiveSavings: '',
    lifetimeExclusiveSavings: '',
    wildlifeProducts: [],
    browsingCounting: 0,
    showAppInstPopup: false,
    todaysDate: '',
    appPopUpCount: 0,
    bannerPlcaeHolderData: [],
    membershipData: [],
    sizeChartData: [],
    dailyDrop: [],
    topBanner: [],
    multipleCategory: [],
    singleCategory: [],
    categoryProducts: [],
    catLanding: [],
    storeDetails: [],
    dailyDropForPDP: {},
    campaignData: [],
    navMenuData: [],
    webcategory: '',
    categoryPageProducts: {},
    filterLandingData: {},
    productWiseSizeChartData: {},
    stayAtHomeData: {},
    paymentOffersData: {},
    googleGeoCodeAddressData: {},
    isComboActive: '',
    showInitialExcPopupOnPdp: '',
    popularCategoriesData: {},
    memberSavingsTxt: '',
    nonMemberSavingsTxt: '',
    faqs: [],
    disableWishlist: '',
    disableEmailLogin: '',
    shopTheLookData: {},
    supimaLandingData: {},
    isLandingPageSubMenu: false,
    activeWearLandingData: {},
    welcomeOffer: '',
    hyperLocalData: {},
    productListingHeader: {},
    productListingStyle: {},
    productDetailHeader: {},
    mobileLoginBackgroundBanner: [],
    isBirthdayMonth: '',
    npsFeedback: {},
    isRepeatedUser: '',
    globalBannerPlaceholder: '',
    globalSettingsKeys: []
  },
  getters: {
    loading: state => state.loading,
    disable: state => state.disable,
    ourArtists: state => state.ourArtists,
    stores: state => state.stores,
    search_products: state => state.search_products,
    ward_list: state => state.ward_list,
    assitant: state => state.assitant,
    search_type: state => state.search_type,
    search_sumarry: state => state.search_sumarry,
    search_input: state => state.search_input,
    artistFilter: state => state.artistFilter,
    artistSales: state => state.artistSales,
    hideFooter: state => state.hideFooter,
    userCategory: state => state.userCategory,
    topsellingList: state => state.topsellingList,
    exclusiveSavings: state => state.exclusiveSavings,
    lifetimeExclusiveSavings: state => state.lifetimeExclusiveSavings,
    browsingCounting: state => state.browsingCounting,
    showAppInstPopup: state => state.showAppInstPopup,
    todaysDate: state => state.todaysDate,
    appPopUpCount: state => state.appPopUpCount,
    bannerPlcaeHolderData: state => state.bannerPlcaeHolderData,
    membershipData: state => state.membershipData,
    sizeChartData: state => state.sizeChartData,
    dailyDrop: state => state.dailyDrop,
    topBanner: state => state.topBanner,
    multipleCategory: state => state.multipleCategory,
    singleCategory: state => state.singleCategory,
    categoryProducts: state => state.categoryProducts,
    catLanding: state => state.catLanding,
    storeDetails: state => state.storeDetails,
    dailyDropForPDP: state => state.dailyDropForPDP,
    campaignData: state => state.campaignData,
    navMenuData: state => state.navMenuData,
    webcategory: state => state.webcategory,
    categoryPageProducts: state => state.categoryPageProducts,
    filterLandingData: state => state.filterLandingData,
    productWiseSizeChartData: state => state.productWiseSizeChartData,
    stayAtHomeData: state => state.stayAtHomeData,
    paymentOffersData: state => state.paymentOffersData,
    googleGeoCodeAddressData: state => state.googleGeoCodeAddressData,
    isComboActive: state => state.isComboActive,
    showInitialExcPopupOnPdp: state => state.showInitialExcPopupOnPdp,
    popularCategoriesData: state => state.popularCategoriesData,
    memberSavingsTxt: state => state.memberSavingsTxt,
    nonMemberSavingsTxt: state => state.nonMemberSavingsTxt,
    faqs: state => state.faqs,
    disableWishlist: state => state.disableWishlist,
    disableEmailLogin: state => state.disableEmailLogin,
    shopTheLookData: state => state.shopTheLookData,
    supimaLandingData: state => state.supimaLandingData,
    isLandingPageSubMenu: state => state.isLandingPageSubMenu,
    activeWearLandingData: state => state.activeWearLandingData,
    welcomeOffer: state => state.welcomeOffer,
    hyperLocalData: state => state.hyperLocalData,
    productListingHeader: state => state.productListingHeader,
    productListingStyle: state => state.productListingStyle,
    productDetailHeader: state => state.productDetailHeader,
    mobileLoginBackgroundBanner: state => state.mobileLoginBackgroundBanner,
    isBirthdayMonth: state => state.isBirthdayMonth,
    npsFeedback: state => state.npsFeedback,
    isRepeatedUser: state => state.isRepeatedUser,
    globalBannerPlaceholder: state => state.globalBannerPlaceholder,
    getGlobalSettingKeys: state => state.globalSettingsKeys
  },
  actions: {
    GET_ASSISTANT: (state, payload) => {
      api.post('tryon', payload, {headers: {Authorization: Vue.ls.get('tss_token')}}).then(response => {
        console.log(response.response, 'response.closet_types')
        state.commit('SET_ASSISTANT', response.data.url)
      }, error => {
        console.log(error)
      })
    },
    GET_WARD_LIST: (state, payload) => {
      api.post('user_closets', payload, {headers: {Authorization: Vue.ls.get('tss_token')}}).then(response => {
        console.log(response.data.closet_types, 'response.closet_types')
        state.commit('SET_WARD_LIST', response.data.closet_types)
      }, error => {
        console.log(error)
      })
    },
    GET_STORES: (state, payload) => {
      api.get('stores', payload, {headers: {Authorization: Vue.ls.get('tss_token')}}).then(response => {
        state.commit('SET_STORE_DATA', response.data.object.stores)
      }, error => {
        console.log(error)
      })
    },
    SEARCH_TEXT: (state, payload) => {
      api.post('text', payload, {headers: {Authorization: Vue.ls.get('tss_token')}}).then(response => {
        state.commit('SET_SEARCH_PRODUCTS', response.data.products)
        state.commit('SET_SEARCH_TYPE', 'text')
        state.commit('SET_SEARCH_SUMARRY', response.data.summary)
        state.commit('SET_SEARCH_INPUT', payload.query)
      }, error => {
        console.log(error)
      })
    },
    ARTIST_FILTER: (state) => {
    },
    BTN_DISABLE: (state, flag) => {
      state.commit('BTN_DISABLE', flag)
    },
    LOADING: (state, flag) => {
      state.commit('LOADING', flag)
    },
    WEBCATEGORY: (state, data) => {
      state.commit('WEBCATEGORY', data)
    },
    OUR_ARTISTS: (state) => {
      api.get('ourartists').then((response) => {
        state.commit('OUR_ARTISTS', response.data)
      }, error => {
        console.log(error)
      })
    },
    ARTIST_SALES: (state, payload) => {
      state.commit('LOADING', true)
      api.post('sales/artist', payload, {headers: {Authorization: Vue.ls.get('tss_token')}}).then(response => {
        state.commit('SET_ARTIST_SALES', response.data)
        state.commit('LOADING', false)
      }, error => {
        console.log(error)
      })
    },
    RESET_ARTIST_SALES: (state) => {
      state.commit('RESET_ARTIST_SALES')
    },
    GET_SURVEY_QUESTION: (state, params) => {
      let token = Vue.ls.get('tss_token')
      let orderId = params.orderId
      state.commit('SET_SURVEY_QUESTION', [])
      if (orderId) {
        return api.get(`order/feedback?order_id=${orderId}`, {headers: {Authorization: token}}).then(response => {
          state.commit('SET_SURVEY_QUESTION', response.data[0])
          return response.data[0]
        }, error => {
          console.log(error.data.title)
          return {}
        })
      }
    },
    SURVEY: (state, params) => {
      let token = Vue.ls.get('tss_token')
      api.post('order/feedback', params.survey, {headers: {Authorization: token}}).then(response => {
        state.commit('SET_SURVEY_QUESTION', [])
        if (params.thankyouFeedback.feedback[0].answer !== '') {
          api.post('feedback', params.thankyouFeedback, {headers: {Authorization: token}}).then(response => {
            console.log('submitted successfully')
          }, error => {
            console.log(error.data.title)
          })
        }
      }, error => {
        console.log(error.data.title)
      })
    },
    THANK_YOU_FEEDBACK: (state, thankyouFeedback) => {
      let token = Vue.ls.get('tss_token')
      api.post('feedback', thankyouFeedback, {headers: {Authorization: token}, params: {platform: 'web'}}).then(response => {
        return response.data
      }, error => {
        console.log(error.data.title)
      })
    },
    HIDE_FOOTER: ({commit}, render) => {
      commit('RENDER_FOOTER', render)
    },
    GET_USER_CATEGORY: (state, params) => {
      let token = Vue.ls.get('tss_token')
      let orderId = params.orderId
      if (orderId) {
        api.get(`thank-you?order_id=${orderId}`, {headers: {Authorization: token}, params: {payment: 'web', platform: 'web'}}).then(response => {
          state.commit('SET_USER_CATEGORY', response.data.user_category)
          state.commit('MOENGAGE_EVENT', {
            eventName: 'MOENGAGE_MEMBER_DISCOUNT',
            payload: {
              User_ID: Vue.ls.get('userID'),
              Order_Id: orderId,
              Member_Discount: response.data.member_discount
            }
          })
          state.commit('SET_EXCLUSIVE_SAVING', response.data.exclusive_saving)
          state.commit('SET_LIFETIME_EXCLUSIVE_SAVING', response.data.life_time_exclusive_savings.exclusive_savings)
          state.commit('UNSET_LOADING', {rootState: true})
          state.commit('SET_IS_REPEATED_USER', response.data.repeat_user)
        }, error => {
          state.commit('UNSET_LOADING', {rootState: true})
          console.log(error.data.title)
        })
      }
    },
    GET_TOPSELLING_LIST: ({ commit }) => {
      let query = `{
        listing(
            page: 1,
            size: 20,
            category: [149, 598, 638, 700, 704, 709],
            sort: POPULARITY,
            artist: []
            tags: [],
            filters:{
              price: []
            }
            ){
          products{
            id
            product
            images
            product_slug: productSlug
          }
        }
      }`

      let token = Vue.ls.get('tss_token')
      let localcart = Vue.ls.get('localcart')

      return api.post('graphql', { 'query': query, localcart, 'is_ab_visible': true }, { headers: { Authorization: token } }).then((response) => {
        commit('SET_TOPSELLING_LIST', response.data.data.listing)
      }, error => {
        Vue.toasted.show(error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      })
    },
    GET_WILDLIFE_PRODUCTS: ({ commit }) => {
      let query = `{
        listing(
            page: 1,
            size: 72,
            category: [],
            sort: DEFAULT,
            artist: []
            tags: ["save-their-souls"],
            filters:{
              price: []
            }
            ){
          products{
            id
            product
            artist{name}
            category{name}
            price
            stock
            prodQty
            splPrice
            exclusivePrice
            images
            product_slug: productSlug
          }
        }
      }`

      let token = Vue.ls.get('tss_token')
      let localcart = Vue.ls.get('localcart')

      return api.post('graphql', { 'query': query, localcart, 'is_ab_visible': true }, { headers: { Authorization: token } }).then((response) => {
        let wildLifeProd = response.data.data.listing.products.filter(prod => {
          if (Object.keys(prodColors).includes(prod.id)) {
            prod.color = prodColors[parseInt(prod.id)].color
            return prod
          }
        })
        commit('SET_WILDLIFE_PRODUCTS', wildLifeProd)
        return wildLifeProd
      }, error => {
        Vue.toasted.show(error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
        return []
      })
    },
    GET_BANNERS_DATA_FROM_MOBILE_CMS: (state, params) => {
      return Axios.get(process.env.MOBILE_CMS_URL + 'banner/placeholder').then((response) => {
        if (response && response.data && response.data.length) {
          state.commit('SET_BANNER_DATA_FROM_MOBILE_CMS', response.data)
          return response.data
        }
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_MEMBERSHIP_DATA: (state, params) => {
      let apiUrl = 'homescreen/v3'
      const getSelectedCountry = Vue.ls.get('selectedCountryAddress')
      const countryId = getSelectedCountry ? getSelectedCountry.countryId : process.env.IND_COUNTRY_ID
      apiUrl = apiUrl + '?country_id=' + countryId
      const token = Vue.ls.get('tss_token') || null
      api.get(process.env.MOBILE_CMS_URL + apiUrl + '&is_ab_visible=true', { headers: { Authorization: token } }).then(response => {
        if (response && response.data) {
          state.commit('SET_MEMBERSHIP_DATA', response.data)
        }
      })
    .catch((error) => {
      console.log(error)
    })
    },
    GET_SIZE_CHART_DATA: (state) => {
      return Axios.get(process.env.MOBILE_CMS_URL + 'product/sizechart/web').then((response) => {
        if (response && response.data && response.data.data && response.data.data.length) {
          state.commit('SET_SIZE_CHART_DATA', response.data.data)
          return response.data
        }
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_DAILY_DROP_DATA: (state) => {
      state.commit('LOADING', true)
      return Axios.get(process.env.MOBILE_CMS_URL + 'product/daily_drop').then((response) => {
        state.commit('LOADING', false)
        if (response && response.data && response.data.length) {
          let dailyDropNewObj = {}
          response.data.map(item => {
            dailyDropNewObj[item.product_slug] = item
          })
          state.commit('SET_DAILY_DROP_DATA_FOR_PDP', dailyDropNewObj)
          state.commit('SET_DAILY_DROP_DATA', response.data)
          return response.data
        }
      }, error => {
        console.log(error)
        state.commit('LOADING', false)
      })
    },
    GET_CAT_COLLECTION_DATA: (state) => {
      state.commit('LOADING', true)
      return Axios.get(process.env.MOBILE_CMS_URL + 'category-page').then((response) => {
        if (response && response.data && response.data && Object.keys(response.data).length) {
          state.commit('LOADING', false)
          const { TopBanner = [], MultipleCategory = [], SingleCategory = [], CategoryProducts = [] } = response.data.winter_data.category_page
          const { CategoryLanding = [] } = response.data.winter_data.category_landing
          state.commit('SET_TOP_BANNER', TopBanner || [])
          state.commit('SET_MULTIPLE_CAT', MultipleCategory || [])
          state.commit('SET_SINGLE_CAT', SingleCategory || [])
          state.commit('SET_CAT_PRODUCTS', CategoryProducts || [])
          state.commit('SET_CAT_LANDING', CategoryLanding || [])
          state.commit('SET_CATEGORY_PAGE_PRODUCTS', response.data.winter_data.category_page || {})
          return response.data
        }
      }, error => {
        state.commit('LOADING', false)
        console.log(error)
        return {}
      })
    },
    GET_STORE_DETAILS_DATA: (state) => {
      return Axios.get(process.env.MOBILE_CMS_URL + 'faq/store-near-me').then((response) => {
        if (response && response.data && response.data.data && response.data.data.length) {
          let storeData = response.data.data.map(store => {
            return {...store,
              address: store && store.address && store.address.split('\\n'),
              web_address: store && store.web_address && store.web_address.split('\\n')
            }
          })
          state.commit('SET_STORE_DETAILS_DATA', storeData)
          return response.data
        }
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_CAMPAIGN_UI_DATA: (state) => {
      return Axios.get(process.env.MOBILE_CMS_URL + 'faq/campaign-ui').then((response) => {
        if (response && response.data && response.data.data && response.data.data.length) {
          state.commit('SET_CAMPAIGN_UI_DATA', response.data.data)
          return response.data.data
        }
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_NAVMENU_DATA: (state) => {
      const getSelectedCountry = Vue.ls.get('selectedCountryAddress')
      const countryId = getSelectedCountry ? getSelectedCountry.countryId : process.env.IND_COUNTRY_ID
      let url = process.env.MOBILE_CMS_URL + 'web_menu/webmenu?country_id=' + countryId
      return Axios.get(url).then((response) => {
        if (response && response.data && response.data) {
          state.commit('SET_NAVMENU_DATA', response.data.data)
          return response.data
        }
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_FILTER_LANDING_DATA: (state, params) => {
      return Axios.get(process.env.MOBILE_CMS_URL + 'filterlanding/', { params }).then((response) => {
        const data = (response.data && response.data['Filter Landing']) || {}
        state.commit('SET_FILTER_LANDING_DATA', data)
        return response.data
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_PRODUCT_WISE_SIZE_CHART_DATA: (state, {params, showSizeChartFallback, isVarientSelectedSizeChart}) => {
      return Axios.get(process.env.MOBILE_CMS_URL_V3 + 'product/newsizechart', { params }).then((response) => {
        state.commit('SET_PRODUCT_WISE_SIZE_CHART_DATA', response && response.data)
        return response.data
      }).catch(error => {
        if (showSizeChartFallback) {
          state.commit('SET_PRODUCT_WISE_SIZE_CHART_DATA', {showSizeChartFallback: true})
        } else {
          if (!isVarientSelectedSizeChart && error && error.response && error.response.data) {
            Vue.toasted.show(error.response.data.title || error.response.data.message, {
              theme: 'primary',
              className: 'toasted-customred',
              position: 'top-right',
              duration: 5000
            })
          }
        }
        return {}
      })
    },
    GET_STAY_AT_HOME_DATA: (state) => {
      return Axios.get(process.env.MOBILE_CMS_URL + 'stay_at_home').then((response) => {
        const data = (response.data && response.data['stay_at_home_data']) || {}
        state.commit('SET_STAY_AT_HOME_DATA', data)
        return response.data
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_PAYMENT_OFFERS_DATA: (state) => {
      return Axios.get(process.env.MOBILE_CMS_URL + 'product/cashback').then((response) => {
        const data = (response && response.data) || {}
        state.commit('SET_PAYMENT_OFFERS_DATA', data)
        return response.data
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_GOOGLE_LOCATION_ADDRESS_DATA: (state, params) => {
      return Axios.get(process.env.APP_URL + 'get-address?lat=' + params.latitude + '&long=' + params.longitude, {headers: {Authorization: Vue.ls.get('tss_token')}}).then((response) => {
        const data = (response && response.data) || {}
        state.commit('SET_GOOGLE_LOCATION_ADDRESS_DATA', data)
        return response.data
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_POPULAR_CATEGORIES_DATA: (state) => {
      return Axios.get(process.env.MOBILE_CMS_URL + 'faq/popular_category').then((response) => {
        const data = (response && response.data) || {}
        state.commit('SET_POPULAR_CATEGORIES_DATA', data)
        return response.data
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_FAQS: (state, countryID) => {
      const params = {
        platform_type: 'web',
        ...(countryID && { country_id: countryID })
      }
      return Axios.get(process.env.MOBILE_CMS_URL + 'faq', {params}).then((response) => {
        const data = response && response.data && response.data.data && response.data.data[0] && response.data.data[0]['FAQ_data']
        state.commit('SET_FAQS', data)
        return response.data
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_SHOP_THE_LOOK_DATA: (state, params) => {
      return api.get(process.env.MOBILE_CMS_URL + 'shopthelook').then((response) => {
        const data = response.data && response.data['Shop The Look']
        state.commit('SET_SHOP_THE_LOOK_DATA', data)
        return response.data
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_SUPIMA_LANDING_DATA: (state) => {
      return api.get(process.env.MOBILE_CMS_URL + 'supima').then((response) => {
        const data = (response && response.data && response.data['supima_data']) || {}
        state.commit('SET_SUPIMA_LANDING_DATA', data)
        return response.data
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_MOBILE_LOGIN_BANNER_DATA: (state) => {
      return Axios.get(process.env.MOBILE_CMS_URL + 'banner/loginbackground').then((response) => {
        const data = (response && response.data && response.data.length && response.data) || {}
        state.commit('SET_MOBILE_LOGIN_BANNER_DATA', data)
        return response.data
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_WELCOME_OFFER: (state, payload) => {
      state.commit('LOADING', true)
      return api.post('welcomeoffer', payload).then((response) => {
        const data = response && response.data
        state.commit('SET_WELCOME_OFFER', data)
        Vue.ls.set('welcome_offer_user', payload && payload.email)
        state.commit('LOADING', false)
        return response.data
      }, error => {
        state.commit('LOADING', false)
        console.log(error)
        return {}
      })
    },
    GET_ACTIVE_WEAR_LANDING_DATA: (state) => {
      return api.get(process.env.MOBILE_CMS_URL + 'activewear').then((response) => {
        const data = (response && response.data && response.data['activeWear_data']) || {}
        state.commit('SET_ACTIVE_WEAR_LANDING_DATA', data)
        return response.data
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_HYPERLOCAL_DATA: (state, payload) => {
      return api.post('check-hyperlocal-availability', payload, {headers: {Authorization: Vue.ls.get('tss_token')}}).then((response) => {
        return response.data
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_FIREBASE_DYNAMIC_LINK_DATA: (state, payload) => {
      return api.post('firebase-dynamic-link', payload, {headers: {'Content-Type': 'application/json'}}).then((response) => {
        console.log('deep: ', response.data)
        return response && response.data && response.data.object
      }, error => {
        console.log(error)
        return {}
      })
    },
    GET_FEEDBACK: (state, payload) => {
      console.log('token', payload.token)
      return api.get(`${process.env.SOUL_V2}netpromoterscore/nps_new_feedback/?&score=${payload.score}`, {headers: {Authorization: payload.token}}).then((response) => {
        console.log('response', response)
        state.commit('SET_FEEDBACK', response && response.data)
        return response.data
      }).catch((err) => {
        err && err.data && err.data.redirect_to && err.data.redirect_to.length ? window.location.replace(err.data.redirect_to) : ''
      })
    },
    GET_FEEDBACK_DATA: (state, payload) => {
      return api.post(`${process.env.SOUL_V2}netpromoterscore/nps_new_feedback/`, payload.data, {headers: {Authorization: payload.token}}).then((response) => {
        console.log('deep fedback: ', response.data)
        return response.data
      }, error => {
        console.log(error)
        return {}
      }).catch((err) => {
        err && err.data && err.data.redirect_to && err.data.redirect_to.length ? window.location.replace(err.data.redirect_to) : ''
      })
    },
    GLOBAL_GET_BANNERS_DATA: (state, { countryId, configKeys }) => {
      return Axios.get(`${process.env.MOBILE_CMS_URL}global_settings?country_id=${countryId}&config_key=${configKeys.join(',')}`).then((response) => {
        state.commit('SET_BANNER_DATA_GLOBAL', response.data)
        return response.data
      }, error => {
        console.log(error)
        return {}
      })
    },
    WHATSMORE_TRACKING: (state, payload) => {
      return Axios.post(process.env.WHATMORE_TRACKING_ENDPOINT, payload, {headers: {Authorization: 'Bearer ' + process.env.WHATMORE_TRACKING_TOKEN}}).then((response) => {
        return true
      }, error => {
        console.log(error)
        return {}
      })
    }
  },
  mutations: {
    SET_SEARCH_PRODUCTS: (state, payload) => {
      state.search_products = payload
    },
    SET_SEARCH_TYPE: (state, payload) => {
      state.search_type = payload
    },
    SET_SEARCH_SUMARRY: (state, payload) => {
      state.search_sumarry = payload
    },
    SET_SEARCH_INPUT: (state, payload) => {
      state.search_input = payload
    },
    SET_STORE_DATA: (state, payload) => {
      state.stores = payload
    },
    SET_WARD_LIST: (state, payload) => {
      state.ward_list = payload
    },
    SET_ASSISTANT: (state, payload) => {
      state.assitant = payload
    },
    RENDER_FOOTER: (state, render) => {
      state.hideFooter = render
    },
    BTN_DISABLE: (state, flag) => {
      state.btnDisable = flag
    },
    LOADING: (state, flag) => {
      state.loading = flag
    },
    SET_SURVEY_QUESTION: (state, payload) => {
      state.survey = payload
    },
    OUR_ARTISTS: (state, artists) => {
      state.ourArtists = artists
    },
    SET_ARTIST_SALES: (state, sales) => {
      state.artistSales = sales
    },
    RESET_ARTIST_SALES: (state) => {
      state.artistSales = []
    },
    SET_USER_CATEGORY: (state, payload) => {
      state.userCategory = payload
    },
    SET_IS_REPEATED_USER: (state, payload) => {
      state.isRepeatedUser = payload
    },
    SET_TOPSELLING_LIST: (state, data) => {
      state.topsellingList = data
    },
    SET_EXCLUSIVE_SAVING: (state, payload) => {
      state.exclusiveSavings = payload
    },
    SET_LIFETIME_EXCLUSIVE_SAVING: (state, payload) => {
      state.lifetimeExclusiveSavings = payload
    },
    SET_WILDLIFE_PRODUCTS: (state, payload) => {
      state.wildlifeProducts = payload
    },
    SET_BROWSING_COUNT: (state, payload) => {
      state.browsingCounting = payload
    },
    SHOW_APP_INSTALL_POPUP: (state, payload) => {
      state.showAppInstPopup = payload
    },
    SET_TODAY_DATE: (state, payload) => {
      state.todaysDate = payload
    },
    SET_APP_POPUP_COUNT: (state, payload) => {
      state.appPopUpCount = payload
    },
    SET_BANNER_DATA_FROM_MOBILE_CMS: (state, payload) => {
      state.bannerPlcaeHolderData = payload
    },
    SET_MEMBERSHIP_DATA: (state, payload) => {
      state.membershipData = payload
    },
    SET_SIZE_CHART_DATA: (state, payload) => {
      state.sizeChartData = payload
    },
    SET_DAILY_DROP_DATA: (state, payload) => {
      state.dailyDrop = payload
    },
    SET_TOP_BANNER: (state, payload) => {
      state.topBanner = payload
    },
    SET_MULTIPLE_CAT: (state, payload) => {
      state.multipleCategory = payload
    },
    SET_SINGLE_CAT: (state, payload) => {
      state.singleCategory = payload
    },
    SET_CAT_PRODUCTS: (state, payload) => {
      state.categoryProducts = payload
    },
    SET_CAT_LANDING: (state, payload) => {
      state.catLanding = payload
    },
    SET_STORE_DETAILS_DATA: (state, payload) => {
      state.storeDetails = payload
    },
    SET_DAILY_DROP_DATA_FOR_PDP: (state, payload) => {
      state.dailyDropForPDP = payload
    },
    SET_CAMPAIGN_UI_DATA: (state, payload) => {
      state.campaignData = payload
    },
    SET_NAVMENU_DATA: (state, payload) => {
      state.navMenuData = payload
    },
    WEBCATEGORY: (state, data) => {
      state.webcategory = data
    },
    SET_CATEGORY_PAGE_PRODUCTS: (state, payload) => {
      state.categoryPageProducts = payload
    },
    SET_FILTER_LANDING_DATA: (state, payload) => {
      state.filterLandingData = payload
    },
    SET_PRODUCT_WISE_SIZE_CHART_DATA: (state, payload) => {
      state.productWiseSizeChartData = payload
    },
    SET_STAY_AT_HOME_DATA: (state, payload) => {
      state.stayAtHomeData = payload
    },
    SET_PAYMENT_OFFERS_DATA: (state, payload) => {
      state.paymentOffersData = payload
    },
    SET_GOOGLE_LOCATION_ADDRESS_DATA: (state, payload) => {
      state.googleGeoCodeAddressData = payload
    },
    SET_COMBO_ACTIVE: (state, flag) => {
      state.isComboActive = flag
    },
    ENABLE_EXCLUSIVE_POPUP_ON_PDP: (state, payload) => {
      state.showInitialExcPopupOnPdp = payload
    },
    SET_POPULAR_CATEGORIES_DATA: (state, payload) => {
      state.popularCategoriesData = payload
    },
    SET_MEMBER_SAVINGS_TXT: (state, payload) => {
      state.memberSavingsTxt = payload
    },
    SET_NON_MEMBER_SAVINGS_TXT: (state, payload) => {
      state.nonMemberSavingsTxt = payload
    },
    SET_FAQS: (state, payload) => {
      state.faqs = payload
    },
    DISABLE_WISHLIST: (state, flag) => {
      state.disableWishlist = flag
    },
    DISABLE_EMAIL_LOGIN: (state, flag) => {
      state.disableEmailLogin = flag
    },
    SET_SHOP_THE_LOOK_DATA: (state, payload) => {
      state.shopTheLookData = payload
    },
    SET_SUPIMA_LANDING_DATA: (state, payload) => {
      state.supimaLandingData = payload
    },
    SET_LANDING_PAGE_SUB_MENU: (state, flag) => {
      state.isLandingPageSubMenu = flag
    },
    SET_WELCOME_OFFER: (state, payload) => {
      state.welcomeOffer = payload
    },
    SET_MOBILE_LOGIN_BANNER_DATA: (state, payload) => {
      state.mobileLoginBackgroundBanner = payload
    },
    SET_ACTIVE_WEAR_LANDING_DATA: (state, payload) => {
      state.activeWearLandingData = payload
    },
    SET_PRODUCT_LISTING_HEADER: (state, payload) => {
      state.productListingHeader = payload
    },
    SET_PRODUCT_DETAIL_HEADER: (state, payload) => {
      state.productDetailHeader = payload
    },
    SET_PRODUCT_LISTING_STYLE: (state, payload) => {
      state.productListingStyle = payload
    },
    SET_BIRTHDAY_MONTH: (state, flag) => {
      state.isBirthdayMonth = flag
    },
    SET_FEEDBACK: (state, payload) => {
      state.npsFeedback = payload
    },
    SET_BANNER_DATA_GLOBAL: (state, payload) => {
      state.globalBannerPlaceholder = payload
    },
    SET_GLOBAL_SETTING_KEYS: (state, payload) => {
      state.globalSettingsKeys = payload
    }
  }
}
export default various
