import Vue from 'vue'
import api from '../../api/api'
import router from '../../router'
import store from '../../store'
import {isDesktop} from '@/assets/js/common'
const state = {
  namespaced: true,
  token: '',
  status: false,
  username: '',
  authError: '',
  loginModelBox: false,
  _loginBox: true,
  forgetBox: false,
  authLoading: false,
  otpValid: '',
  phoneNumber: '',
  emailid: '',
  activeLoginForm: 'generalLogin',
  activeRegisterForm: 'register',
  activeEmailLoginForm: 'emailLogin',
  sendOtpLoginDetails: '',
  attemptsMsg: '',
  isPosLogin: false,
  isCodCheckoutLogin: false
}

const getters = {
  isAuthenticated: state => !!state.token,
  authStatus: state => state.status,
  username: state => state.username,
  authError: state => state.authError,
  loginModelBox: state => state.loginModelBox,
  _loginBox: state => state._loginBox,
  forgetBox: state => state.forgetBox,
  successCallback: state => state.successCallback,
  authLoading: state => state.authLoading,
  activeLoginForm: state => state.activeLoginForm,
  otpValid: state => state.otpValid,
  phoneNumber: state => state.phoneNumber,
  emailid: state => state.emailid,
  activeEmailLoginForm: state => state.activeEmailLoginForm,
  activeRegisterForm: state => state.activeRegisterForm,
  sendOtpLoginDetails: state => state.sendOtpLoginDetails,
  attemptsMsg: state => state.attemptsMsg,
  isPosLogin: state => state.isPosLogin,
  isCodCheckoutLogin: state => state.isCodCheckoutLogin
}

const actions = {
  CHECK_AUTH: (state) => {
    let token = Vue.ls.get('tss_token')
    if (!token) {
      return
    }
    // verify token here
    state.commit('SET_AUTH')
  },
  AUTH_REQUEST: ({commit, dispatch, state}, payload) => {
    // encoding redirect params
    payload.redirect = encodeURI(payload.redirect)

    Vue.toasted.clear()
    payload.localcart = Vue.ls.get('localcart')
    payload.localwishlist = Vue.ls.get('localwishlist')
    commit('LOGIN_LOADER')
    api.post(process.env.APP_URL + 'email-tfa?platform=web', payload).then((response) => {
      commit('STOP_LOADING')
      if (response.data.is_otp_sent) {
        commit('SET_ACTIVE_EMAIL_LOGIN_FORM', 'verifyOtp')
        commit('SET_SEND_OTP_LOGIN_DETAILS', response.data)
        Vue.toasted.show(response.data.message, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      } else {
        dispatch('SET_LOGIN_DETAILS', {response, payload})
      }
    }).catch(error => {
      commit('STOP_LOADING')
      if (error.data) {
        commit('AUTH_ERROR', error)
        commit('GTAG_EVENT', {eventName: 'login_failed',
          payload: {
            login_failed_reason: error.data.title || error.data.message,
            login_method: 'Custom Login'
          }}
        )
        dispatch('TRACK_STORE_EVENT', {parent_event_name: 'login_event', event_name: 'login_failed', method: 'email', message: error.data.title || error.data.message})
        Vue.toasted.show(error.data.title || error.data.message, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      }
    })
  },
  SET_LOGIN_DETAILS_NEW: ({commit, dispatch, state}, {response, payload}) => {
    let userData = response.data
    console.log(userData, 'datadata12')
    commit('AUTH_SUCCESS_NEW', userData)
    Vue.toasted.show('You\'ve been successfully logged in.', {
      theme: 'primary',
      className: isDesktop() ? 'toasted-customred' : 'toasted-mobileDefault',
      position: isDesktop() ? 'top-right' : 'bottom-right',
      duration: 5000
    })
  },
  SET_LOGIN_DETAILS: ({commit, dispatch, state}, {response, payload}) => {
    let userData = response.data
    commit('AUTH_SUCCESS', userData)
    dispatch('ADD_CUSTOMER')
    Vue.toasted.show('You\'ve been successfully logged in.', {
      theme: 'primary',
      className: isDesktop() ? 'toasted-customred' : 'toasted-mobileDefault',
      position: isDesktop() ? 'top-right' : 'bottom-right',
      duration: 5000
    })
    // dispatch('WISHLIST_DATA')
    // dispatch('CT_WISHLIST_DATA')
    dispatch('USER').then((userRes) => {
      Vue.ls.set('email', userRes.email)
      let profileEventObj = {...userRes}
      !(profileEventObj.gender && profileEventObj.gender.length) ? delete profileEventObj.gender : ''
      profileEventObj.telephone === '' ? profileEventObj.telephone = '0000000000' : ''
      commit('GTAG_EVENT', {eventName: 'response.profile.payload',
        payload: {
          profile_response: profileEventObj,
          exclusive_user: this.get_exclusive_user
        }}
      )
      commit('GTAG_EVENT', {eventName: 'ct_login',
        payload: {
          profile_response: userRes,
          login_method: 'Custom Login'
        }}
      )
      dispatch('TRACK_STORE_EVENT', {parent_event_name: 'login_event', event_name: 'login_success', method: 'email'})
      commit('MOENGAGE_SET_USER', userRes)
      commit('MOENGAGE_EVENT', {
        eventName: 'LOGIN',
        payload: {
          'Full Name': String(userRes && userRes.firstname + userRes.lastname),
          'Phone Number': Number(userRes.telephone),
          Email: String(userRes.email),
          Status: 'successfull',
          Login_Type: 'Email Login'
        }
      })
      dispatch('TATVIC_EVENT', {eventName: 'LOGIN_SUCCESSFUL', payload: {LOGIN_MEDIUM: 'Email Id', USER_ID: userRes.user_id}})
    })
    if (Vue.ls.get('routeObj').previous === '') {
      Vue.ls.set('routeObj', {
        current: Vue.ls.get('routeObj').current,
        previous: 'Account Page'
      })
    }
    commit('GTAG_EVENT', {eventName: 'user.email.login', payload: {}})
    commit('CART_DATA', userData.cart)
    commit('WISHLIST_DATA', userData.wishlist)
    if (state.successCallback) {
      state.successCallback()
    }
    dispatch('SET_LOGINBOX', {flag: false})
    if (payload.redirect === '/cart') {
      if ((userData && userData.cart && userData.cart.products && userData.cart.products.items && payload.localcart && payload.localcart.products && payload.localcart.products.items && userData.cart.products.items.length > payload.localcart.products.items.length) || (userData.cart.giftvouchers && userData.cart.giftvouchers.items && payload.localcart.giftvouchers && payload.localcart.giftvouchers.items && userData.cart.giftvouchers.items.length > payload.localcart.giftvouchers.items.length)) {
        Vue.toasted.clear()
        Vue.toasted.show('You have products in your cart', {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 5000})
        commit('HAS_CART_DATA', true)
      }
      router.push(payload.redirect)
    } else if (payload.redirect === '/login') {
      router.push('/')
    } else if (payload.newTab === 'true') {
      let token = Vue.ls.get('tss_token')
      let email = Vue.ls.get('email')
      window.open(`${payload.redirect}${token}&user_email=${email}`, '_blank')
      router.push('/')
    } else {
      router.push(payload.redirect)
    }
    dispatch('SYNC_WIDGET_DATA', userData)
  },
  OTP_REQUEST: ({ commit, state }, payload) => {
    Vue.toasted.clear()
    commit('LOGIN_LOADER')
    return api.post(process.env.APP_URL + 'tfa-mob?platform=web', payload).then((response) => {
      state.phoneNumber = payload.telephone
      commit('SET_ACTIVE_LOGIN_FORM', 'mobileLogin')
      commit('STOP_LOADING')
      commit('SET_ATTEMPTS_MSG', '')
      Vue.toasted.show(response.data.msg, {
        theme: 'primary',
        className: isDesktop() ? 'toasted-customred' : 'toasted-mobileDefault',
        position: isDesktop() ? 'top-right' : 'bottom-right',
        duration: 3000
      })
      return response.data
    }).catch(error => {
      commit('STOP_LOADING')
      if (error.data) {
        Vue.toasted.show(error.data.title || error.data.message, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 3000
        })
      }
      if (error && error.status === 403) {
        const {currentRoute: {query}} = router
        if (payload && payload.is_shopper_login) {
          query.redirect = router.currentRoute.path
        }
        router.push({path: '/register', query: {...query}})
      }
    })
  },
  VERIFY_OTP_REGISTER: ({state, commit, dispatch, rootState}, {payload, redirectPayload}) => {
    commit('LOGIN_LOADER')
    payload.localcart = Vue.ls.get('localcart')
    payload.localwishlist = Vue.ls.get('localwishlist')
    return api.post('verify-otp-register', payload).then((response) => {
      let userData = response.data
      store.dispatch('TATVIC_EVENT', {eventName: 'REGISTER_SUBMIT', payload: { USER_ID: response.data.user_id }})
      Vue.toasted.show('Your account has been created successfully', {
        theme: 'primary',
        className: 'toasted-customred',
        position: 'top-right',
        duration: 5000
      })
      commit('STOP_LOADING')
      // dispatch('WISHLIST_DATA')
      // dispatch('CT_WISHLIST_DATA')
      commit('GTAG_EVENT', {eventName: 'FB_Registration', payload: {}})
      commit('AUTH_SUCCESS', userData)
      dispatch('USER').then((response) => {
        Vue.ls.set('email', response.email)
        let profileEventObj = {...response}
        !(profileEventObj.gender && profileEventObj.gender.length) ? delete profileEventObj.gender : ''
        profileEventObj.telephone === '' ? profileEventObj.telephone = '0000000000' : ''
        commit('GTAG_EVENT', {eventName: 'response.profile.payload',
          payload: {
            profile_response: profileEventObj,
            exclusive_user: this.get_exclusive_user
          }}
        )
        // commit('GTAG_EVENT', {eventName: 'ct_register',
        //   payload: {
        //     profile_response: response,
        //     register_method: 'Custom Registration'
        //   }}
        // )
        dispatch('TRACK_STORE_EVENT', {parent_event_name: 'login_event', event_name: 'register_success'})
        commit('MOENGAGE_SET_USER', response)
        const moengageLoginPayload = {
          'Full Name': String(response && response.firstname + ' ' + response.lastname),
          'Phone Number': Number(response.telephone),
          Email: String(response.email),
          Status: 'successfull'
        }
        commit('MOENGAGE_EVENT', {
          eventName: 'LOGIN',
          payload: {
            ...moengageLoginPayload
            // Login_Type: 'Facebook Login'
          }
        })
        commit('MOENGAGE_EVENT', {
          eventName: 'REGISTER',
          payload: {
            ...moengageLoginPayload,
            // 'Social login': 'Yes',
            Birthday: response.birthdate,
            Gender: response.gender
          }
        })
      })
      dispatch('ADD_CUSTOMER')
      commit('CART_DATA', userData.cart, {root: true})
      commit('WISHLIST_DATA', userData.wishlist)
      if (state.successCallback) {
        state.successCallback()
      }
      dispatch('SET_LOGINBOX', { flag: false })
      if (redirectPayload.redirect === '/cart') {
        if (userData.cart.products.items.length > payload.localcart.products.items.length || userData.cart.giftvouchers.items.length > payload.localcart.giftvouchers.items.length) {
          Vue.toasted.show('You have products in your cart', {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 5000})
          commit('HAS_CART_DATA')
        }
      }
      if (userData.is_first_time_login && redirectPayload.redirect === '/cart') {
        redirectPayload.redirect = encodeURI('/delivery-address')
        dispatch('VALIDATE_CHECKOUT', rootState, {root: true})
        router.push(redirectPayload.redirect)
      } else if (redirectPayload.newTab === 'true') {
        let token = Vue.ls.get('tss_token')
        let email = Vue.ls.get('email')
        window.open(`${redirectPayload.redirect}${token}&user_email=${email}`, '_blank')
        router.push('/')
      } else {
        router.push(redirectPayload.redirect)
      }
      dispatch('SYNC_WIDGET_DATA', userData)
    }).catch(error => {
      if (error.data) {
        dispatch('TRACK_STORE_EVENT', {parent_event_name: 'login_event', event_name: 'register_failed', message: error.data.title || error.data.message || error.data.msg})
        Vue.toasted.show(error.data.title || error.data.message || error.data.msg, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      }
      commit('STOP_LOADING')
    })
  },
  VERIFY_OTP_PROFILE: ({commit, dispatch}, payload) => {
    let token = Vue.ls.get('tss_token')
    commit('LOGIN_LOADER')
    return api.post(process.env.APP_URL + 'verify-otp-profile', payload, {headers: {Authorization: token}}).then((response) => {
      const user = response.data
      const userName = Vue.ls.get('tss_username')
      commit('USER', user)
      commit('AUTH_SUCCESS', {access_token: response.data.access_token, username: userName})
      Vue.toasted.show('Profile updated successfully', {
        theme: 'primary',
        className: 'toasted-customred',
        position: 'top-right',
        duration: 5000
      })
      commit('STOP_LOADING')
      dispatch('SYNC_WIDGET_DATA', {access_token: response.data.access_token, username: userName})
      return user
    }).catch(error => {
      commit('STOP_LOADING')
      if (error.data) {
        Vue.toasted.show(error.data.title || error.data.message, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      }
    })
  },
  VERIFY_OTP_LOGIN: ({commit, dispatch}, payload) => {
    const data = {
      ...payload,
      redirect: encodeURI(payload.redirect),
      localcart: Vue.ls.get('localcart')
    }
    commit('LOGIN_LOADER')
    return api.post(process.env.APP_URL + 'verify-otp-login', {telephone: payload.telephone, otp: payload.otp}).then((response) => {
      // save user data
      dispatch('SET_LOGIN_DETAILS', {response, payload: data})
      commit('STOP_LOADING')
      return response.data
    }).catch(error => {
      if (error.data) {
        Vue.toasted.show(error.data.title || error.data.message, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      }
      commit('STOP_LOADING')
    })
  },
  LOGIN_USER: ({commit, dispatch}, payload) => {
    const data = {
      email: payload.email,
      password: payload.password
    }
    return api.post(process.env.APP_URL + 'login', {email: payload.email, password: payload.password}).then((response) => {
      console.log(response, 'datadata')
      // save user data
      dispatch('SET_LOGIN_DETAILS_NEW', {response, payload: data})
      return response.data
    }).catch(error => {
      if (error.data) {
        Vue.toasted.show('Something went wrong', {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      }
    })
  },
  RESEND_REGISTER_OTP: ({commit}, payload) => {
    Vue.toasted.clear()
    commit('LOGIN_LOADER')
    return api.post('resend-otp-register', payload, { params: {platform: 'web'} }).then((response) => {
      commit('STOP_LOADING')
      Vue.toasted.show(response.data.msg, {
        theme: 'primary',
        className: 'toasted-customred',
        position: 'top-right',
        duration: 3000
      })
      return response.data
    }).catch(error => {
      commit('STOP_LOADING')
      if (error && error.data) {
        Vue.toasted.show(error.data.title || error.data.message || error.data.msg, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 3000
        })
      }
    })
  },
  RESEND_OTP: ({ commit, dispatch, state }, payload) => {
    Vue.toasted.clear()
    commit('LOGIN_LOADER')
    return api.post(process.env.APP_URL + 'resendotp', payload).then((response) => {
      commit('STOP_LOADING')
      Vue.toasted.show(response.data.message, {
        theme: 'primary',
        className: 'toasted-customred',
        position: 'top-right',
        duration: 3000
      })
      return response.data
    }).catch(error => {
      commit('STOP_LOADING')
      if (error && error.data) {
        Vue.toasted.show(error.data.title || error.data.message, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 3000
        })
      }
    })
  },
  FB_LOGIN: ({state, commit, dispatch, rootState}, payload) => {
    // encoding redirect params
    payload.redirect = encodeURI(payload.redirect)

    Vue.toasted.clear()
    commit('LOGIN_LOADER')
    return new Promise((resolve, reject) => {
      payload.localcart = Vue.ls.get('localcart')
      payload.localwishlist = Vue.ls.get('localwishlist')
      api.post('facebooklogin?platform=web', payload).then((response) => {
        let userData = response.data
        commit('AUTH_SUCCESS', userData)
        dispatch('ADD_CUSTOMER')
        Vue.toasted.show('You\'ve been successfully logged in.', {
          theme: 'primary',
          className: isDesktop() ? 'toasted-customred' : 'toasted-mobileDefault',
          position: isDesktop() ? 'top-right' : 'bottom-right',
          duration: 5000
        })
        commit('STOP_LOADING')
        dispatch('CART_DATA')
        dispatch('USER').then((response) => {
          Vue.ls.set('email', response.email)
          let profileEventObj = {...response}
          !(profileEventObj.gender && profileEventObj.gender.length) ? delete profileEventObj.gender : ''
          profileEventObj.telephone === '' ? profileEventObj.telephone = '0000000000' : ''
          this.$store.commit('GTAG_EVENT', {eventName: 'response.profile.payload',
            payload: {
              profile_response: profileEventObj,
              exclusive_user: this.get_exclusive_user
            }}
          )
          commit('GTAG_EVENT', {eventName: 'ct_login',
            payload: {
              profile_response: response,
              login_method: 'Facebook Login'
            }}
          )
          // commit('GTAG_EVENT', {eventName: 'ct_register',
          //   payload: {
          //     profile_response: response,
          //     register_method: 'Facebook Registration'
          //   }}
          // )
          dispatch('TRACK_STORE_EVENT', {parent_event_name: 'login_event', event_name: 'login_success', method: 'facebook'})
          commit('MOENGAGE_SET_USER', response)
          const moengageLoginPayload = {
            'Full Name': String(response && response.firstname + response.lastname),
            'Phone Number': Number(response.telephone),
            Email: String(response.email),
            Status: 'successfull'
          }
          commit('MOENGAGE_EVENT', {
            eventName: 'LOGIN',
            payload: {
              ...moengageLoginPayload,
              Login_Type: 'Facebook Login'
            }
          })
          if (userData.is_first_time_login) {
            commit('MOENGAGE_EVENT', {
              eventName: 'REGISTER',
              payload: {
                ...moengageLoginPayload,
                'Social login': 'Yes',
                Birthday: response.birthdate,
                Gender: response.gender,
                Login_Type: 'Facebook Login'
              }
            })
          }
          dispatch('TATVIC_EVENT', {eventName: 'LOGIN_SUCCESSFUL', payload: {LOGIN_MEDIUM: 'Facebook', USER_ID: response.user_id}})
        })
        commit('GTAG_EVENT', {eventName: 'user.facebook.login', payload: {}})
        commit('CART_DATA', userData.cart)
        commit('WISHLIST_DATA', userData.wishlist)
        if (state.successCallback) {
          state.successCallback()
        }
        dispatch('SET_LOGINBOX', {flag: false})
        if (payload.redirect === '/cart') {
          if (userData.cart.products.items.length > payload.localcart.products.items.length || userData.cart.giftvouchers.items.length > payload.localcart.giftvouchers.items.length) {
            Vue.toasted.show('You have products in your cart', {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 5000})
            commit('HAS_CART_DATA')
          }
        }
        if (userData.is_first_time_login && payload.redirect === '/cart') {
          payload.redirect = encodeURI('/delivery-address')
          dispatch('VALIDATE_CHECKOUT', rootState, {root: true})
          router.push(payload.redirect)
        } else if (payload.newTab === 'true') {
          let token = Vue.ls.get('tss_token')
          let email = Vue.ls.get('email')
          window.open(`${payload.redirect}${token}&user_email=${email}`, '_blank')
          router.push('/')
        } else {
          router.push(payload.redirect)
        }
        dispatch('SYNC_WIDGET_DATA', userData)
        resolve(response)
      }, error => {
        commit('STOP_LOADING')
        commit('GTAG_EVENT', {eventName: 'login_failed',
          payload: {
            login_failed_reason: error.data.title || error.data.message,
            login_method: 'Facebook Login'
          }}
        )
        dispatch('TRACK_STORE_EVENT', {parent_event_name: 'login_event', event_name: 'login_failed', method: 'facebook', message: error.data.title || error.data.message})
        if (error) {
          Vue.toasted.show(error.data.title, {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 3000})
        }
        reject(error)
        Vue.toasted.show(error && error.data && error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      })
    })
  },
  GOOGLE_LOGIN: ({state, commit, dispatch, rootState}, payload) => {
    // encoding redirect params
    payload.redirect = encodeURI(payload.redirect)

    Vue.toasted.clear()
    commit('LOGIN_LOADER')
    return new Promise((resolve, reject) => {
      payload.localcart = Vue.ls.get('localcart')
      payload.localwishlist = Vue.ls.get('localwishlist')
      api.post('googlelogin?platform=web', payload).then((response) => {
        let userData = response.data
        commit('AUTH_SUCCESS', userData)
        dispatch('ADD_CUSTOMER')
        Vue.toasted.show('You\'ve been successfully logged in.', {
          theme: 'primary',
          className: isDesktop() ? 'toasted-customred' : 'toasted-mobileDefault',
          position: isDesktop() ? 'top-right' : 'bottom-right',
          duration: 5000
        })
        commit('STOP_LOADING')
        dispatch('CART_DATA')
        // dispatch('WISHLIST_DATA')
        // dispatch('CT_WISHLIST_DATA')
        dispatch('USER').then((response) => {
          Vue.ls.set('email', response.email)
          let profileEventObj = {...response}
          !(profileEventObj.gender && profileEventObj.gender.length) ? delete profileEventObj.gender : ''
          profileEventObj.telephone === '' ? profileEventObj.telephone = '0000000000' : ''
          commit('GTAG_EVENT', {eventName: 'response.profile.payload',
            payload: {
              profile_response: profileEventObj,
              exclusive_user: this.get_exclusive_user
            }}
          )
          commit('GTAG_EVENT', {eventName: 'ct_login',
            payload: {
              profile_response: response,
              login_method: 'Google Login'
            }}
          )
          // commit('GTAG_EVENT', {eventName: 'ct_register',
          //   payload: {
          //     profile_response: response,
          //     register_method: 'Google Registration'
          //   }}
          // )
          dispatch('TRACK_STORE_EVENT', {parent_event_name: 'login_event', event_name: 'login_success', method: 'google'})
          commit('MOENGAGE_SET_USER', response)
          const moengageLoginPayload = {
            'Full Name': String(response && response.firstname + ' ' + response.lastname),
            'Phone Number': Number(response.telephone),
            Email: String(response.email),
            Status: 'successfull'
          }
          commit('MOENGAGE_EVENT', {
            eventName: 'LOGIN',
            payload: {
              ...moengageLoginPayload,
              Login_Type: 'Google Login'
            }
          })
          if (userData.is_first_time_login) {
            commit('MOENGAGE_EVENT', {
              eventName: 'REGISTER',
              payload: {
                ...moengageLoginPayload,
                'Social login': 'Yes',
                Birthday: response.birthdate || 'NA',
                Gender: response.gender || 'NA',
                Login_Type: 'Google Login'
              }
            })
          }
          dispatch('TATVIC_EVENT', {eventName: 'LOGIN_SUCCESSFUL', payload: {LOGIN_MEDIUM: 'Google', USER_ID: response.user_id}})
        })
        commit('GTAG_EVENT', {eventName: 'user.google.login', payload: {}})
        commit('CART_DATA', userData.cart)
        commit('WISHLIST_DATA', userData.wishlist)
        if (state.successCallback) {
          state.successCallback()
        }
        dispatch('SET_LOGINBOX', { flag: false })
        if (payload.redirect === '/cart') {
          if (userData.cart.products.items.length > payload.localcart.products.items.length || userData.cart.giftvouchers.items.length > payload.localcart.giftvouchers.items.length) {
            Vue.toasted.show('You have products in your cart', {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 5000})
            commit('HAS_CART_DATA')
          }
        }
        if (userData.is_first_time_login && payload.redirect === '/cart') {
          payload.redirect = encodeURI('/delivery-address')
          dispatch('VALIDATE_CHECKOUT', rootState, {root: true})
          payload.redirect(payload.redirect)
        } else if (payload.newTab === 'true') {
          let token = Vue.ls.get('tss_token')
          let email = Vue.ls.get('email')
          window.open(`${payload.redirect}${token}&user_email=${email}`, '_blank')
          router.push('/')
        } else {
          router.push(payload.redirect)
        }
        dispatch('SYNC_WIDGET_DATA', userData)
        resolve(response)
      }, error => {
        commit('STOP_LOADING')
        commit('GTAG_EVENT', {eventName: 'login_failed',
          payload: {
            login_failed_reason: error.data.title || error.data.message,
            login_method: 'Google Login'
          }}
        )
        dispatch('TRACK_STORE_EVENT', {parent_event_name: 'login_event', event_name: 'login_failed', method: 'google', message: error.data.title || error.data.message})
        // Vue.toasted.show(error.data.title, {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 3000})
        reject(error)
        Vue.toasted.show(error && error.data && error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      })
    })
  },
  RESET_PASSWORD: (state, payload) => {
    Vue.toasted.clear()
    state.commit('LOGIN_LOADER')
    return api.post('forgetpassword', payload).then((response) => {
      // state.commit('AUTH_SUCCESS', response.data)
      state.commit('STOP_LOADING')
      Vue.toasted.show('Password reset link sent to your registered email ID', {
        theme: 'primary',
        className: 'toasted-customred',
        position: 'top-right',
        duration: 5000
      })
      return response.data
    }).catch(error => {
      state.commit('STOP_LOADING')
      if (error.data) {
        Vue.toasted.show(error.data.title || error.data.message, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      }
    })
  },
  REGISTER_OTP: (state, payload) => {
    Vue.toasted.clear()
    state.commit('LOGIN_LOADER')
    return api.post('register-otp', payload, { params: {platform: 'web'} }).then((response) => {
      if (response) {
        state.commit('STOP_LOADING')
        Vue.toasted.show(response && response.data && response.data.msg, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
        return response.data
      }
    }).catch(error => {
      state.commit('STOP_LOADING')
      if (error.data) {
        Vue.toasted.show(error.data.title || error.data.message || error.data.msg, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      }
    })
  },
  SET_LOGINBOX: (state, payload) => {
    state.commit('SET_LOGINBOX', payload.flag)
    state.commit('SET_SUCCESS_CALLBACK', payload.successCallback)
  },
  SET_FORGETBOX: (state, flag) => {
    state.commit('SET_FORGETBOX', flag)
  },
  LOGOUT: (state, payload) => {
    state.commit('LOGOUT')
    state.commit('MOENGAGE_CLEAR_USER')
    if (payload && payload.data && payload.data.title) {
      return
    }
    if (payload.requiresAuth) {
      if (router.currentRoute.path === '/checkout') {
        router.push('cart')
      } else {
        router.go()
      }
    }
  },
  BLACKLIST_LOGOUT: (state, payload) => {
    const token = Vue.ls.get('tss_token')
    return api.post(process.env.APP_URL + 'logout', {}, {headers: {Authorization: token}}).then(response => {
      return response.data
    }).catch(error => {
      console.log('error=', error)
      return
    })
  },
  CT_WISHLIST_DATA: (state) => {
    let wishListData = Vue.ls.get('wishlist')
    let wishItemLen = wishListData && wishListData.products && wishListData.products.items && wishListData.products.items.length
    let wishItems = []
    for (let i = 0; i < wishItemLen; i++) {
      var item = {
        product_name: wishListData.products.items[i].product,
        product_catgory: wishListData.products.items[i].category,
        product_artist: wishListData.products.items[i].artist,
        product_id: wishListData.products.items[i].prod_id,
        price: wishListData.products.items[i].price
      }
      wishItems.push(item)
    }
    window.clevertap.event.push('Active_Wishlist', {
      'products': JSON.stringify(wishItems),
      'user_id': Vue.ls.get('userID')
    })
  },
  SYNC_WISHLIST: (state) => {
    const token = Vue.ls.get('tss_token')
    const localwishlist = Vue.ls.get('localwishlist')
    api.post(process.env.APP_URL + 'sync_wishlist', {token, localwishlist}).then(response => {
      if (response && response.data) {
        state.commit('WISHLIST_DATA', response.data.wishlist)
      }
    }).catch(error => {
      console.log('error=', error)
    })
  },
  DELETE_OTP_REQUEST: ({ commit, state }, payload) => {
    Vue.toasted.clear()
    let token = Vue.ls.get('tss_token')
    api.post(process.env.APP_URL + 'account-delete-otp', payload, {headers: {Authorization: token}}).then((response) => {
      Vue.toasted.show(response.data.msg, {
        theme: 'primary',
        className: isDesktop() ? 'toasted-customred' : 'toasted-mobileDefault',
        position: isDesktop() ? 'top-right' : 'bottom-right',
        duration: 3000
      })
    }).catch(error => {
      console.log('error=', error)
    })
  },
  DELETE_RESEND_OTP: ({ commit, state }, payload) => {
    Vue.toasted.clear()
    let token = Vue.ls.get('tss_token')
    api.get(process.env.APP_URL + 'account-delete-otp/resend', {headers: {Authorization: token}}).then((response) => {
      return response.data
    }, error => {
      console.log(error)
    })
  },
  DELETE_OTP_VERIFIED: ({ commit, state }, payload) => {
    Vue.toasted.clear()
    return new Promise((resolve, reject) => {
      let token = Vue.ls.get('tss_token')
      api.post(process.env.APP_URL + 'account-delete-otp/verify', payload, {headers: {Authorization: token}}).then((response) => {
        resolve(response)
      }).catch(error => {
        Vue.toasted.show(error.data.title, {
          theme: 'primary',
          className: isDesktop() ? 'toasted-customred' : 'toasted-mobileDefault',
          position: isDesktop() ? 'top-right' : 'bottom-right',
          duration: 3000
        })
      })
    })
  },
  SYNC_WIDGET_DATA: (state, user) => {
    let searchHistory = Vue.ls.get('searchHistory')
    let recentViewProducts = Vue.ls.get('recentViewProducts')
    let searchHistoryList = []
    let searchHistoryStucture = [
      {
        name: 'recent searches',
        list: []
      }
    ]
    let searchHistoryObj = searchHistory && searchHistory.find(obj => obj.name === 'recent searches')
    if (searchHistoryObj && Array.isArray(searchHistoryObj.list) && searchHistoryObj.list.length > 0) {
      searchHistoryObj.list && searchHistoryObj.list.forEach(item => {
        searchHistoryList.push(item.autosuggest)
      })
    }
    let payload = {
      product_ids: recentViewProducts || [],
      keywords: searchHistoryList || []
    }
    let token = Vue.ls.get('tss_token')
    let apiUrl = process.env.WIDGET_URL + `/trending-products/sync-visited-product-and-keyword`
    api.post(apiUrl, payload, {headers: {Authorization: token}}).then((response) => {
      Vue.ls.remove('recentViewProducts')
      Vue.ls.set('searchHistory', searchHistoryStucture)
    })
  }
}

const mutations = {
  SET_AUTH_APP: (state, token) => {
    Vue.ls.set('tss_token', token)
    state.status = true
    state.token = token
  },
  SET_AUTH: (state) => {
    state.status = true
    state.username = Vue.ls.get('tss_username')
    state.token = Vue.ls.get('tss_token')
  },
  AUTH_REQUEST: (state, user) => {
    // console.log(user)
  },
  AUTH_SUCCESS: (state, user) => {
    Vue.ls.set('tss_token', user.access_token)
    Vue.ls.set('tss_username', user.username)
    Vue.ls.set('popupShownOnce', false)
    Vue.ls.set('childrenDayPopUpShown', false)
    Vue.ls.set('popupExcShownOnce', false)
    Vue.ls.set('welcomeOfferPopupShown', false)
    Vue.ls.set('bdayDiscountPopupDate', null)
    state.status = true
    state.username = user.username
    state.token = user.access_token
    state.loginModelBox = false
    state._loginBox = false
    state.authLoading = false
  },
  AUTH_SUCCESS_NEW: (state, user) => {
    Vue.ls.set('tss_token', user.auth_token)
    state.status = true
    state.username = user.username
    state.token = user.auth_token
    state.loginModelBox = false
    state._loginBox = false
    state.authLoading = false
  },
  IS_NEW_USER: (state, isNewUser) => {
    Vue.ls.set('is_new_user', isNewUser)
  },
  LOGIN_LOADER: (state) => {
    state.authLoading = true
  },
  STOP_LOADING: (state) => {
    state.authLoading = false
  },
  AUTH_ERROR: (state, error) => {
    Vue.ls.set('tss_token', '')
    Vue.ls.set('is_new_user', '')
    state.status = false
    state.token = ''
    state.authError = 'Invalid Credentials.'
    state.authLoading = false
  },
  SET_LOGINBOX: (state, flag) => {
    state.loginModelBox = flag
    state._loginBox = true
  },
  SET_SUCCESS_CALLBACK: (state, successCallback) => {
    state.successCallback = successCallback
  },
  SET_FORGETBOX: (state, flag) => {
    state.forgetBox = flag
    if (flag) {
      state._loginBox = false
    } else {
      state._loginBox = true
    }
  },
  LOGOUT: (state) => {
    if (state.status) {
      Vue.ls.remove('recentViewProducts')
    }
    Vue.ls.set('tss_token', '')
    Vue.ls.set('is_new_user', '')
    Vue.ls.remove('localcart')
    Vue.ls.remove('localwishlist')
    Vue.ls.remove('genderDOBModal')
    Vue.ls.remove('userID')
    Vue.ls.set('popupShownOnce', false)
    Vue.ls.set('childrenDayPopUpShown', false)
    Vue.ls.set('popupExcShownOnce', false)
    Vue.ls.set('welcomeOfferPopupShown', false)
    Vue.ls.set('bdayDiscountPopupDate', null)
    Vue.ls.remove('searchHistory')
    Vue.ls.remove('customer_update')
    state.status = false
    Vue.ls.remove('pos_login')
    Vue.ls.remove('cod_checkout_login')
    Vue.ls.remove('pos_store_id')
    Vue.ls.remove('pos_user_id')
    state.isPosLogin = false
    state.isCodCheckoutLogin = false
    state.username = ''
    state.token = ''
    window.sessionStorage.removeItem('isPerfumePushPopup')
  },
  SYNC_CART: (state) => {
    // let token = Vue.ls.get('tss_token')
  },
  SET_ACTIVE_LOGIN_FORM: (state, flag) => {
    state.activeLoginForm = flag
  },
  EMAIL_FORM_VALUE: (state, payload) => {
    state.emailid = payload
  },
  SET_ACTIVE_EMAIL_LOGIN_FORM: (state, payload) => {
    state.activeEmailLoginForm = payload
  },
  SET_ACTIVE_REGISTER_FORM: (state, flag) => {
    state.activeRegisterForm = flag
  },
  SET_SEND_OTP_LOGIN_DETAILS: (state, payload) => {
    state.sendOtpLoginDetails = {...payload}
  },
  SET_ATTEMPTS_MSG: (state, payload) => {
    state.attemptsMsg = payload
  },
  SET_POS_LOGIN_USER: (state, flag) => {
    state.isPosLogin = flag
  },
  SET_COD_CHECKOUT_LOGIN_USER: (state, flag) => {
    state.isCodCheckoutLogin = flag
  }
}
export default {
  state,
  getters,
  actions,
  mutations
}
