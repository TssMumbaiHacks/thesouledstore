import api from '../../api/api'
import Vue from 'vue'
import router from '../../router'
import * as cTimer from './../../assets/js/stickyPopup.js'
import {isDesktop, getProductUrl, getCookie} from '@/assets/js/common'
import { getFbcId } from '../../assets/js/common'
// import store from '../../store'

function getMeta (cart, attr) {
  let metaObj = {}
  let meta = cart && cart.meta
  if (meta && (meta.index[attr] || meta.index[attr] === 0)) {
    metaObj = meta.items[meta.index[attr]]
  }
  return metaObj
}

// use the below function during exclusive sale
// function formatTime (date) {
//   let d = date ? new Date(date) : new Date()
//   return [
//     d.getFullYear(),
//     ('0' + (d.getMonth() + 1)).slice(-2),
//     ('0' + d.getDate()).slice(-2)
//   ].join('-') + ' ' +
//     [('0' + d.getHours()).slice(-2),
//       ('0' + d.getMinutes()).slice(-2),
//       ('0' + d.getSeconds()).slice(-2)
//     ].join(':')
// }

const cart = {
  state: {
    added: [],
    checkoutStatus: null,
    productStockStatus: false,
    sizeError: '',
    quantityError: '',
    localCart: {},
    _cart: {},
    couponError: '',
    giftVoucher: '',
    goToCart: false,
    cartWidgets: [],
    mysteryProduct: {},
    isMystery: 0,
    validcoupons: [],
    rewardPoints: false,
    popupFlag: false,
    totalSavings: 0,
    hasCartData: false,
    membershipManuallyAdded: false,
    tssPoints: false,
    tssMoney: false,
    oldActivePricelists: {},
    isCouponLoading: '',
    isVoucherLoading: false,
    isBillingDonationApplicable: false,
    hyperLocalSelection: false,
    voucherPinAuth: {},
    deliveryEstimateData: {},
    isClimesEnable: '',
    climesRemaining: '',
    notificationData: [],
    shipmentData: []
  },
  getters: {
    sizeError: state => state.sizeError,
    quantityError: state => state.quantityError,
    _cart: state => state._cart,
    cartcount: function (state) {
      let cart = state._cart
      let keys = ['products', 'giftvouchers', 'complementary_products']
      let count = 0
      for (let key of keys) {
        if (!cart[key]) {
          continue
        }
        let items = cart[key].items
        for (let item of items) {
          if (key !== 'complementary_products') {
            count += (item['quantity'] || 1)
          } else if (item['is_valid'] && item['show_freebie']) {
            count++
          }
        }
      }
      return count
    },
    product_count: function (state) {
      let count = 0
      if (state._cart && state._cart.products) {
        return state._cart.products.items.length
      }
      return count
    },
    cartvouchers: function (state) {
      if (state._cart && state._cart.giftvouchers) {
        return state._cart.giftvouchers.items
      }
      return []
    },
    products: function (state) {
      if (state._cart && state._cart.products) {
        return state._cart.products.items
      }
      return []
    },
    complementaryProducts: function (state) {
      if (state._cart && state._cart.complementary_products) {
        return state._cart.complementary_products.items
      }
      return []
    },
    cartwidgets: function (state) {
      if (state._cart && state._cart.widgets) {
        return state._cart.widgets.items
      }
      return []
    },
    calculations: function (state) {
      return getMeta(state._cart, 'calculations')
    },
    convenience_fee_config: function (state) {
      return getMeta(state._cart, 'convenience_fee_config')
    },
    hyperlocal_order: function (state) {
      return getMeta(state._cart, 'hyperlocal_order')
    },
    active_pricelists: function (state) {
      return getMeta(state._cart, 'active_pricelists')
    },
    site_config: function (state) {
      return getMeta(state._cart, 'site_config')
    },
    isExclusive: function (state) {
      const exclusiveMeta = getMeta(state._cart, 'exclusive_user')
      if (Object.keys(exclusiveMeta).length) {
        return exclusiveMeta.active
      } else {
        return false
      }
    },
    exclusiveProduct: function (state) {
      let val = getMeta(state._cart, 'exclusive_user').cart
      return val
    },
    exclusiveUser: function (state) {
      let val = getMeta(state._cart, 'exclusive_user').permanent
      return val
    },
    gift_voucher: function (state) {
      return getMeta(state._cart, 'gift_voucher')
    },
    coupon: function (state) {
      return getMeta(state._cart, 'coupon')
    },
    selected_address: function (state) {
      return getMeta(state._cart, 'address')
    },
    cod_details: function (state) {
      return getMeta(state._cart, 'cod')
    },
    addedWidgets: function (state) {
      if (state._cart && state._cart.widgets) {
        let checker = {}
        for (let widget of state._cart.widgets.items) {
          checker[widget['id']] = true
        }
        return checker
      }
      return {}
    },
    giftVoucher: state => state.giftVoucher,
    gvdetails: state => state.gvdetails,
    isGiftVoucher: state => state.isGiftVoucher,
    goToCart: state => state.goToCart,
    cartWidgets: state => state.cartWidgets,
    mysteryProduct: state => state.mysteryProduct,
    isMystery: state => state.isMystery,
    validcoupons: state => state.validcoupons,
    rewardPoints: state => state.rewardPoints,
    popupFlag: state => state.popupFlag,
    totalSavings: state => state.totalSavings,
    hasCartData: state => state.hasCartData,
    couponError: state => state.couponError,
    membershipManuallyAdded: state => state.membershipManuallyAdded,
    tssMoney: state => state.tssMoney,
    tssPoints: state => state.tssPoints,
    oldActivePricelists: state => state.oldActivePricelists,
    isCouponLoading: state => state.isCouponLoading,
    isVoucherLoading: state => state.isVoucherLoading,
    isBillingDonationApplicable: state => state.isBillingDonationApplicable,
    hyperLocalSelection: state => state.hyperLocalSelection,
    voucherPinAuth: state => state.voucherPinAuth,
    deliveryEstimateData: state => state.deliveryEstimateData,
    climes_data: function (state) {
      return getMeta(state._cart, 'climes')
    },
    isClimesEnable: state => state.isClimesEnable,
    climesRemaining: state => state.climesRemaining,
    notificationData: state => state.notificationData,
    getShipment: state => state.shipmentData
  },
  actions: {
    CHECK_CLIMES_STATUS: ({commit, dispatch}, payload) => {
      api.get(process.env.APP_URL + 'climes/status/' + payload.cart_id).then((response) => {
        if (response && response.data) {
          commit('SET_CLIMES_STATUS', response.data.optedIn)
        }
      }, error => {
        console.log(error)
      })
    },
    UPDATE_CLIMES_STATUS: ({commit, dispatch}, payload) => {
      api.post(process.env.APP_URL + 'climes/update_status', payload).then((response) => {
        if (response) {
          commit('SET_CLIMES_STATUS', payload.opted_in)
        }
      }, error => {
        console.log(error)
      })
    },
    GET_CLIMES_REMAINING: ({commit, dispatch}, payload) => {
      api.get(process.env.APP_URL + 'climes/remaining').then((response) => {
        if (response && response.data) {
          commit('SET_CLIMES_REMAINING', response.data.remaining)
        }
      }, error => {
        console.log(error)
      })
    },
    UPDATE_CART: ({state, dispatch, commit, getters}, payload) => {
      Vue.toasted.clear()
      return new Promise((resolve, reject) => {
        let token = Vue.ls.get('tss_token')
        let localcart = Vue.ls.get('localcart')
        let isHyperlocal = Vue.ls.get('is_hyperlocal')
        let isSplitOrder = Vue.ls.get('is_split_order')
        const hideToaster = payload.hideToaster
        delete payload.hideToaster
        const preventCartMutation = payload.preventCartMutation
        delete payload.preventCartMutation
        const cartAfterDelete = payload.cartAfterDelete
        delete payload.cartAfterDelete
        payload['is_ab_visible'] = true
        // save old active_pricelists
        commit('OLD_ACTIVE_PRICELISTS', localcart)
        localcart = {...localcart, fbp: getCookie('_fbp'), external_id: getters.user.user_id, fbc: getFbcId(router.currentRoute.query.fbclid)}
        payload = {payload, localcart, is_ab_visible: true, is_hyperlocal: isHyperlocal || false, is_split_order: isSplitOrder || false}
        api.post('cart', payload, {headers: {Authorization: token}, params: {platform: 'web'}}).then((response) => {
          switch (payload.payload.operation) {
            case 'add':
              !hideToaster && Vue.toasted.show(
                'Product added to your cart successfully.',
                {
                  theme: 'primary',
                  className: isDesktop() ? 'toasted-customred' : 'toasted-mobileTeal',
                  position: isDesktop() ? 'top-right' : 'bottom-right',
                  duration: isDesktop() ? 5000 : 2000
                }
              )
              commit('GTAG_EVENT', {eventName: 'product.add_to_cart.payload',
                payload: {
                  product_added_to_cart: payload.payload,
                  coupon_applied: getters.get_coupon_applied,
                  coupon_value: getters.calculations.coupon_discount || 0,
                  reward_points: getters.calculations.used_reward_points || 0
                }}
              )
              commit('GTAG_EVENT', {eventName: 'FB_Add_To_Cart',
                payload: {
                  product: payload
                }}
              )
              commit('GTAG_EVENT', {eventName: 'Added_To_Cart',
                payload: {
                  product_added_to_cart: payload,
                  coupon_applied: getters.get_coupon_applied,
                  coupon_value: (getters.calculations.coupon_discount || 0),
                  reward_points: (getters.calculations.used_reward_points || 0),
                  category: payload.payload.data.category,
                  SKU: payload.payload.data.parent_prod_id,
                  quantity: payload.payload.data.quantity,
                  product_price: payload.payload.data.price,
                  CartEMSaving_Value: payload.payload.data.spl_price,
                  Cart_Value: payload && payload.localcart && payload.localcart.products && payload.localcart.products.items
                }}
              )
              if (payload && payload.payload && payload.payload.data) {
                dispatch('TRACK_STORE_EVENT', {
                  parent_event_name: 'general_event',
                  event_name: 'add to cart',
                  product_name: payload.payload.data.product,
                  product_id: payload.payload.data.parent_prod_id,
                  child_id: payload.payload.data.prod_id,
                  quantity: payload.payload.data.quantity
                })
                commit('MOENGAGE_EVENT', {
                  eventName: 'ADDED_TO_CART',
                  payload: {
                    Product_Category: String(payload.payload.data.category),
                    Product_Name: String(payload.payload.data.product),
                    Product_ID: String(payload.payload.data.parent_prod_id),
                    Product_Price: Number(payload.payload.data.price),
                    Quantity: Number(payload.payload.data.quantity),
                    Product_Artist: String(payload.payload.data.artist_slug),
                    Product_URL: String(getProductUrl(true, payload.payload.data.url_key, payload.payload.data.gender_type)),
                    ProductImage_URL: String(payload.payload.data.images && payload.payload.data.images[0] ? `${process.env.IMG_BASE_URL}${process.env.PRODUCT_DETAIL_IMG}${payload.payload.data.images[0]}` : ''),
                    Size: String(payload.payload.data.size)
                  }
                })
              }
              break
            case 'delete':
              !hideToaster && Vue.toasted.show('Product removed from cart.', { theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 5000 })
              commit('GTAG_EVENT', {eventName: 'product.remove_from_cart.payload', payload: {product_remove_from_cart: payload.payload}})
              commit('CT_REMOVE_CART', payload)
              commit('GTAG_EVENT', {eventName: 'Remove From Cart',
                payload: {membership_type: getters.getMemberShipType,
                  membership_price: getters.getMemberShipPrice,
                  pdp_response: Vue.ls.get('routeObj')}
              })
              commit('SET_COUPON_ERROR', '')
              if (payload.payload.data.prod_id === getters.site_config.exclusive_products[2] &&
                getters.site_config.exclusive_products[2].prod_id ||
                payload.payload.data.prod_id === getters.site_config.exclusive_products[1].prod_id ||
                payload.payload.data.prod_id === getters.site_config.exclusive_products[0].prod_id ||
                payload.payload.data.prod_id === getters.site_config.exclusive_products[2].prod_id) {
                // Google Analytics Event
                // commit('GTAG_EVENT', {eventName: 'exclusive.product.removed', payload: {}})
                commit('GTAG_EVENT', {eventName: 'ExclusiveRemovedFromCart',
                  payload: {
                    name: 'The Souled Store Membership',
                    id: payload.payload.data.prod_id || 'NA',
                    category: 'Exclusive'
                  }
                })
              }
              dispatch('TRACK_STORE_EVENT', {
                parent_event_name: 'general_event',
                event_name: 'remove from cart',
                product_name: payload.payload.data && payload.payload.data.product,
                product_id: payload.payload.data && payload.payload.data.parent_prod_id,
                child_id: payload.payload.data && payload.payload.data.prod_id,
                quantity: payload.payload.data && payload.payload.data.quantity
              })
              break
            case 'set':
              if (payload.payload.name) {
                Vue.toasted.show(payload.payload.name + ' Membership has been added to your cart.', { theme: 'primary', className: 'toasted-customblue', position: 'top-right', duration: 5000 })
              }
              break
            default:
              console.log('DEFAULT CASE TRIGGERED')
          }
          commit('CART_DATA', {...response.data, preventCartMutation})
          resolve({ animate: true, cart: response.data })
          if (payload.payload.operation === 'add' && parseInt(payload.payload.data.prod_id) !== process.env.EXCLUSIVE_PRODUCT) {
            commit('SET_GOTO_CART', true)
          }
          if (getters.site_config.exclusive_products[0] &&
            getters.site_config.exclusive_products[1] &&
            getters.site_config.exclusive_products[2] &&
            getters.site_config.exclusive_products[0].prod_id &&
            getters.site_config.exclusive_products[1].prod_id &&
            getters.site_config.exclusive_products[2].prod_id &&
            payload.payload &&
            payload.payload.data &&
            payload.payload.data.prod_id &&
            (payload.payload.data.prod_id === getters.site_config.exclusive_products[0].prod_id ||
            payload.payload.data.prod_id === getters.site_config.exclusive_products[1].prod_id ||
            payload.payload.data.prod_id === getters.site_config.exclusive_products[2].prod_id) &&
            payload.payload.operation === 'set') {
            // commit('GTAG_EVENT', {eventName: 'exclusive.checkbox.click', payload: {source_route_of_exclusive: payload.payload.route}})
            // commit('GTAG_EVENT', {eventName: 'Exclusive_Added',
            //   payload: {
            //     membership_type: getters.getMemberShipType,
            //     membership_price: getters.getMemberShipPrice
            //   }}
            // )
          }
          // commit('GTAG_EVENT', {eventName: 'response.cart',
          //   payload: {email: getters.user.email,
          //     cart_data_response: getters._cart
          //   }}
          // )
          // commit('GTAG_EVENT', {eventName: 'Ecommerce-Cart_button',
          //   payload: {crto: {
          //     email: getters.user && getters.user.email,
          //     add_to_cart_products: getters.cartContent_for_criteo
          //   }}}
          // )
          const productData = payload.payload.data
          commit('GTAG_EVENT', {eventName: payload && payload.payload ? payload.payload.operation === 'add' ? 'eec.add' : payload.payload.operation === 'delete' ? 'eec.remove' : '' : '',
            payload: {
              ecommerce: {
                add: {
                  actionField: {
                    list: state.productDetailsPrevRoute && state.productDetailsPrevRoute.path
                  },
                  exclusive_user: getters.get_exclusive_user,
                  products: [{
                    id: productData && productData.prod_id || 'NA',
                    name: productData.product,
                    category: productData.category,
                    variant: productData.size,
                    price: productData.spl_price > 0 ? productData.spl_price * productData.quantity : productData.price * productData.quantity,
                    ...productData.size && { variant: productData.size },
                    brand: productData.artist,
                    quantity: productData.quantity
                  }]
                }
              }
            }}
          )
          if (payload && payload.payload && payload.payload.data) {
            commit('GTAG_EVENT', {eventName: 'Cart_button',
              payload: {
                screen_name: Vue.ls.get('routeObj'),
                ecommerce: {
                  add: {
                    actionField: {
                      list: getters.productDetailsPrevRoute && getters.productDetailsPrevRoute.path
                    },
                    exclusive_user: getters.get_exclusive_user,
                    products: [{
                      id: payload.payload.data.prod_id,
                      name: payload.payload.data.product,
                      category: payload.payload.data.category,
                      variant: payload.payload.data.size,
                      price: payload.payload.data.spl_price > 0 ? payload.payload.data.spl_price * payload.payload.data.quantity : payload.payload.data.price * payload.payload.data.quantity,
                      ...payload.payload.data.size && { variant: payload.payload.data.size },
                      brand: payload.payload.data.artist,
                      quantity: payload.payload.data.quantity
                    }]
                  }
                }
              }}
            )
          }
          commit('GTAG_EVENT', {eventName: 'Ecommerce-Cart_button',
            payload: {
              screen_name: Vue.ls.get('routeObj')
            }}
          )
          if (payload.payload.type === 'giftvouchers') {
            commit('GTAG_EVENT', {eventName: payload && payload.payload ? payload.payload.operation === 'set' ? 'eec.add' : payload.payload.operation === 'delete' ? 'eec.remove' : '' : '',
              payload: {
                ecommerce: {
                  add: {
                    exclusive_user: getters.get_exclusive_user,
                    products: [{
                      id: payload.payload.data.gvamountid,
                      name: 'Gift Voucher ' + payload.payload.data.pay_amt,
                      category: 'Gift Voucher',
                      price: payload.payload.data.pay_amt,
                      quantity: '1'
                    }]
                  }
                }
              }}
            )
          }
          return response
        }, error => {
          Vue.toasted.show(error.data.title, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
          // resolve({animate: false})
          if (cartAfterDelete && cartAfterDelete.setCartAfterDelete && cartAfterDelete.deletedCart) {
            commit('CART_DATA', cartAfterDelete.deletedCart)
          }
          reject(error)
        })
      })
    },
    APPLY_WALLET: ({state, dispatch, commit}, payload) => {
      let token = Vue.ls.get('tss_token')
      let localcart = Vue.ls.get('localcart')
      let isHyperlocal = Vue.ls.get('is_hyperlocal')
      let isSplitOrder = Vue.ls.get('is_split_order')
      // save old active_pricelists
      commit('OLD_ACTIVE_PRICELISTS', localcart)
      payload.localcart = localcart
      payload.is_hyperlocal = isHyperlocal || false
      payload.is_split_order = isSplitOrder || false
      Vue.toasted.clear()
      return api.post('wallet', payload, {headers: {Authorization: token}}).then((response) => {
        commit('CART_DATA', response.data)
        commit('SET_REWARD_POINT_FLAG', payload.state)
        dispatch('USER')
        return response
      }, error => {
        Vue.toasted.show(error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
        return error
      })
    },
    CART_DATA: ({commit, dispatch}, payload) => {
      return new Promise((resolve, reject) => {
        let token = Vue.ls.get('tss_token')
        let localcart = Vue.ls.get('localcart')
        let params = {
          platform: 'web'
        }
        if (payload && payload.isReinit) {
          params = {
            ...params,
            re_init: payload.isReinit,
            platform: 'web'
          }
        }
        // save old active_pricelists
        commit('OLD_ACTIVE_PRICELISTS', localcart)
        api.post('cart', {
          localcart,
          payload: {operation: 'get'},
          is_hyperlocal: (payload && payload.is_hyperlocal) ? payload.is_hyperlocal : false,
          is_split_order: (payload && payload.is_split_order) ? payload.is_split_order : false,
          is_ab_visible: true
        }, {headers: {Authorization: token}, params}).then((response) => {
          resolve(response.data)
          commit('CART_DATA', response.data)
          return response.data
        }, error => {
          console.log(error)
          return error
        })
      })
    },
    CART_WIDGETS: (state) => {
      return new Promise((resolve, reject) => {
        api.get('cartwidgets').then((response) => {
          state.commit('CART_WIDGETS', response.data)
          // HACK: buffer time to ensure value is always set
          setTimeout(() => {
            resolve({update: true})
          }, 100)
        }, error => {
          console.log(error)
          resolve({update: false})
        })
      })
    },
    CART_DELIVERY_ESTIMATE: (state) => {
      let token = Vue.ls.get('tss_token')
      api.get('cart-delivery-estimate', {headers: {Authorization: token}}).then((response) => {
        state.commit('SET_DELIVERY_ESTIMATE', response.data && response.data.data)
      }, error => {
        console.log(error)
      })
    },
    VALIDATE_CHECKOUT: (state) => {
      let token = Vue.ls.get('tss_token')
      Vue.toasted.clear()
      api.post('validatecheckout', {}, {headers: {Authorization: token}}).then((response) => {
        if (!state.getters.hasCartData) {
          if (Object.keys(state.getters.get_coupon_applied).length) {
            state.commit('GTAG_EVENT', {eventName: 'response.validatecheckout',
              payload: {
                coupon_applied: state.getters.get_coupon_applied,
                coupon_value: (state.getters.calculations.coupon_discount || 0),
                price: (state.getters.calculations.total || 0) + (state.getters.calculations.used_reward_points || 0) + (state.getters.calculations.used_tss_points || 0) + (state.getters.calculations.gift_voucher_value || 0)
              }}
            )
          }
          // state.commit('GTAG_EVENT', {eventName: 'eec.checkout_1',
          //   payload: {
          //     ecommerce: {
          //       checkout: {
          //         actionField: {
          //           step: 2
          //         },
          //         exclusive_user: state.getters.get_exclusive_user,
          //         products: state.getters.cartContent_for_eec // Here we need to add a made up array of all product added
          //       }
          //     }
          //   }}
          // )
          // state.commit('GTAG_EVENT', {eventName: 'FB_Checkout',
          //   payload: {
          //     all_cart_product_data: state.getters._cart.products.items,
          //     price: (state.getters.calculations.total || 0) + (state.getters.calculations.used_reward_points || 0) + (state.getters.calculations.used_tss_points || 0) + (state.getters.calculations.gift_voucher_value || 0),
          //     coupon_applied: state.getters.get_coupon_applied,
          //     coupon_value: (state.getters.calculations.coupon_discount || 0)
          //   }}
          // )
          state.dispatch('ECOMMERCE_EVENT', {eventName: 'begin_checkout',
            payload: {
              currency: state.getters.currency,
              value: (state.getters.calculations.total || 0) + (state.getters.calculations.used_reward_points || 0) + (state.getters.calculations.used_tss_points || 0) + (state.getters.calculations.gift_voucher_value || 0),
              items: [
                ...state.getters.getUserTatvicCartItems
              ],
              tss_points: (state.getters.calculations.used_tss_points || 0),
              coupon: (this.coupon && this.coupon.coupon) || 'NA'
            }
          })
          router.push({name: 'paymentoptions'})
        }
        state.commit('HAS_CART_DATA', false)
      }, error => {
        Vue.toasted.show(error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 5000
        })
      })
      // Vue.toasted.clear()
    },
    REMOVE_COUPON: (state, coupon) => {
      Vue.toasted.clear()
      state.commit('SET_COUPON_LOADING', true)
      state.dispatch('UPDATE_CART', {'type': 'meta', 'operation': 'delete', 'data': {'name': 'coupon'}, hideToaster: true}).then(res => {
        state.commit('SET_COUPON_LOADING', false)
      })
    },
    SET_GOTO_CART: (state, flag) => {
      state.commit('SET_GOTO_CART', flag)
    },
    VALIDATE_COUPON: (state, coupon) => {
      let token = Vue.ls.get('tss_token')
      let localcart = Vue.ls.get('localcart')
      let isHyperlocal = Vue.ls.get('is_hyperlocal')
      let isSplitOrder = Vue.ls.get('is_split_order')
      Vue.toasted.clear()
      state.commit('SET_COUPON_LOADING', true)
      api.post('coupon', {coupon: coupon, platform: 'web', localcart, is_hyperlocal: isHyperlocal || false, is_split_order: isSplitOrder || false}, {headers: {Authorization: token}}).then((response) => {
        // Vue.toasted.show('Coupon applied successfully.', {theme: 'primary', className: 'toasted-customred', position: 'top-right', duration: 5000})
        state.commit('SET_COUPON_LOADING', false)
        state.commit('CART_DATA', response.data)
        state.dispatch('TATVIC_EVENT', {eventName: 'DISCOUNT_CODE_APPLY',
          payload: {
            VOUCHER_TYPE: 'Apply Coupon',
            STATUS: 'Success'
          }}
        )
        state.commit('MODIFY_OFFER_APPEAR_TIMER', cTimer.TIMER.OFFER_APPEAR_TIMER)
        state.commit('MODIFY_OFFER_TIMER', cTimer.TIMER.OFFER_COUNTDOWN_TIMER)
        state.commit('SET_COUPON_ERROR', '')
        // state.commit('SET_COUPON', coupon)
      }, error => {
        state.dispatch('TATVIC_EVENT', {eventName: 'DISCOUNT_CODE_APPLY',
          payload: {
            VOUCHER_TYPE: 'Apply Coupon',
            STATUS: 'Failure'
          }}
        )
        state.commit('SET_COUPON_LOADING', false)
        state.commit('SET_COUPON_ERROR', error.data.title)
      })
    },
    APPLY_GIFT_VOUCHER: (state, payload) => {
      let token = Vue.ls.get('tss_token')
      let localcart = Vue.ls.get('localcart')
      state.commit('SET_VOUCHER_LOADING', true)
      api.post('giftvoucher', {
        ...payload,
        localcart
      }, {headers: {Authorization: token}}).then((response) => {
        state.commit('CART_DATA', response.data)
        state.commit('SET_GIFT_VOUCHER', payload.voucher_code)
        state.commit('SET_VOUCHER_LOADING', false)
        state.dispatch('TATVIC_EVENT', {eventName: 'DISCOUNT_CODE_APPLY',
          payload: {
            VOUCHER_TYPE: 'Gift Voucher',
            STATUS: 'Success'
          }}
        )
      }, error => {
        if (error && error.data && error.data.is_pin_required) {
          state.commit('SET_GV_PIN_AUTH', error.data)
          Vue.toasted.show(error.data.title, {
            theme: 'primary',
            className: isDesktop() ? 'toasted-customred' : 'toasted-mobileDefault',
            position: isDesktop() ? 'top-right' : 'bottom-right',
            duration: 5000
          })
        } else {
          state.commit('SET_VOUCHER_LOADING', false)
          state.dispatch('TATVIC_EVENT', {eventName: 'DISCOUNT_CODE_APPLY',
            payload: {
              VOUCHER_TYPE: 'Gift Voucher',
              STATUS: 'Failure'
            }}
          )
          Vue.toasted.show(error.data.title, {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
        }
      })
    },
    REMOVE_GIFT_VOUCHER: (state) => {
      state.commit('SET_VOUCHER_LOADING', true)
      state.dispatch('UPDATE_CART', {operation: 'delete', type: 'meta', data: {'name': 'gift_voucher'}}).then(() => {
        state.commit('SET_VOUCHER_LOADING', false)
      }).catch(() => {
        state.commit('SET_VOUCHER_LOADING', false)
      })
    },
    VALID_COUPONS: (state) => {
      let token = Vue.ls.get('tss_token')
      let localcart = Vue.ls.get('localcart')
      let isHyperlocal = Vue.ls.get('is_hyperlocal')
      let isSplitOrder = Vue.ls.get('is_split_order')
      Vue.toasted.clear()
      api.post('validcoupons', {localcart, platform: 'web', is_hyperlocal: isHyperlocal || false, is_split_order: isSplitOrder || false}, {headers: {Authorization: token}}).then((response) => {
        state.commit('VALID_COUPONS', response.data)
      }, error => {
        Vue.toasted.show(error.data.title, {
          theme: 'primary',
          className: 'toasted-customred',
          position: 'top-right',
          duration: 3000
        })
      })
    },
    GETCARTLIST_DATA: ({commit, dispatch}, payload) => {
      return new Promise((resolve, reject) => {
        let token = Vue.ls.get('tss_token')
        let localwishlist = Vue.ls.get('localcart')
        let isHyperlocal = Vue.ls.get('is_hyperlocal')
        let isSplitOrder = Vue.ls.get('is_split_order')
        payload = {payload, localwishlist, is_hyperlocal: isHyperlocal || false, is_split_order: isSplitOrder || false}
        api.post('cart?re_init=1', payload, {headers: {Authorization: token}, 'Content-Type': 'application/json'}).then((response) => {
          resolve(response.data)
          commit('CART_DATA', response.data)
          return response.data
        }, error => {
          console.log(error)
          return error
        })
      })
    },
    GET_NOTIFICATIONS: ({commit}) => {
      let token = Vue.ls.get('tss_token')
      api.get('notifications', {headers: {Authorization: token}}).then((response) => {
        if (response && response.data) {
          commit('SET_NOTIFICATION_DATA', response.data.notification_data)
        }
      }, error => {
        console.log(error)
      })
    },
    FETCH_SHIPMENT: ({ state, commit }, payload) => {
      let token = Vue.ls.get('tss_token')
      return api.post(process.env.APP_URL + 'get-shipment', payload, {headers: {Authorization: token}}).then((response) => {
        commit('GET_SHIPMENT', response.data)
        return response.data
      }).catch((error) => {
        console.log(error)
        throw error
      })
    }
  },
  mutations: {
    SET_CLIMES_STATUS: (state, payload) => {
      state.isClimesEnable = payload
    },
    SET_CLIMES_REMAINING: (state, data) => {
      state.climesRemaining = data
    },
    CART_DATA: (state, cart) => {
      const preventCartMutation = cart.preventCartMutation
      delete cart.preventCartMutation
      Vue.ls.set('localcart', cart)
      if (!preventCartMutation) {
        state._cart = cart
        // FIXME: add to a getter
        let totalSavings = 0
        // for (let x of cart.cartinfo) {
        //   if (x.spl_price > 0) {
        //     totalSavings += (x.original_price - x.spl_price) * x.quantity
        //   }
        // }
        // totalSavings += cart.coupon_discount
        state.totalSavings = parseInt(totalSavings)
        state.totalSavings = 0
        state.coupon = cart.coupon
        state.giftVoucher = cart.giftvoucher
        state.isGiftVoucher = cart.isGiftVoucher
        // state.isExclusive = cart.isExclusive
      }
    },
    HAS_CART_DATA: (state, flag) => {
      state.hasCartData = flag
    },
    CART_WIDGETS: (state, cartwidgets) => {
      state.cartWidgets = cartwidgets
    },
    SET_DELIVERY_ESTIMATE: (state, payload) => {
      state.deliveryEstimateData = payload
    },
    SET_COUPON: (state, coupon) => {
      state.coupon = coupon
    },
    SET_GIFT_VOUCHER: (state, voucher) => {
      state.giftVoucher = voucher
    },
    SET_GOTO_CART: (state, flag) => {
      state.goToCart = flag
    },
    SET_REWARD_POINT_FLAG: (state, flag) => {
      state.rewardPoints = flag
    },
    VALID_COUPONS: (state, data) => {
      state.validcoupons = data
    },
    SET_COUPON_ERROR: (state, data) => {
      state.couponError = data
    },
    MEMBERSHIP_MANUALLY_ADDED: (state, flag) => {
      state.membershipManuallyAdded = flag
    },
    OLD_ACTIVE_PRICELISTS: (state, cart) => {
      state.oldActivePricelists = getMeta(cart, 'active_pricelists')
    },
    SET_COUPON_LOADING: (state, payload) => {
      state.isCouponLoading = payload
    },
    SET_VOUCHER_LOADING: (state, payload) => {
      state.isVoucherLoading = payload
    },
    SET_BILLING_DONATION_CAMPAIGN: (state, payload) => {
      state.isBillingDonationApplicable = payload
    },
    SET_CART_HYPERLOCAL_SELECTION: (state, payload) => {
      state.hyperLocalSelection = payload
    },
    SET_GV_PIN_AUTH: (state, payload) => {
      state.voucherPinAuth = payload
    },
    SET_NOTIFICATION_DATA: (state, data) => {
      state.notificationData = data
    },
    GET_SHIPMENT: (state, payload) => {
      state.shipmentData = payload
    }
  }
}

export default cart
