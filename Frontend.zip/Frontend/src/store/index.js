import Vue from 'vue'
import Vuex from 'vuex'
import auth from './modules/auth'
import cart from './modules/cart'
import wishlist from './modules/wishlist'
import checkout from './modules/checkout'
import products from './modules/products'
import payment from './modules/payment'
import juspay from './modules/juspay'
import payu from './modules/payu'
import user from './modules/user'
import various from './modules/various'
import giftvoucher from './modules/gift-voucher'
import order from './modules/order'
import search from './modules/search'
import exclusive from './modules/exclusive'
import tagManager from './modules/tag-manager'
import myRewardPoints from './modules/myRewardPoints'
import * as cTimer from './../assets/js/stickyPopup'
import contactus from './modules/contactus'
import sneakercare from './modules/sneakercare'
import buyNowMobile from './modules/buyNowMobile'
import eCommerceEvents from './modules/e-commerceEvents.js'
import storeEvents from './modules/storeEvents.js'

Vue.use(Vuex)

export default new Vuex.Store({
  modules: {
    search: search,
    auth: auth,
    cart: cart,
    wishlist: wishlist,
    checkout: checkout,
    product: products,
    payment: payment,
    juspay: juspay,
    payu: payu,
    user: user,
    various: various,
    giftvoucher: giftvoucher,
    order: order,
    exclusive: exclusive,
    tagManager: tagManager,
    myRewardPoints: myRewardPoints,
    contactus: contactus,
    sneakercare: sneakercare,
    buyNowMobile: buyNowMobile,
    eCommerceEvents: eCommerceEvents,
    storeEvents: storeEvents
  },
  state: {
    todos: [],
    currentPage: 1,
    searchData: {data: {}, total: 0},
    dgraphSearch: {data: {}, total: 0},
    searchPageNo: 1,
    searchKey: '',
    offerAppearTimer: cTimer.TIMER.OFFER_APPEAR_TIMER, // offer-appear-timer
    offerTimer: cTimer.TIMER.OFFER_COUNTDOWN_TIMER, // offer-countdown-timer
    webpushInitiator: true,
    userInterestTime: null,
    footerCollapseControl: {
      expanded: true,
      expandedClass: 'show',
      bottomStyle: 'margin-bottom: 0px;'
    },
    selectedCountryAddress: {
      name: '',
      country: 'India',
      countryId: '99',
      isoCode: 'IND',
      isoCode2: 'IN'
    },
    isUserInitiatedChange: false,
    dynamicCurrencySymbol: '',
    dynamicCurrencyType: ''
  },
  actions: {
    ADD_TODO: function ({commit}, newTodo) {
      var setNew = {
        todo: newTodo,
        status: false
      }
      commit('ADD_TODO_MUTATION', setNew)
    },
    COMPLETE_TODO: function ({commit}, todo) {
      commit('COMPLETE_TODO_MUTATION', todo)
    },
    setCurrentPage: function ({commit}, pageNo) {
      commit('setCurrentPageMutation', pageNo)
    },
    setSearchData: function ({commit}, search) {
      var setData = {
        data: search.products,
        total: search.numberOfProducts
      }
      commit('setSearchDataMutation', setData)
    },
    setSearchPageNo: function ({commit}, pageNo) {
      commit('setSearchPageNoMutation', pageNo)
    },
    setSearchPageKey: function ({commit}, searchKey) {
      commit('setSearchKeyMutation', searchKey)
    },
    loadCountryFromLocalStorage ({ state, commit }) {
      const savedAddress = Vue.ls.get('selectedCountryAddress')
      if (savedAddress) {
        commit('SET_SELECTED_ADDRESS', savedAddress)
      } else {
        Vue.ls.set('selectedCountryAddress', state.selectedCountryAddress)
      }
    }
  },
  mutations: {
    ADD_TODO_MUTATION: function (state, newTodo) {
      state.todos.push(newTodo)
    },
    COMPLETE_TODO_MUTATION: function (state, todo) {
      state.todos.find(x => x.todo === todo).status = true
    },
    setCurrentPageMutation: function (state, pageNo) {
      state.currentPage = pageNo
    },
    setSearchDataMutation: function (state, data) {
      state.searchData = data
    },
    setSearchPageNoMutation: function (state, pageNo) {
      state.searchPageNo = pageNo
    },
    setSearchKeyMutation: function (state, searchKey) {
      state.searchKey = searchKey
    },
    MODIFY_OFFER_APPEAR_TIMER: function (state, timer) {
      state.offerAppearTimer = timer
    },
    DECREMENT_APPEAR_TIMER: function (state, time) {
      state.offerAppearTimer -= time
    },
    MODIFY_OFFER_TIMER: function (state, timer) {
      state.offerTimer = timer
    },
    DECREMENT_TIMER: function (state, time) {
      state.offerTimer -= time
    },
    WEBPUSH_INITIATOR: function (state, flag) {
      state.webpushInitiator = flag
    },
    USER_INTEREST_TIME: function (state, timeLog) {
      state.userInterestTime = timeLog
    },
    SET_FOOTER_COLLAPSE_CONTROL: (state, payload) => {
      state.footerCollapseControl = payload
    },
    SET_SELECTED_ADDRESS (state, address) {
      const addressValue = address.value ? address.value : address
      state.selectedCountryAddress = addressValue
    },
    SET_USER_INITIATED_CHANGE (state) {
      state.isUserInitiatedChange = true
    },
    SET_CURRENCY (state, payload) {
      if (payload) {
        state.dynamicCurrencySymbol = payload.currencySymbol
        state.dynamicCurrencyType = payload.currencyType
      }
    },
    RESET_SELECTED_ADDRESS (state) {
      state.selectedCountryAddress = {
        name: '',
        country: 'India',
        countryId: '99',
        isoCode: 'IND',
        isoCode2: 'IN'
      }
      Vue.ls.set('selectedCountryAddress', state.selectedCountryAddress)
    }
  },
  getters: {
    not_done: state => {
      var filtered = state.todos.filter(function (el) {
        return el.status === false
      })
      return filtered
    },
    done: state => {
      var filtered = state.todos.filter(function (el) {
        return el.status === true
      })
      return filtered
    },
    getCurrentPage: state => {
      return state.currentPage
    },
    getSearchData: state => {
      return state.searchData
    },
    getSearchPageNo: state => {
      return parseInt(state.searchPageNo)
    },
    getSearchKey: state => {
      return state.searchKey
    },
    webpushInitiator: state => state.webpushInitiator,
    userInterestTime: state => state.userInterestTime,
    footerCollapseControl: state => state.footerCollapseControl,
    isSelectedCountryIndia: state => {
      return state.selectedCountryAddress && state.selectedCountryAddress.isoCode === 'IND'
    },
    currencySymbol: (state, getters) => {
      if (state.dynamicCurrencySymbol) {
        return state.dynamicCurrencySymbol
      }
      // return getters.isSelectedCountryIndia ? '₹' : '$'
    },
    currencyRsToUSD: (state, getters) => {
      if (state.dynamicCurrencyType) {
        return state.dynamicCurrencyType
      }
      // return getters.isSelectedCountryIndia ? 'Rs.' : 'USD'
    },
    hasAddressChanged: (state) => {
      if (state.isUserInitiatedChange) {
        return state.selectedCountryAddress
      }
    }
  }
})

// export default store
