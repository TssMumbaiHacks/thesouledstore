import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home'
import store from '../store'
import {nginxTags} from '../assets/js/nginxTagsRedirection'

Vue.use(Router)

var $ = require('jquery')
window.jQuery = $

const router = new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/login',
      name: 'login',
      component: function (resolve) {
        require(['@/components/auth.vue'], resolve)
      }
      // meta: { requiresAuth: false }
    },
    {
      path: '/srp',
      name: 'srp',
      component: function (resolve) {
        require(['@/components/SearchResult.vue'], resolve)
      }
    },
    {
      path: '/virtual/:storeid',
      name: 'virtual',
      component: function (resolve) {
        require(['@/components/VirtualTry.vue'], resolve)
      }
    },
    {
      path: '/ward-list/:wname',
      name: 'ward-list',
      component: function (resolve) {
        require(['@/components/WardList.vue'], resolve)
      }
    }
  ],
  scrollBehavior (to, from, savedPosition) {
    if (to.hash) {
      // If the route has a hash (sectional link), scroll to the element with the corresponding ID.
      return {
        selector: to.hash,
        offset: { x: 0, y: 100 } // Adjust the offset as needed to accommodate any fixed headers or margins.
      }
    } else if (from.path === to.path && to.name === 'listing') {
      return {}
    }
    return {x: 0, y: 0}
  }
})

router.beforeEach((to, from, next) => {
  // const currentHostname = window.location.hostname
  if (to.path === '/pos/login/' && to.query.api_key === process.env.POS_LOGIN_API_KEY && to.query.token) {
    Vue.ls.set('tss_token', to.query.token)
    Vue.ls.set('pos_login', true)
    Vue.ls.set('pos_store_id', to.query.pos_store_id)
    Vue.ls.set('pos_user_id', to.query.pos_user_id)
    next({
      path: '/'
    })
  }
  const Datetiming = new Date()
  store && store.getters && store.getters.userInterestTime ? '' : store.commit('USER_INTEREST_TIME', Datetiming.getTime())
  if (to.path === '/login') {
    store.dispatch('CHECK_AUTH')
    if (store.getters.authStatus) {
      next({
        path: '/'
      })
    } else {
      next()
    }
  } else if (from.path === '/thank-you' && to.path === '/checkout') {
    next({
      path: '/'
    })
  } else if (to.path && to.path.includes('/tags/') && nginxTags && !nginxTags.includes(to.path) && to.params && to.params.sid) {
    if (to.query) {
      let params
      params = to.query
      next({
        path: `/${to.params.sid}`, query: params
      })
    } else {
      next({
        path: `/${to.params.sid}`
      })
    }
  } else if (to.matched.some(record => record.meta.requiresAuth)) {
    store.dispatch('CHECK_AUTH')
    if (!store.getters.authStatus) {
      next({
        path: '/login',
        query: {redirect: to.fullPath}
      })
    } else {
      next()
    }
  } else if (to.path && to.path.includes('///')) {
    next({
      path: '/notfound'
    })
  } else {
    next() // make sure to always call next()!
  }
})
export default router
