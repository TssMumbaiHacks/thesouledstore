export const RATING_JSON = [
  {value: 0, color: '#e94151'},
  {value: 1, color: '#e94151'},
  {value: 2, color: '#ed7433'},
  {value: 3, color: '#f8c533'},
  {value: 4, color: '#72eee2'},
  {value: 5, color: '#65d1b8'},
  {value: 6, color: '#5abba4'},
  {value: 7, color: '#72eee2'},
  {value: 8, color: '#76e67b'},
  {value: 9, color: '#74df49'},
  {value: 10, color: '#76e67b'}
]
