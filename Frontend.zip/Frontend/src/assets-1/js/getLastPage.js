export default function (path) {
  switch (path) {
    case 'deliveryaddress':
      return 'Delivery Address Page'
    case 'membership':
      return 'Exclusive Membership Page'
    case 'cart':
      return 'Cart Page'
    case 'home':
      return 'Home Page'
    case 'paymentoptions':
      return 'Checkout Page'
    case 'productdetails':
      return 'PDP Page'
    case 'listing':
      return 'PLP Page'
    case 'myorders':
      return 'My Orders Page'
    case 'contact':
      return 'Contact Us page'
    case 'mywishlist':
      return 'My Wishlist Page'
    case 'mygiftvoucher':
      return 'My GiftVouchers page'
    case 'myprofile':
      return 'Profile Page'
    case 'mySavedCards':
      return 'Saved Cards Page'
    case 'myrewardpointsTss':
      return 'TSS Points Page'
    case 'myrewardpointsMoney':
      return 'Tss Money Page'
    case 'faqs':
      return 'FAQ\'s Page'
    case 'giftvoucher':
      return 'Gift Voucher Page'
    case 'termsconditions':
      return 'Terms & Conditions Page'
    case 'privacyPolicy':
      return 'Privacy Policy Page'
    case 'sitemap':
      return 'Sitemap Page'
    case 'about':
      return 'AboutUs Page'
    case 'careers':
      return 'Carrers Page'
    case 'StoreLocator':
      return 'Store Locator Page'
    case 'souledarmy':
      return 'Souled Army Page'
    case 'thankyou':
      return 'Thank You Page'
    case 'Order Details':
      return 'Order Details Page'
    case 'cancelorder':
      return 'Cancel Order Page'
    case 'login':
      return 'OTP Login Page'
    case 'search':
      return 'Search Page'
    case 'submit-art-work':
      return 'Submit Art Work Page'
    case 'metaverseLanding':
      return 'Metaverse Page'
    case 'myAccount':
      return 'My Account Page'
    default:
      return path
  }
}
