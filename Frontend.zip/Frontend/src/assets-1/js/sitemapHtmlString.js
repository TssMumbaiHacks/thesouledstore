export function getSitemapHtmlString (data) {
  const splSymbolsRegex = /[^a-zA-Z\d\s:-\s.']/g
  return `
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <title>SiteMap</title>
        <style>
          .header {
          }
          .topbar{
            width: 100%;
            height: 25px;
            background-color: #ed2d2f;
          }
          .bottombar{
            width: 100%;
            height: 75px;
            box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.16);
            background-color: #ffffff;
          }
          .logo{
            width: 97px;
            height: 63.2px;
            margin: -120px 1786px 70px 37px;
            object-fit: contain;
          } 
          ul, #list-wrapper {
            list-style-type: none;
          }

          #list-wrapper {
            margin: 0;
            padding: 0;
            margin-left: 40px;
          }

          .caret {
            cursor: pointer;
            -webkit-user-select: none; 
            -moz-user-select: none; 
            -ms-user-select: none; 
            user-select: none;
          }

          .caret::before {
            content: "\\25BD";
            color: #ed2d2f;
            display: inline-block;
            margin: 10px 6px 2px 6px;
          }

          .caret-down::before {
            -ms-transform: rotate(-90deg); 
            -webkit-transform: rotate(-90deg); 
            transform: rotate(-90deg);  
          }

          .nested {
            display: block;
          }

          .active {
            display: none;
          }
        </style>
      </head>
      <body>
        <div>
          <div class="header">
            <div class="topbar"></div>
            <div class="bottombar"></div>
            <div class="logo"><img src="https://www.thesouledstore.com/static/img/newlogosticky.f7f01f0.png" alt="logo" width="140" height="140"></img></div>
          </div>
          <div>
            <ul id="list-wrapper"></ul>
          </div>
          <script>
            const navMenuData = ${JSON.stringify(data, null, 4)}
            const symbolsRegex = ${splSymbolsRegex}
            const listWrapper = document.getElementById('list-wrapper')
            navMenuData.forEach(item => {
              const liEl = document.createElement('LI')
              const spanEl = document.createElement('SPAN')
              spanEl && spanEl.classList.add('caret')
              if (item.url_key){
                const anchorEl = document.createElement('A')
                anchorEl.href = item.url_key.includes('http') ? item.url_key : 'https://www.thesouledstore.com' + item.url_key
                anchorEl.target = "_blank"
                anchorEl.appendChild(document.createTextNode(item.name && item.name.replace(symbolsRegex,'')))
                spanEl.appendChild(anchorEl)
              } else {
                spanEl.appendChild(document.createTextNode(item.name && item.name.replace(symbolsRegex,'')))
              }
              liEl.appendChild(spanEl)
              if (item.categories && item.categories.length) {
                const subUlEl = document.createElement('UL')
                subUlEl && subUlEl.classList.add('nested')
                item.categories.forEach(category => {
                  const subLiEl = document.createElement('LI')
                  const subSpanEl = document.createElement('SPAN')
                  subSpanEl && subSpanEl.classList.add('caret')
                  if (category.url_key) {
                    const subAnchorEl = document.createElement('A')
                    subAnchorEl.href = category.url_key.includes('http') ? category.url_key : 'https://www.thesouledstore.com' + category.url_key
                    subAnchorEl.target = "_blank"
                    subAnchorEl.appendChild(document.createTextNode(category.name && category.name.replace(symbolsRegex,'')))
                    subSpanEl.appendChild(subAnchorEl)
                  } else {
                    subSpanEl.appendChild(document.createTextNode(category.name && category.name.replace(symbolsRegex,'')))
                  }
                  subLiEl.appendChild(subSpanEl)
                  if (category.sub_categories && category.sub_categories.length) {
                    const subSubUlEl = document.createElement('UL')
                    subSubUlEl && subSubUlEl.classList.add('nested')
                    category.sub_categories.forEach(subCategory=>{
                      const subSubLiEl = document.createElement('LI')
                      const subSubSpanEl = document.createElement('SPAN')
                      if (subCategory.url_key){
                        const subSubAnchorEl = document.createElement('A')
                        subSubAnchorEl.href = subCategory.url_key.includes('http') ? subCategory.url_key : 'https://www.thesouledstore.com' + subCategory.url_key
                        subSubAnchorEl.target = "_blank"
                        subSubAnchorEl.appendChild(document.createTextNode(subCategory.name && subCategory.name.replace(symbolsRegex,'')))
                        subSubSpanEl.appendChild(subSubAnchorEl)
                      } else {
                        subSubSpanEl.appendChild(document.createTextNode(subCategory.name && subCategory.name.replace(symbolsRegex,'')))
                      }
                      subSubSpanEl && subSubSpanEl.classList.add('caret')
                      subSubLiEl.appendChild(subSubSpanEl)
                      subSubUlEl.appendChild(subSubLiEl)
                    })
                    subLiEl.appendChild(subSubUlEl)
                  }
                  subUlEl.appendChild(subLiEl)
                })
                liEl.appendChild(subUlEl)
              }
              listWrapper.appendChild(liEl)
            })
            var toggler = document.getElementsByClassName("caret");
            var i;
            
            for (i = 0; i < toggler.length; i++) {
              toggler[i].addEventListener("click", function() {
                this.classList.toggle("caret-down");
                this.parentElement.querySelector(".nested").classList.toggle("active");
              });
            }
          </script>
        </div>
      </body>
    </html>`
}
