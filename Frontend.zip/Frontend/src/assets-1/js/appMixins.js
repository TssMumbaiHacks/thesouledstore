var $ = require('jquery')
window.jQuery = $
import auth from '../../auth/index.js'
// import moment from 'moment/src/moment'
import moment from 'moment'
import 'moment/locale/fr' // For example, to load the French locale
moment.locale('fr')
// import store from '../../store/index'

export const appMixins = {
  data () {
    return {
      isDesktop: '',
      isxsMobile: '',
      cartCnt: 0,
      splitimg: [],
      loading: '',
      domain: process.env.APP_URL,
      loginshow: false,
      myaccount: false,
      thumbpath: process.env.IMG_BASE_URL + process.env.PRODUCT_IMG,
      footerTextMixin: '',
      userAcc: auth.user,
      imageview: false,
      magImage: {},
      modelStatus: false,
      chekView: ''
    }
  },
  methods: {
    showloginModal () {
      this.loginshow = true
    },
    hideloginModal () {
      this.loginshow = true
    },
    newAccount () {
      this.loginshow = false
      this.$router.push('/login')
    },
    getround: function (val) {
      return parseInt(val)
    },
    currencyFormate (currency) {
      var c = ''
      if (currency) {
        c = currency.toLocaleString()
        return c
      } else {
        return c
      }
    },
    isValidImageUrlWithFormatCheck (url) {
      if (!url) {
        return false
      }
      const imageFormats = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp']
      const extension = url.split('.').pop().toLowerCase()
      return imageFormats.includes(extension)
    },
    checkoutvalide () {
      if (this.cartCnt > 0) {
        this.$router.push('delivery-address')
      } else {
        alert('Add Products in Cart')
      }
    },
    getDateFormat: function (date) {
      return moment(date, 'YYYY-MM-DD').format('DD MMM, YYYY') || ''
    },
    getDateFormatByDDMMYY: function (date) {
      return moment(date, 'DD/MM/YYYY').format('DD MMM, YYYY') || ''
    },
    getDateFormatByMMDDYY: function (date) {
      return moment(date, 'DD/MM/YYYY').format('MMM DD, YYYY') || ''
    },
    isCorporateProduct: function (artistSlug) {
      return artistSlug === 'tss-corporate' || artistSlug === 'nestle-polo'
    },
    dateformate: function (date) {
      var mydate = new Date(date.replace(/\s/, 'T'))
      let monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
      var day = mydate.getDate()
      var monthIndex = mydate.getMonth()
      var year = mydate.getFullYear()
      return day + ' ' + monthNames[monthIndex] + ' ' + year
    },
    formatDateToGivenFormat: function (date, format = 'MMM D, YYYY h:mm A') {
      return date ? moment(date).format(format) : ''
    },
    formateDateToDDMMYYYY: function (d) {
      let date = d ? new Date(d) : new Date()
      let month = String(date.getMonth() + 1)
      let day = String(date.getDate())
      const year = String(date.getFullYear())
      if (month.length < 2) {
        month = '0' + month
      }
      if (day.length < 2) {
        day = '0' + day
      }
      return `${day}-${month}-${year}`
    },
    // getDateSubscript: function (day) {
    //   var n = ''
    //   if (day > 3 && day < 21) return 'th'
    //   switch (day % 10) {
    //     case 1:
    //       n = 'st'
    //       break
    //     case 2:
    //       n = 'nd'
    //       break
    //     case 3:
    //       n = 'rd'
    //       break
    //     default:
    //       n = 'th'
    //       break
    //   }
    //   return n
    // },
    getFullMonthName: function (date = new Date()) {
      return date.toLocaleString('default', {month: 'long'})
    },
    removeChar (str) {
      var b = str.slice(0, -1)
      return b
    },
    magnifyimage (img, url) {
      this.$store.commit('GTAG_EVENT', {eventName: 'Size_Chart_Viewed', payload: {}})
      this.imageview = true
      this.magImage = {'img': img, 'url': url}
    },
    // stringArray (ab) {
    //   var b = ab.replace('[', '').replace(']', '').replace('"', '').replace('"', '')
    //   return b
    // },
    formatDateSale: function (date) {
      return moment(date)
    },
    getOrderStatusStyle: function (status) {
      switch (status.toLowerCase()) {
        case 'order placed':
          return { 'border-color': '#148c8d' }
        case 'cancelled':
          return { 'background-color': '#ed3031', 'border-color': '#ed3031' }
        case 'shipped':
          return { 'border-color': '#148c8d' }
        case 'delivered':
          return { 'background-color': '#148c8d', 'border-color': '#148c8d' }
        case 'return initiated':
          return { 'border-color': '#fd8724' }
        case 'return_initiated':
          return { 'border-color': '#fd8724' }
        case 'self initiated':
          return { 'border-color': '#fd8724' }
        case 'self return':
          return { 'border-color': '#fd8724' }
        case 'return received':
          return { 'background-color': '#fd8724', 'border-color': '#fd8724' }
        case 'rto':
          return { 'border-color': '#148c8d' }
        case 'exchange initiated':
          return { 'border-color': '#fd8724' }
        case 'product picked up':
          return { 'background-color': '#fd8724', 'border-color': '#fd8724' }
        case 'exchange shipped':
          return { 'border-color': '#fd8724' }
        case 'exchange in transit':
          return { 'background-color': '#fd8724', 'border-color': '#fd8724' }
        case 'exchange out for delivery':
          return { 'background-color': '#fd8724', 'border-color': '#fd8724' }
        case 'exchange delivered':
          return { 'background-color': '#148c8d', 'border-color': '#148c8d' }
        case 'exchange completed':
          return { 'background-color': '#148c8d', 'border-color': '#148c8d' }
        case 'exchange terminated':
          return { 'background-color': '#ed3031', 'border-color': '#ed3031' }
        default:
          return { 'border-color': 'grey' }
      }
    }
  },
  created () {
    var b = $(window).width()
    if (b < 991) {
      this.isDesktop = false
    } else {
      this.isDesktop = true
    }
    if (b < 450) {
      this.isxsMobile = true
    } else {
      this.isxsMobile = false
    }
  },
  mounted: function () {
    window.addEventListener('resize', () => {
      var b = $(window).width()
      if (b < 991) {
        this.isDesktop = false
      } else {
        this.isDesktop = true
      }
      if (b < 450) {
        this.isxsMobile = true
      } else {
        this.isxsMobile = false
      }
    })
  },
  computed: {
    authCheck () {
      this.ckuser = this.userAcc.authenticated
      var tk = this.ckuser
      return tk
    },
    pghead () {
      var content = this.head
      return content
    },
    footerData () {
      var c = this.footerTextMixin
      return c
    },
    cartQuantity () {
      var citems = this.cartCnt
      return citems
    },
    getUsername () {
      // var b = this.$localStorage.get('username')
      // if (b) {
      //   return b
      // } else {
      //   return 'Click to login'
      // }
    },
    popupStatus () {
      var b = this.modelStatus
      // console.log(b)
      if (b === false) {
        // console.log('f5555')
        $('body').removeClass('modelOpen')
      } else {
        // console.log('3241')
        $('body').addClass('modelOpen')
      }
      return b
    },
    pageView () {
      return this.chekView
    },
    isBflUtm () {
      const {utm_source: utmSource, utm_medium: utmMedium} = this.$route && this.$route.query
      return (utmSource && utmSource.toLowerCase().includes('bfl')) || (utmMedium && utmMedium.toLowerCase().includes('bfl'))
    }
  },
  watch: {
    '$route' (to, from) {
      this.footerTextMixin = ''
    }
  }
}
export const textTruncate = {
  methods: {
    textTruncate: function (str, length, ending) {
      if (length == null) {
        length = 100
      }
      if (ending == null) {
        ending = '...'
      }
      if (str.length > length) {
        return str.substring(0, length - ending.length) + ending
      } else {
        return str
      }
    }
  }
}
export const wrapperBottomVisible = {
  methods: {
    wrapperBottomVisible (elementId) {
      const listingWrapperEl = document.getElementById(elementId)
      if (listingWrapperEl) {
        const rect = listingWrapperEl.getBoundingClientRect()
        return (rect.bottom - 600) <= (window.innerHeight || document.documentElement.clientHeight)
      }
    }
  }
}
export const osDetector = {
  methods: {
    getMobileOperatingSystem () {
      var userAgent = navigator.userAgent || navigator.vendor || window.opera
      // Windows Phone must come first because its UA also contains "Android"
      if (/windows phone/i.test(userAgent)) {
        return 'windowsPhone'
      }
      if (/android/i.test(userAgent)) {
        return 'android'
      }
      // iOS detection from: http://stackoverflow.com/a/9039885/177710
      if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
        return 'ios'
      }
      return 'unknown'
    }
  }
}
export const browserDetector = {
  methods: {
    getSystemBrowser () {
      let userAgentString = navigator.userAgent
      // Detect Chrome
      let chromeAgent = userAgentString.indexOf('Chrome') > -1
      // Detect Internet Explorer
      let IExplorerAgent = userAgentString.indexOf('MSIE') > -1 || userAgentString.indexOf('rv:') > -1
      if (IExplorerAgent) {
        return 'internetExplorer'
      }
      // Detect Firefox
      let firefoxAgent = userAgentString.indexOf('Firefox') > -1
      if (firefoxAgent) {
        return 'firefox'
      }
      // Detect Safari
      let safariAgent = userAgentString.indexOf('Safari') > -1
      // Discard Safari since it also matches Chrome
      if ((chromeAgent && safariAgent) || (userAgentString.match(/CriOS/i))) {
        safariAgent = false
      }
      if (safariAgent) {
        return 'safari'
      }
      // Detect Opera
      let operaAgent = userAgentString.indexOf('OP') > -1
      // Discard Chrome since it also matches Opera
      if ((chromeAgent) && (operaAgent)) {
        return 'opera'
      }
      return 'chrome'
    }
  }
}

export const sessionStorageMixin = {
  methods: {
    saveToSessionStorage (key, value) {
      try {
        sessionStorage.setItem(key, JSON.stringify(value))
      } catch (error) {
        console.error('Error saving to session storage:', error)
      }
    },
    getFromSessionStorage (key) {
      try {
        const item = sessionStorage.getItem(key)
        return item ? JSON.parse(item) : null
      } catch (error) {
        console.error('Error getting from session storage:', error)
        return null
      }
    },
    removeFromSessionStorage (key) {
      try {
        sessionStorage.removeItem(key)
      } catch (error) {
        console.error('Error removing from session storage:', error)
      }
    }
  }
}
