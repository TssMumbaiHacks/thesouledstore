export const reversePickUp = [
  'Ensure that the product is in good condition and the tags are intact',
  'Pack the product securely to prevent any loss or damage during transit',
  'The product will be picked up by our courier partners within 3 working days',
  'Once the product is picked up, your refund will be initiated in your preferred mode'
]

export const selfShip = [
  'Ensure that the product is in good condition and the tags are intact',
  'Pack the product securely to prevent any loss or damage during transit',
  'Ship the product back to us on the address mentioned below:',
  'As soon as the courier receipt is sent to <a href="mailto:connect@thesouledstore.com" class="fblue">connect@thesouledstore.com </a>, a refund will be initiated to your preferred mode.',
  'An additional amount of ₹ 100 will be credited to your account as TSS Money for the courier charges you incur.'
]
export const reversePickUpAndDrop = [
  'Ensure that the product is in good condition and the tags are intact',
  'Pack the product securely to prevent any loss or damage during transit',
  'The product will be picked up by our courier partners within 3 working days',
  'Once the product is picked up, a fresh product will be dispatched from our warehouse within 3-4 working days'

]
