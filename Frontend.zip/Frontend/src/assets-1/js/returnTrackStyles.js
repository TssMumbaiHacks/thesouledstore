export const styles = {
  colors: {
    blueGreen: '#148c8d',
    red: '#ed3031',
    lightOrange: '#fd8724',
    dark: '#58595b'
  },
  stepperContainer: {
    display: 'flex',
    flexDirection: 'column',
    flex: 1
  },
  flexRow: {
    display: 'flex',
    flexDirection: 'row'
  },
  dotContainer: {
    width: '15px',
    height: '15px',
    borderRadius: '50%',
    backgroundColor: '#ffffff',
    borderWidth: '2px',
    borderStyle: 'solid',
    borderColor: '#e0e0e0'
  },
  lineContainer: {
    width: '2px',
    backgroundColor: '#cccccc',
    height: '50%',
    minHeight: '40px',
    marginLeft: '7px'
  },
  steperTextContainer: {
    marginTop: '-5px',
    marginLeft: '15px',
    paddingBottom: '30px'
  },
  stepperTitleText: {
    fontSize: '14px',
    fontfamily: "'Source Sans Pro', sans-serif",
    fontweight: '600',
    color: '#58595b',
    margin: '0px',
    padding: '0px'
  },
  stepperTitleTextDate: {
    fontSize: '12px',
    fontfamily: "'Source Sans Pro', sans-serif",
    fontweight: '600',
    color: '#58595b',
    margin: '0px',
    padding: '0px'
  },
  trackingText: {
    // fontFamily: 'source_sans_pro',
    fontSize: '12px',
    lineHeight: '1.25',
    letterSpacing: '0.15px',
    color: '#148c8d',
    cursor: 'pointer'
  },
  dateFormat: {
    color: '#148c8d',
    fontfamily: "'Source Sans Pro', sans-serif",
    fontweight: '600',
    marginBottom: '10px',
    marginTop: '20px'
  },
  categoryText: {
    fontSize: '12px',
    fontfamily: "'Source Sans Pro', sans-serif",
    fontweight: '400',
    color: '#a7a9ac',
    margin: '0px',
    padding: '0px'
  },
  trackMsgContainer: {
    padding: '10px',
    borderRadius: '2px',
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: '#dbc666',
    backgroundColor: '#fcfbf7'
  },
  trackSuccessMsgContainer: {
    padding: '10px',
    borderRadius: '2px',
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: '#148c8d',
    backgroundColor: 'rgba(29, 184, 161, 0.09)'
  },
  trackMsg: {
    lineHeight: '1.29',
    letterSpacing: '0.18px',
    fontfamily: "'Source Sans Pro', sans-serif",
    fontweight: '400',
    fontSize: '14px'
  }
}
