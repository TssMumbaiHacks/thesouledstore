import Vue from 'vue'

export default {
  signupWithHaptikSDK () {
    const tssToken = Vue.ls.get('tss_token')

    const authOptions = {
      auth_id: Vue.ls.get('tss_token'),
      auth_code: Vue.ls.get('tss_token'),
      custom_data: { loggedin: 'yes', token: tssToken }
    }
    window.HaptikSDK.signup(authOptions, (success, error, data) => {
      if (success) {
        window.HaptikSDK.show()
      } else {
        console.log(error)
      }
    })
  },
  initializeHaptikSDK () {
    document.addEventListener('haptik_sdk', () => {
      this.signupWithHaptikSDK()
    })
  },
  hideChatBot () {
    window.HaptikSDK.hide()
  }
}
