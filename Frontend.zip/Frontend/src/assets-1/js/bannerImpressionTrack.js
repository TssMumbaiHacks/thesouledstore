import store from '../../store'
import Vue from 'vue'
export default {
  componentUpdated: (el, binding) => {
    function loadImage () {
      const imageElement = Array.from(el.children).find(
        el => el.nodeName === 'IMG'
      )
      const renderWidth = el.getBoundingClientRect().width
      let compressedImg = renderWidth && renderWidth > 0 ? `${imageElement && imageElement.dataset && imageElement.dataset.url}` : ``
      if (imageElement && imageElement.dataset && imageElement.dataset.src !== compressedImg) {
        imageElement.addEventListener('load', () => {
          if (binding && binding.value) {
            store.dispatch('ECOMMERCE_EVENT', {eventName: 'view_promotion',
              payload: {
                creative_name: binding.value.creative_name || 'NA',
                creative_slot: binding.value.creative_slot || binding.value.creative_slot === 0 ? binding.value.creative_slot : 'NA',
                promotion_id: binding.value.promotion_id || 'NA',
                promotion_name: binding.value.promotion_name || 'NA'
              }
            })
          }
          setTimeout(() => {
            el.classList.add('loaded')
            let checkDrop = Vue.ls.get('pdp_checkDrop')
            if (checkDrop) {
              el.classList.add('customFade-active-drop')
            } else {
              imageElement.classList.add('customFade-active')
            }
          }, 100)
        })
        imageElement.addEventListener('error', () => console.log('error'))
        imageElement.dataset.src = compressedImg
      }
    }
    function handleIntersect (entries, observer) {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          loadImage()
          observer.unobserve(el)
        }
      })
    }
    function createObserver () {
      const options = {
        root: null,
        threshold: '0'
      }
      const observer = new IntersectionObserver(handleIntersect, options)
      observer.observe(el)
    }
    if ((!binding.hasOwnProperty('value')) || binding.value) {
      if (window['IntersectionObserver']) {
        createObserver()
      } else {
        loadImage()
      }
    }
  },
  inserted: (el, binding) => {
    function loadImage () {
      const imageElement = Array.from(el.children).find(
        el => el.nodeName === 'IMG'
      )
      const renderWidth = el.getBoundingClientRect().width
      let compressedImg = renderWidth && renderWidth > 0 ? `${imageElement && imageElement.dataset && imageElement.dataset.url}` : ``
      if (imageElement && imageElement.dataset && imageElement.dataset.src !== compressedImg) {
        imageElement.addEventListener('load', () => {
          if (binding && binding.value) {
            store.dispatch('ECOMMERCE_EVENT', {eventName: 'view_promotion',
              payload: {
                creative_name: binding.value.creative_name || 'NA',
                creative_slot: binding.value.creative_slot || binding.value.creative_slot === 0 ? binding.value.creative_slot : 'NA',
                promotion_id: binding.value.promotion_id || 'NA',
                promotion_name: binding.value.promotion_name || 'NA'
              }
            })
          }
          setTimeout(() => {
            el.classList.add('loaded')
            let checkDrop = Vue.ls.get('pdp_checkDrop')
            if (checkDrop) {
              el.classList.add('customFade-active-drop')
            } else {
              imageElement.classList.add('customFade-active')
            }
          }, 100)
        })
        imageElement.addEventListener('error', () => console.log('error'))
        imageElement.dataset.src = compressedImg
      }
    }
    function handleIntersect (entries, observer) {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          loadImage()
          observer.unobserve(el)
        }
      })
    }
    function createObserver () {
      const options = {
        root: null,
        threshold: '0'
      }
      const observer = new IntersectionObserver(handleIntersect, options)
      observer.observe(el)
    }
    if ((!binding.hasOwnProperty('value')) || binding.value) {
      if (window['IntersectionObserver']) {
        createObserver()
      } else {
        loadImage()
      }
    }
  }
}
