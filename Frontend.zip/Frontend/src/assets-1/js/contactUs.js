export const ORDER_STATUS = {
  '2': [1, 18, 2, 8, 26, 16],
  '3': [3, 16],
  '6': [10, 14],
  '7': [3],
  '8': [3],
  '9': [3, 17]
}

export const ORDER_STATUS_MSG = {
  '1': "We've received your order and we usually ship them out in 1 -2 days.",
  '2': 'Your box of happiness has been dispatched and you can track your order from the My Orders section in your profile.',
  '18': 'Your box of happiness has been dispatched and you can track your order from the My Orders section in your profile.',
  '26': 'Your order is out for delivery and will be delivered today. Please be avaiable at the address to accept your package.',
  '16': 'Our courier partner attempted to deliver your order but was unable to do so. Don’t worry, your delivery will be reattempted. Please check your email/ whatsapp for the next steps.',
  '3': 'Hurray! Your order has been delivered!'
}
