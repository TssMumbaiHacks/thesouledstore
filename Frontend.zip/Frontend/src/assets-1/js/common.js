export const childrenDayFunds = [
  {
    prod_id: 187132,
    amount: 100,
    name: 'Special Children Day Fundraiser: Rs 100',
    url_key: 'special-children-day-fundraiser-rs-100'
  },
  {
    prod_id: 187133,
    amount: 250,
    name: 'Special Children Day Fundraiser: Rs 250',
    url_key: 'special-children-day-fundraiser-rs-250'
  },
  {
    prod_id: 187134,
    amount: 500,
    name: 'Special Children Day Fundraiser: Rs 500',
    url_key: 'special-children-day-fundraiser-rs-500'
  },
  {
    prod_id: 187135,
    amount: 700,
    name: 'Special Children Day Fundraiser: Rs 700',
    url_key: 'special-children-day-fundraiser-rs-700'
  },
  {
    prod_id: 187136,
    amount: 1000,
    name: 'Special Children Day Fundraiser: Rs 1000',
    url_key: 'special-children-day-fundraiser-rs-1000'
  }
]
export const getBrowser = () => {
  const userAgentString = navigator.userAgent
  let name = 'Not known'
  if (userAgentString.indexOf('MSIE') > -1 || userAgentString.indexOf('rv:') > -1) {
    name = 'Internet Explorer'
  }
  if (userAgentString.indexOf('Firefox') > -1) {
    name = 'Firefox'
  }
  if (userAgentString.indexOf('Safari') > -1) {
    name = 'Safari'
  }
  if (userAgentString.indexOf('Chrome') > -1) {
    name = 'Chrome'
  }
  if (userAgentString.indexOf('OP') > -1) {
    name = 'Opera'
  }
  return name
}

export const isDesktop = () => {
  const deviceWidth = screen.width
  if (deviceWidth > 991) {
    return true
  }
  return false
}
export const getProductUrl = (isPdp, url, genderType) => {
  if (isPdp) {
    return window.location.origin + '/product/' + url + '?gte=' + genderType
  }
  return window.location.origin + url
}

const addressLabels = {
  99: {
    firstName: 'First Name*',
    lastName: 'Last Name*',
    address1: 'House No., Building Name*',
    address2: 'Street Name, Area*',
    address3: 'Landmark',
    city: 'City/District*',
    postcode: 'Postal Code*',
    countryId: 'Country*',
    zone_id: 'State*',
    phone_no: 'Phone No.*',
    email: 'Email Id.*'
  },
  222: {
    firstName: 'First Name*',
    lastName: 'Last Name*',
    address1: 'House No., Building Name*',
    address2: 'Street Name, Area*',
    address3: 'Landmark',
    city: 'Town/City*',
    postcode: 'Postal Code*',
    countryId: 'Country*',
    zone_id: 'County*',
    phone_no: 'Phone No.*',
    email: 'Email Id.*'
  },
  221: {
    firstName: 'First Name*',
    lastName: 'Last Name*',
    address1: 'House No., Building Name*',
    address2: 'Street Name, Area*',
    address3: 'P.O. Box',
    city: 'City*',
    postcode: 'Postal Code*',
    countryId: 'Country*',
    zone_id: 'Emirate*',
    phone_no: 'Phone No.*',
    email: 'Email Id.*'
  },
  223: {
    firstName: 'First Name*',
    lastName: 'Last Name*',
    address1: 'Street Address 1*',
    address2: 'Street Address 2',
    address3: 'Landmark',
    city: 'Town/City*',
    postcode: 'Zip Code*',
    countryId: 'Country*',
    zone_id: 'State*',
    phone_no: 'Phone No.*',
    email: 'Email Id.*'
  },
  0: {
    firstName: 'First Name*',
    lastName: 'Last Name*',
    address1: 'House No., Building Name*',
    address2: 'Street Name, Area*',
    address3: 'Landmark',
    city: 'City/District*',
    postcode: 'Postal Code*',
    countryId: 'Country*',
    zone_id: 'State*',
    phone_no: 'Phone No.*',
    email: 'Email Id.*'
  }
}

export const getAddressLabel = (countryId, label) => {
  if (addressLabels[countryId]) {
    if (addressLabels[countryId][label]) {
      return addressLabels[countryId][label]
    } else {
      return `Label not found for ${countryId}`
    }
  } else {
    if (addressLabels[0][label]) {
      return addressLabels[0][label]
    } else {
      return `Label not found for ${countryId}`
    }
  }
}

export function getCookie (name) {
  const value = `; ${document.cookie}`
  const parts = value.split(`; ${name}=`)
  if (parts.length === 2) return parts.pop().split(';').shift()
}

export function getFbcId (fbclid) {
  let _fbc = getCookie('_fbc')
  if (_fbc) {
    return _fbc
  }
  const now = Date.now()
  if (fbclid) {
    return `fb.0.${now}.${fbclid}`
  }
  return 'NA'
}
