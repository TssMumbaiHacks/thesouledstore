export const metaElements = {
  data () {
    return {
      metaTitle: '',
      metaDescription: '',
      metaKeywords: 'Designer T-shirts, Frames, Posters, Badges, Stickers, Notebooks, Coasters',
      metaUrl: 'https://www.thesouledstore.com/',
      metaImage: 'https://www.thesouledstore.com/static/img/newlogosticky.f7f01f0.png',
      ogTitle: '',
      ogDescription: '',
      metaTwitterImage: 'https://www.thesouledstore.com/static/img/300x157-twitter.png',
      metaTwitterTitle: '',
      metaTwitterDescription: '',
      locationhref: location && location.href
    }
  },
  methods: {
    getAsyncData: function () {
      var self = this
      window.setTimeout(function () {
        self.$emit('updateHead')
      }, 1000)
    },
    getCanonicalData: function () {
      var CanonicalTag = document.querySelector('link[rel="canonical"]')
      var hrefParts = location.href.split('?')
      var canonicalUrl = hrefParts.length > 1 ? hrefParts[0] : location.href
      CanonicalTag.href = canonicalUrl
    }
  },
  head: {
    title: function () {
      return {
        inner: this.mtitle
      }
    },
    meta: function () {
      return [
        {name: 'title', inner: this.mtitle, id: 'title'},
        {name: 'description', content: this.mdescription, id: 'desc'},
        {name: 'keywords', content: this.mkeywords, id: 'keywords'},
        {name: 'og:title', content: this.mtitle, id: 'ogtitle'},
        {name: 'og:description', content: this.mdescription, id: 'ogdesc'},
        {name: 'og:url', content: this.murl, id: 'ogurl'},
        {name: 'og:image', content: this.mimage, id: 'ogimage'},
        {name: 'twitter:title', content: this.mtitle, id: 'twittertitle'},
        {name: 'twitter:description', content: this.mdescription, id: 'twitterdescription'},
        {name: 'twitter:image', content: this.mtwitterimage, id: 'twitterimage'}
        // {rel: 'canonical', href: this.canonicalhref, id: 'canonical'}
      ]
    }
  },
  mounted: function () {
    this.getAsyncData()
    this.getCanonicalData()
  },
  computed: {
    mtitle () {
      if (this.metaTitle) {
        return this.metaTitle
      }
      return ''
    },
    mdescription () {
      return this.metaDescription || ''
    },
    mkeywords () {
      return this.metaKeywords || ''
    },
    mtwitterimage () {
      return this.metaTwitterImage || ''
    },
    mtwittertitle () {
      return this.metaTwitterTitle || ''
    },
    mtwitterdescription () {
      return this.metaTwitterDescription || ''
    },
    murl () {
      return this.metaUrl || ''
    },
    mimage () {
      return this.metaImage || ''
    },
    ogtitle () {
      return this.ogTitle || ''
    },
    ogdescription () {
      return this.ogDescription || ''
    }
    // canonicalhref () {
    //   return this.locationhref || ''
    // }
  },
  watch: {
    'metaTitle' (to, from) {
      this.getAsyncData()
    },
    'locationhref' (to, from) {
      this.getCanonicalData()
    },
    '$route' (to, from) {
      this.getCanonicalData()
    }
  }
}
