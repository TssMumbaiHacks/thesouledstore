import store from '../../store'
import Vue from 'vue'

export default {
  componentUpdated: handleImageLoad,
  inserted: handleImageLoad
}

function handleImageLoad (el, binding) {
  function loadImage () {
    const hoverImg = Array.from(el.children).find(child => child.className === 'listhoverimg')
    const imageElement = Array.from(el.children).find(child => child.nodeName === 'IMG')

    if (!imageElement) return

    const renderWidth = el.getBoundingClientRect().width
    const compressedImg = renderWidth > 0 ? imageElement.dataset.url : ''
    let extractedGumletConfig = null

    if (imageElement.dataset.src !== compressedImg) {
      imageElement.dataset.src = compressedImg

      imageElement.addEventListener('load', () => {
        handleImageLoadSuccess(binding, el, imageElement, hoverImg, compressedImg, extractedGumletConfig)
      })

      imageElement.addEventListener('error', () => console.log('Error loading image'))
    }
  }

  function handleImageLoadSuccess (binding, el, imageElement, hoverImg, compressedImg, extractedGumletConfig) {
    if (binding && binding.value) {
      const localBindingValue = { ...binding.value }
      const searchTerm = localBindingValue.searchTerm || ''

      if (localBindingValue.searchTerm) delete localBindingValue.searchTerm

      store.commit('EC_PLP_PROD_VIEW_PUSH', {
        ...localBindingValue,
        item_list_name: localBindingValue.item_list_name || 'NA'
      })

      store.commit('MOENGAGE_PLP_PROD_VIEW_PUSH', localBindingValue)
      handleImpressionDelayed(searchTerm, 200)
    }

    setTimeout(() => {
      el.classList.add('loaded')
      const checkDrop = Vue.ls.get('pdp_checkDrop')
      if (checkDrop) {
        el.classList.add('customFade-active-drop')
      } else {
        imageElement.classList.add('customFade-active')
      }
    }, 1)

    if (!extractedGumletConfig) {
      extractedGumletConfig = extractGumletConfig(imageElement.src)
    }

    if (hoverImg && window.innerWidth >= 768) {
      const compressedHoverImg = `${hoverImg.dataset.url}${extractedGumletConfig ? `?${extractedGumletConfig}` : ''}`
      if (hoverImg.style.backgroundImage !== `url(${compressedHoverImg})`) {
        hoverImg.style.backgroundImage = `url(${compressedHoverImg})`
      }
    }
  }

  function extractGumletConfig (src) {
    const extractor = src && src.includes('?') && src.split('?')
    return extractor && extractor[1] ? extractor[1] : ''
  }

  function handleImpressionDelayed (searchTerm, delayTime) {
    setTimeout(() => {
      handleImpression(searchTerm)
    }, delayTime)
  }

  function handleImpression (searchTerm) {
    if (store.getters.tatvicProductImpression.data.length >= 1) {
      store.dispatch('ECOMMERCE_EVENT', {
        eventName: 'view_item_list',
        payload: {
          items: [...store.getters.tatvicProductImpression.data]
        }
      })

      store.commit('EC_PLP_PROD_VIEW_RESET')
    }
  }

  function handleIntersect (entries, observer) {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        loadImage()
        observer.unobserve(el)
      }
    })
  }

  function createObserver () {
    const observer = new IntersectionObserver(handleIntersect, {
      root: null,
      threshold: 0
    })

    observer.observe(el)
  }

  if ('IntersectionObserver' in window) {
    createObserver()
  } else {
    loadImage()
  }
}
