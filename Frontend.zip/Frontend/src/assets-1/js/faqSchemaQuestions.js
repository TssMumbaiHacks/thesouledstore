export const faqSchemaQuestions = [
  {
    name:
      'Is it safe to shop online if I make payment using Net Banking, Debit Card, or Credit Card?',
    text:
      'All Credit Card, Debit Card, and Net Banking transactions are processed over a secure encrypted conne'
  },
  {
    name: 'Why am I not getting any COD option on the payment page?',
    text:
      'If the COD option is not showing, it’s because this facility is unavailable for your postal code. You can either pay by Debit Card, Credit Card, or Net Banking, or you can get the products delivered to an alternate address (where COD is available).'
  },
  {
    name: 'Are there any hidden charges?',
    text:
      'There are absolutely NO hidden charges for any of our products- what you see is what you pay.'
  },
  {
    name: 'What should I do if my payment fails?',
    text:
      'In case there is a failure in payment, please retry and keep the following things in mind:Please confirm if the information you’ve provided is correct i.e. account details, billing address, and password (for Net Banking); and that your internet connection wasn’t disrupted during the process.If your account has been debited even after a payment failure, it is normally rolled back to your bank account within 10 business days. For any further clarification, you can email us at connect@thesouledstore.com.'
  },
  {
    name: 'How do I place my order?',
    text: `To place your order, follow these steps :   
          Browse through our wide range of products until you find something you like. After you’ve chosen what you want, select the relevant size, if applicable. You can check out our size chart for reference.
          Once you’re done, click the ‘Add To Cart’ button
          After you have added all the products, click on the cart icon on the top right. You can either choose to continue shopping or confirm the order and click ‘Checkout’.
          From there, you can either login to your existing The Souled Store account or simply continue as a 'New User' and create one.
          Once you’re done, proceed to checkout, confirm your shipping address, and select the desired payment method to confirm your order by clicking ‘Place Order’.
        `
  },
  {
    name: 'How will I know that my order is placed successfully?',
    text: `Once you successfully place your order, you will receive a confirmation email with details of your order and your order ID.
           You’ll receive another email once your order is shipped out. All you have to do then is, sit back, relax, and wait for your awesome product(s) to arrive!
          `
  },
  {
    name: 'How do I receive my Order?',
    text: `We have tied up with several reputed courier companies, so your orders will be delivered right to your doorstep within 2-7 business days depending on where you live.
           All orders come in fully sealed packages to make sure that all your goods reach you in perfect condition.
          `
  },
  {
    name:
      'I tried placing my order using my Debit Card/ Credit Card/ Net Banking. The order was not successful but my money got deducted. What’s happening here?',
    text: `As a first step, kindly check your bank account to ensure if your account has been debited. If your account has been debited after a payment failure, it is normally rolled back by banks within 10 business days.
           For any other assistance/issues you can write to us at "mailto:connect@thesouledstore.com"connect@thesouledstore.com
           orcall us on our helpline, and we’ll help sort things out.
          `
  },
  {
    name: 'How should I check the status of my Order?',
    text: `To find out when your order is arriving, you need to first log in to your account. Click on the icon to the left of the cart (located on the top right corner) and enter your details.
           Click on Orders to see the status of your current order (as well as your order history). You can also simply click on ‘Track Order’ on the top right, type in your order ID, and check your order status.
           After your order has been successfully placed, you will immediately receive a confirmation and order details via email and SMS. Once your products have been shipped, you will be notified again via email and SMS.
           In case there is any unusual event or complication that leads to a delay in shipping your order, you will immediately receive an update from our end- with reasons and the revised shipping and delivery timelines.
           If there are any other issues/ delays that come up, or you need the order to be delivered urgently, write to us at "mailto:connect@thesouledstore.com" connect@thesouledstore.com, we will see what we can do to help.
          `
  },
  {
    name:
      'Is it safe to shop online if I make payment using Net Banking, Debit Card, or Credit Card?',
    text: `All Credit Card, Debit Card, and Net Banking transactions are processed over a secure encrypted connection. Rest assured, your money is safe.`
  },
  {
    name: 'Why am I not getting any COD option on the payment page?',
    text: `If the COD option is not showing, it’s because this facility is unavailable for your postal code. You can either pay by Debit Card, Credit Card, or Net Banking, or you can get the products delivered to an alternate address (where COD is available).`
  },
  {
    name: 'Are there any hidden charges?',
    text: `There are absolutely NO hidden charges for any of our products- what you see is what you pay.`
  },
  {
    name: 'What should I do if my payment fails?',
    text: `In case there is a failure in payment, please retry and keep the following things in mind:
             Please confirm if the information you’ve provided is correct i.e. account details, billing address, and password (for Net Banking); and that your internet connection wasn’t disrupted during the process.
             If your account has been debited even after a payment failure, it is normally rolled back to your bank account within 10 business days. For any further clarification, you can email us at "mailto:connect@thesouledstore.com" connect@thesouledstore.com.`
  },
  {
    name: 'Is there any additional charge for COD orders?',
    text: `Yes, we charge a flat ₹ 25 per COD order.`
  },
  {
    name: 'How do I use my TSS Money?',
    text: `You can check how much TSS Money you have in your account once you login. Select My Account and click on ‘TSS Money’ from the list. You will be able to see Available Balance, Total Purchases and Usage History.
             To use available balance, once you have added your products to cart and clicked on the cart icon to go to the checkout page, you will see your order details.
             Below that will be an option to apply codes for discounts. Tick the 'Use TSS Money' box. Once you’re done, proceed to checkout, confirm your shipping address, and select the desired payment method to confirm your order by clicking ‘Place Order’.
             There is no minimum or maximum usage limit on TSS Money.
             TSS Money Can be clubbed with gift vouchers and discount codes.
             TSS Money is applicable on products on offer/sale.
             TSS Money is subject to expire 12 months after the date of credit. Once expired, TSS Money will lapse automatically and cannot be credited back.
            `
  },
  {
    name: 'How do I use my TSS Points?',
    text: `You can check how many TSS Points you have in your account once you login. Select My Account and click on ‘TSS Points’ from the list. You will be able to see Current Active Points, Total Purchases, Usage History and Expired Points.
             To use TSS Money, once you have added your products to cart and clicked on the cart icon to go to the checkout page, you will see your order details.
             Below that will be an option to apply codes for discounts. Tick the 'Use TSS Points' box. Once you’re done, proceed to checkout, confirm your shipping address, and select the desired payment method to confirm your order by clicking ‘Place Order’.
             Maximum 20% of cart value can be paid using TSS Points.
             TSS Points Cannot be clubbed with a discount code/ offer..
             TSS Points are not applicable on products on offer/sale.
             TSS Points are subject to expiry. To check the expiry date, visit your account details. Once expired, the points will lapse automatically and cannot be credited back.
             `
  },
  {
    name: 'How long will it take for my order to be delivered?',
    text: `Orders in India, once shipped, are typically delivered in 1-4 business days in metros, and 4-7 business days for the rest of India. Delivery time may vary depending upon the shipping address and other factors (public holidays, extreme weather conditions, etc.).
              Please Note</u>: Due to the ongoing pandemic, our courier partners are working with limited staff. Delivery of your orders may be delayed by up to 15 days.
             `
  },
  {
    name: 'When will my products on pre-order be shipped?',
    text: `We ship pre-order products on the date given in the product description, as far as possible. However, there may be a slight delay in shipping in case of an unforeseen surge in demand or any similar issue. Rest assured, our customer experience team will keep you updated on the status of your order.`
  },
  {
    name: 'Are there any additional shipping charges?',
    text: `The Souled Store provides FREE shipping for all orders above ₹ 445 in India. A shipping charge of ₹ 50 is payable only on orders below ₹ 445.`
  },
  {
    name: 'How do I track my order?',
    text: `You can track your order once it has been dispatched from our warehouse. An email and SMS will be sent with a link. You can also track it from your account on the website by Selecting ‘Orders’ from the top right corner and then clicking on 'Track Order' for the respective Order ID.`
  },
  {
    name: 'What if my order is undelivered?',
    text: `For prepaid orders, if our courier partners are unable to deliver the product and they send it back to us, we will initiate a refund as TSS Money to your The Souled Store account which will reflect within 24-48 hours of initiation.`
  },
  {
    name: 'What are the terms of the Return Policy?',
    text: `Customers can return their order within 30 days after an order has been delivered.
              In the interests of hygiene, we may refuse returns where it's obvious that the item has been worn, washed or soiled.
              Defective products need not be sent back to us, unless confirmed by the Customer Experience Team. If you have received a defective product, send us images at connect@thesouledstore.com and we will get back to you. Once confirmed by the Customer Experience Team the refund will be provided either into your bank account or as TSS Money as per your convenience.
              If you have to return anything from a combo pack, the whole pack will have to be returned. There will not be any partial returns accepted for this. If there is a manufacturing issue, or if you have any other query regarding this, you can contact us on the number or email us on connect@thesouledstore.com.
              Gift cards/vouchers are non-refundable. 
              Gift wrapping charges will not be refunded if goods are returned. Also, we will not be able to gift wrap any replacements you have asked for. 
              To maintain strict hygiene standards of our products, we do not accept returns on several product categories, including but not limited to masks, boxers, shorts, sweat-activated t-shirts and socks. The Souled Store may, at its discretion and without prior notice, change the products or categories to which this policy would apply.`
  },
  {
    name: 'How does the Return process work?',
    text: `You can only apply for a Return from your The Souled Store account. Login to your account and go the ‘My Orders’ section. Click on ‘View/Edit Order Details’ for the respective order.
             Self-Ship: Since we do not have a reverse pick up facility, we request you to self-ship the product to us. We will credit 100 TSS Money in your account in lieu of the shipping costs.
             `
  },
  {
    name:
      'What is the refund policy for returns of orders placed during a sale?',
    text: `If an order placed during a sale is returned to us, only the amount paid by you will be refunded, not the current product price.`
  },
  {
    name: 'How do I self-ship the products?',
    text: `Please pack the items securely to prevent any loss or damage during transit. All items must be in unused condition with all original tags attached and packaging intact.
              You can courier the product(s) to the address mentioned below:
                 The Souled Store 
                 F6 - 202, Bhumi World-Industrial Park, Pimplas Village, Mumbai-Nashik Highway, 
                 Before Kalyan-Bhiwandi Naka, Opp. Tata Amantra, Pimplas, 
                 Thane, Maharashtra - 421302. 
              On receiving the product at the warehouse, TSS Money will be credited to your account along with 100 Points for Courier Charges.`
  },
  {
    name: 'How do I cancel my order?',
    text:
      'Orders that have not been shipped can be cancelled by logging into your The Souled Store account, clicking ‘Orders’ and then ‘Cancel Order’.If you want to edit your order we will not be able to change anything once shipped. For changes in the order before it has been shipped, please call us directly on the number and we will see if we can work it out for you.'
  },
  {
    name: 'What are the terms and conditions for refund?',
    text: ` Returns - The product amount and 100 for courier will be added as TSS Money to your The Souled Store account.
             Cancellations - If the order is cancelled before shipped, the refund will be done to your bank account and will reflect within 7-10 business days. If a cancellation is required after the product is shipped, we will provide a bank refund upon request, after the package reaches back to us.
             Defective/ Damaged in transit - Once confirmed by the Customer Experience Team the refund will be provided either into your bank account or as TSS Money as per your convenience.
             Wrong/ Missing products - We can either ship out the product(s) (if available in stock at the time) or a refund into the bank account or as TSS Money as per your convenience.
           `
  },
  {
    name: 'What are the rules for refunding courier charges?',
    text: `As we do not have a reverse pickup facility yet, we will provide you with TSS Money worth ₹ 100 for the shipping charges borne by you.
             Please make sure your courier costs do not exceed the amount stipulated above. We recommend using ‘Speed Post’ as your courier service. Speed Post is a Government of India owned entity and has the most widely distributed postal network in India. Please try and avoid Professional Couriers as much as possible since we have been facing issues with them.
            `
  },
  {
    name: "I haven't received my refund yet. What should I do?",
    text: `We update our customers via email once we initiate the refund procedure.
            Bank refunds will take 7-10 business days and a refund as TSS Money will take 24-48 hours.
           `
  },
  {
    name: 'Do you take bulk orders/ customise products? ',
    text: `Yes, we absolutely do. You can email us with your order and design details at"mailto:corporate@thesouledstore.com" ccorporate@thesouledstore.com We’ll also try and work out a discount for you, depending on the quantity of your order.You can check out our "/bulk-and-custom-orders" Bulk/ Custom Orders page for more details.
           `
  },
  {
    name:
      'Will I automatically receive marketing emails from you after registration?',
    text: ` You will automatically get subscribed to our marketing emails and SMS's after registering with us. In case you do not want to receive these, you can click on the unsubscribe link in the email.`
  },
  {
    name: 'What to do if I forgot my password?',
    text: `You can click on the 'Forgot Password' option when logging in, and the password reset link will be sent to you via email.`
  },
  {
    name:
      'I want to place an order but I don’t want any price tag or invoice attached as it is a gift for someone. Is it possible?',
    text: ` We have to leave the tags intact in case the person you’re gifting faces any issues and would like to return the product.
             It is not possible to detach the invoices and tags but if you call us immediately after placing the order, our team can help you out. 
             If you want to add a note to the gift, please email the note to us at "mailto:connect@thesouledstore.com" connect@thesouledstore.com
             and immediately call us on our number so that we can add it before the order is shipped. Please note that the character limit for the note is 250 characters.
            `
  },
  {
    name: 'Is there any option to try the product before buying it?',
    text: `We only sell online so there is no try-and-buy option available. However, in order to make sure you in pick the right size, we have a size chart with measurements on our product pages. For any queries, please write to us at `
  },
  {
    name: 'I wish to add few more products in my order. Will it be possible?',
    text: `Once you have confirmed the order and we have accepted it, you cannot add any more products to your order. You will have to place a fresh order for the other products.`
  },
  {
    name:
      'The product I want to return was bought on discount. Will I get refunded the full amount?',
    text: `No. You will only receive the exact amount paid for the product.`
  },
  {
    name:
      'In case I return the products, will the COD/Shipping/Gifting charges be credited back?',
    text: ` No. These are one time charges and are non-refundable.`
  },
  {
    name: 'I have created a Return request. When will I get the refund?',
    text: `You will receive the refund in the form of Points, once the package reaches the warehouse. To request for bank refund, you may Contact Us.`
  },
  {
    name: "What if I'm not available when the pickup is being attempted?",
    text: ` Our courier partner will attempt the pick up 3 times. You can let him know a convenient time to pick the product up.`
  },
  {
    name: 'What is the validity of TSS Money in my The Souled Store account?',
    text: ` TSS Money credited as a refund for non-delivery or return of product/s will be valid for a period of 365 days from the date of the addition of points.
             TSS Money given for marketing promotions are valid for a shorter period of time and will expire as per the T&Cs of the offer.
           `
  },
  {
    name:
      'What are the standard terms and conditions applicable to contests run by The Souled Store?',
    text: `You can find the standard terms and conditions for our contests "/contest-terms-and-conditions"here.
            `
  }
]
