export const tssPointsTC = {
  'TSS POINTS TERMS AND CONDITIONS': 'TSS Points are given to The Souled Store users as part of marketing campaigns and other promotions and can be redeemed only on The Souled Store website or mobile app (collectively “Platform”). Please read these terms and conditions carefully before participating. You understand that by using TSS Points and using our Platform, you agree to be bound by these terms and conditions, including Terms of Use and Privacy Policy of the Platform. Please understand that if you refuse to accept these terms and conditions, you will not be able to access the offers provided under our Platform.',
  terms_conditions_items: [
    'TSS Points are issued with an expiry date and can be redeemed only before expiry.',
    'TSS Points cannot be used with discount coupon on an order.',
    'The total TSS Points that can be used in one transaction is subject to the cart value. A max of 20% of the cart value can be redeemed via TSS Points for any transaction.',
    'If The Souled Store has suspicion or knowledge that any Customer is or has been involved in any fraudulent or illegal activity directly or indirectly, The Souled Store reserves the right to disqualify/remove all TSS Points/cancel order of such Customer and any related Customers.',
    'The Souled Store shall not be responsible if a purchase is not registered or is lost due to any network issues, breakdown of machinery, disruption in the network or non-receipt of payment from banks/payment gateways and/or the cost(s) charged by the network operator(s). Any dispute in connection to the same shall be settled between the end customer and the network operator, and The Souled Store shall not be liable for the same.',
    'The Souled Store reserves the right to amend, modify, cancel, update or suspend TSS Points at any time without notice. Upon such premature amendment, modification, cancellation, updation, or suspension of TSS Points by The Souled Store, no person shall be entitled to claim loss of any kind whatsoever against The Souled Store or its affiliates.',
    'TSS Points are open only for end consumers and not resellers.',
    'TSS Points cannot be settled in cash and are not transferable.',
    'Users are not bound in any way to participate in this offer. Any participation is entirely voluntary, and the TSS Points allocated are being made available purely on a best effort basis.',
    'You hereby agree to indemnify and keep indemnified The Souled Store against all damages, liabilities, costs, expenses, claims, suits and proceedings (including reasonable attorney’s fee) that may be suffered by The Souled Store because of (i) violation of terms of these terms and conditions by you; (ii) violation of applicable laws; (iii) wilful negligence or misconduct on your part in dealing with the Platform.'
  ],
  faq: [
    {
      question: 'Can I buy items on other e-commerce websites with TSS Points?',
      answer: 'TSS Points can only be used to purchase products at The Souled Store website or app. They cannot be used on any other websites or apps.'
    },
    {
      question: 'Can I transfer my TSS Points to another TSS account?',
      answer: 'TSS Points are non-transferable. Thus, they cannot be transferred to another account and cannot be used to pay for orders made by other TSS accounts.'
    },
    {
      question: 'Can I get my expired TSS Points back in my account?',
      answer: 'TSS Points once expired cannot be credited back to your account. It is recommended to use them within the expiry period.'
    },
    {
      question: 'Can I transfer TSS Points to my bank account or redeem to cash?',
      answer: 'TSS Points cannot be transferred to any bank account or redeemed as cash. They can only be used on The Souled Store website and app.'
    },
    {
      question: 'How many TSS Points can I redeem in each order?',
      answer: 'For each order, you can avail a maximum of 20% discount on the total cart value via TSS Points.'
    },
    {
      question: 'Are TSS Points applicable on all products?',
      answer: 'Yes! TSS Points are applicable on all products available at The Souled Store.'
    },
    {
      question: 'Do TSS Points have an expiry date?',
      answer: 'Yes, TSS Points are subject to expiry. To check the expiry date, visit your account details on our website or app. Once expired, the points will lapse automatically and cannot be credited back.'
    },
    {
      question: 'How do I check my TSS Points?',
      answer: 'To check your TSS Points balance, simply login to your The Souled Store account and visit your account details on our website or app.'
    },
    {
      question: 'How do I redeem TSS Points?',
      answer: 'During checkout, simply select the TSS Points checkbox to redeem your TSS Points.'
    }
  ]
}

export const tssMoneyTC = {
  'TSS MONEY TERMS AND CONDITIONS': 'TSS Money is given to The Souled Store users as part of refund/courier reimbursements, promotions, etc. and can be redeemed only on The Souled Store website or mobile app (collectively “Platform”). Please read these terms and conditions carefully before participating. You understand that by using TSS Money and using our Platform, you agree to be bound by these terms and conditions, including Terms of Use and Privacy Policy of the Platform. Please understand that if you refuse to accept these terms and conditions, you will not be able to access the offers provided under our Platform.',
  terms_conditions_items: [
    'TSS Money is 100% redeemable.',
    'TSS Money once redeemed cannot be redeemed again.',
    'TSS Money cannot be transferred to the Customer’s bank account.',
    'TSS Money is subject to expire after 12 months.',
    'If The Souled Store has suspicion or knowledge that any Customer is or has been involved in any fraudulent or illegal activity directly or indirectly, The Souled Store reserves the right to disqualify/remove all TSS Money/cancel order of such Customer and any related Customers.',
    'The Souled Store shall not be responsible if a purchase is not registered or is lost due to any network issues, breakdown of machinery, disruption in the network or non-receipt of payment from banks/payment gateways and/or the cost(s) charged by the network operator(s). Any dispute in connection to the same shall be settled between the end customer and the network operator, and The Souled Store shall not be liable for the same.',
    'The Souled Store reserves the right to amend, modify, cancel, update or suspend TSS Money at any time without notice. Upon such premature amendment, modification, cancellation, updation, or suspension of TSS Money by The Souled Store, no person shall be entitled to claim loss of any kind whatsoever against The Souled Store or its affiliates.',
    'TSS Money is open only for end consumers and not resellers.',
    'TSS Money cannot be settled in cash and is not transferable.',
    'Users are not bound in any way to participate in this offer. Any participation is entirely voluntary, and the TSS Money allocated is being made available purely on a best effort basis.',
    'You hereby agree to indemnify and keep indemnified The Souled Store against all damages, liabilities, costs, expenses, claims, suits and proceedings (including reasonable attorney’s fee) that may be suffered by The Souled Store because of (i) violation of terms of these terms and conditions by you; (ii) violation of applicable laws; (iii) wilful negligence or misconduct on your part in dealing with the Platform.'
  ],
  faq: [
    {
      question: 'Can I buy items on other e-commerce websites with TSS Money?',
      answer: 'TSS Money can only be used to purchase products at The Souled Store website or app. It cannot be used on any other websites or apps.'
    },
    {
      question: 'Can I transfer my TSS Money to another TSS account?',
      answer: 'TSS Money is non-transferable. Thus, they cannot be transferred to another account and cannot be used to pay for orders made by other TSS accounts.'
    },
    {
      question: 'Can I get my expired TSS Money back in my account?',
      answer: 'TSS Money once expired cannot be credited back to your account. It is recommended to use them within the expiry period.'
    },
    {
      question: 'Can I transfer TSS Money to my bank account or redeem to cash?',
      answer: 'TSS Money cannot be transferred to any bank account or redeemed as cash. They can only be used on The Souled Store website and app.'
    },
    {
      question: 'How much TSS Money can I use in each order?',
      answer: 'There is no minimum or maximum usage limit on TSS Money.'
    },
    {
      question: 'Is TSS Money applicable on all products?',
      answer: 'Yes! TSS Money is applicable on all products available at The Souled Store.'
    },
    {
      question: 'Does TSS Money have an expiry date?',
      answer: 'Yes, TSS Money is subject to expire 12 months after the date of credit. Once expired, TSS Money will lapse automatically and cannot be credited back.'
    },
    {
      question: 'How do I check my TSS Money balance?',
      answer: 'To check your TSS Money balance, simply login to your The Souled Store account and visit your account details on our website or app. You can see available balance, total purchases and usage history as well.'
    },
    {
      question: 'How do I redeem TSS Money?',
      answer: 'During checkout, simply select the TSS Money checkbox to use your TSS Money.'
    }
  ]
}
