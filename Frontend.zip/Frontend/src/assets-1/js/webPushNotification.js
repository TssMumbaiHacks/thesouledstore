export default {
  async requestNotificationPermission () {
    const permission = await window.Notification.requestPermission()
    // value of permission can be 'granted', 'default', 'denied'
    // granted: user has accepted the request
    // default: user has dismissed the notification permission popup by clicking on x
    // denied: user has denied the request.
    return permission
  },
  async updateSubscription () {
    let sw = await navigator.serviceWorker.ready
    await sw.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: process.env.WEBPUSH_FIREBASE_PUBLIC_VAPID
    }).then((sub) => {
      // console.log('User subscription Generated : ', JSON.stringify(sub))
      window.clevertap.notifications.push(sub)
      // console.log('webpush_ct updated')
    }).catch((err) => console.log(err))
  },
  async checkAvailableSubscription () {
    let sw = await navigator.serviceWorker.ready
    let subscription = await sw.pushManager.getSubscription()
    // console.log('Subscription: ', subscription)
    if (!subscription) {
      await this.updateSubscription()
    }
  },
  async chromeWebpush () {
    // check device notification permission
    const prmResult = await this.requestNotificationPermission()
    // if permission is granted or default update subscription to server
    // console.log('Permission: ', prmResult)
    if (prmResult === 'default') {
      await this.updateSubscription()
    } else if (prmResult === 'granted') {
      await this.checkAvailableSubscription()
    }
  },
  webpushSubscription () {
    if ('safari' in window && 'pushNotification' in window.safari) {
      // safari
    } else {
      return this.chromeWebpush()
    }
  }
}
