/* eslint-disable */
export const trackOrderStatus = {
  orderPlaced: [
	  {
			id: 1,
			status_code: 1,
			status: 'Order Placed'
		},
		{
			id: 2,
			status_code: 1001,
			status: 'Shipped'
		},
		{
			id: 3,
			status_code: 5,
			status: 'In-Transit'
		},
		{
			id: 4,
			status_code: 6,
			status: 'Out For Delivery'
		},
		{
			id: 5,
			status_code: 8,
			status: 'Delivered'
		}
	],
	orderCancelled: [
		{
			id: 1,
			status_code: 1,
			status: 'Order Placed'
		},
		{
			id: 2,
			status_code: 2,
			status: 'Cancelled'
		},
		{
			id: 3,
			status_code: 3,
			status: 'Refund Initiated'
		},
		{
			id: 4,
			status_code: 4,
			status: 'Refund Completed'
		}
	],
	exchangeOrderCancelled: [
		{
			id: 1,
			status_code: 1,
			status: 'Exchange Order Placed'
		},
		{
			id: 2,
			status_code: 2,
			status: 'Exchange Cancelled'
		},
		{
			id: 3,
			status_code: 3,
			status: 'Refund Initiated'
		},
		{
			id: 4,
			status_code: 4,
			status: 'Refund Completed'
		}
	],
	orderCancelledCod: [
		{
			id: 1,
			status_code: 1,
			status: 'Order Placed'
		},
		{
			id: 2,
			status_code: 2,
			status: 'Cancelled'
		}
	],
	orderDelivered: [
		{
			id: 1,
			status_code: 1,
			status: 'Order Placed'
		},
		{
			id: 2,
			status_code: 1001,
			status: 'Shipped'
		},
		{
			id: 5,
			status_code: 8,
			status: 'Delivered'
		}
	],
	orderExchanged: [
		{
			id: 2,
			status_code: 1001,
			status: 'Exchange Shipped'
		},
		{
			id: 3,
			status_code: 5,
			status: 'Exchange In-Transit'
		},
		{
			id: 4,
			status_code: 6,
			status: 'Exchange Out For Delivery'
		},
		{
			id: 5,
			status_code: 8,
			status: 'Exchange Delivered'
		}
	],
	storeOrderPlaced: [
		{
			id: 1,
			status_code: 1,
			status: 'Order Placed'
		},
		{
			id: 5,
			status_code: 8,
			status: 'Delivered'
		}
	],
	missingDamagedOrder: [
		{
			id: 1,
			status_code: 1,
			status: 'Order Placed'
		},
		{
			id: 2,
			status_code: 1001,
			status: 'Shipped'
		},
		{
			id: 3,
			status_code: 5,
			status: 'In-Transit'
		},
		{
			id: 4,
			status_code: 6,
			status: 'Out For Delivery'
		},
		{
			id: 5,
			status_code: 8,
			status: 'Delivered'
		},
		{
			id: 6,
			status_code: 9,
			status: 'Refund Initiated'
		},
		{
			id: 7,
			status_code: 10,
			status: 'Refund Completed'
		}
	],
	rtoProduct: [
		{
			id: 1,
			status_code: 1,
			status: 'Order Placed'
		},
		{
			id: 2,
			status_code: 2,
			status: 'Return To Warehouse'
		},
		{
			id: 3,
			status_code: 3,
			status: 'Refund Initiated'
		},
		{
			id: 4,
			status_code: 4,
			status: 'Refund Completed'
		}
	],
	rtoProductCod: [
		{
			id: 1,
			status_code: 1,
			status: 'Order Placed'
		},
		{
			id: 2,
			status_code: 2,
			status: 'Return To Warehouse'
		}
	],
}