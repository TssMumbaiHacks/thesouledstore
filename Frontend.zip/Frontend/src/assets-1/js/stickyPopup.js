export const TIMER = {
  'OFFER_APPEAR_TIMER': 45, // time in seconds
  'OFFER_COUNTDOWN_TIMER': 300, // time in seconds
  'MINIMUM_CART_VALUE': 49, // value in ₹
  'COUPON_CODES': ['CART10'], // possible discount codes
  'RESTRICTED_PAGES': ['/delivery-address', '/checkout']
}
