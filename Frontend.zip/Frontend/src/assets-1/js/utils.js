export function getPhonelength (countryId, countries) {
  const filterCountry = countries.find(obj => parseInt(obj.id) === parseInt(countryId))
  const countryPhoneLength = filterCountry.phone_no_length
  return countryPhoneLength || 10
}
