<template>
  <div v-if="showHeader" :class="{'supima-menu': callerComp === 'supimaMenu' || callerComp === 'winterMenu' || callerComp === 'winterWearMenu', 'activewear-menu': callerComp === 'activeWearMenu', 'birthday-logo': isBirthdayMonth && !isExclusive}">
    <div id="notifylogin" class="notifylogin">&nbsp;</div>
    <div class="loadingOverlay" v-if="userAcc.loader">
      <div class="loading"></div>
    </div>
    <div v-if="!['supimaMenu', 'activeWearMenu', 'winterWearMenu'].includes(callerComp) && isSelectedCountryIndia && !isCodCheckoutLogin" class="topbar img-auto">
      <div class="container py-1">
        <div class="row" v-if="bannerPlaceHolderForAppDownldPopup && !isBflUtm">
          <div
            class="col-12 text-white d-flex justify-content-end align-items-center justify-content-center"
            :class="(this.getSystemBrowser() === 'safari') ? 'py-1' :'py-2'"
          >
            <div class="col">
              {{bannerPlaceHolderForAppDownldPopup && bannerPlaceHolderForAppDownldPopup.tag_text}}
            </div>
            <div>
              <span
                @click="appOpenHandler"
                class="pointer text-uppercase p-1"
                style="border: 2px solid #fff; border-radius: 6px;"
              >
                &ensp;
                <i
                  class="fa fa-mobile mr-1"
                  style="font-size: 15px;"
                  aria-hidden="true"
                ></i>
                Open App&ensp;
              </span>
              <div class="d-flex" v-if="starRating && starRating.description">
                <div class="rating-label">{{ starRating.description }}</div>
                <div class="star-section mt-1">
                  <div class="star-blank"><img src="./assets/images/fill-star.svg" /></div> 
                  <div class="star-fill" :style="{ width: `calc(${getRatingToShow(starRating.description)}%)` }"><img src="./assets/images/fill-star.svg" /></div>
                </div>
              </div>
              </div>
          </div>
          <!--
          <div class="col-6 text-left">
            <router-link to="/orders" class="pointer text-uppercase"
              >Track Order
            </router-link>
          </div>
          <div class="col-6 text-right">
            <a
              @click="redirectToAppStore"
              class="pointer text-uppercase d-flex justify-content-end align-items-center"
            >
              <i
                class="fa fa-mobile mr-1"
                style="font-size: 18px"
                aria-hidden="true"
              ></i>
              Download App
            </a>
          </div>
          -->
        </div>
        <div v-else class="pt-3 pb-2"></div>
      </div>
    </div>
    <nav class="navbar navbar-toggleable-md navbar-light" :class="{ 'global-nav': !isSelectedCountryIndia, 'bg-inverse': isPosLogin, 'bg-faded': !isPosLogin }">
      <button
        v-if="$route.name === 'home' || ['supimaMenu', 'activeWearMenu', 'winterWearMenu'].includes(callerComp)"
        class="navbar-toggler navbar-toggler-left mobilenav"
        aria-label="navigation menu"
        type="button"
      >
        <span  v-if="$route.name === 'home'" class="navbar-toggler-icon"></span>
        <span v-else class='menu-hamburger'>
          <img src='./assets/images/hamburger-white.png'/>
        </span>
      </button>
      <div
        class="navbar-toggler-left toggle-menu left-arrow-style"
        v-else-if="!isCodCheckoutLogin"
        @click="goToPreviousPage"
      >
        <img :src="imgBaseUrl + 'appIcons/leftArrow@2x.png'" alt="Arrow" style="filter: brightness(0) saturate(100%);"/>
      </div>
      <div v-if="(this.$route.name === 'listing' || this.$route.name === 'search' || this.$route.name === 'mywishlist')" class="pl-4"
        :class="[this.$route.name === 'mywishlist' ? 'pr-1' : 'pr-5', productListingStyle.fontPosition ? `text-${productListingStyle.fontPosition}` : '']"
      >
        <span
          class="pl-3 pr-5 txtTruncate font-weight-bold text-capitalize"
          style="color:#191919;"
          :class="productListingHeader.subHeader ? '' : 'pt-1'"
        >
          {{productListingHeader.header}}
        </span>
        <span 
          v-if="productListingHeader.subHeader"
          class="pl-2 pr-5 txtTruncate text-capitalize"
          style="line-height:1;font-size: 12px;"
        >{{productListingHeader.subHeader}}</span>
      </div>
      <div class="headerRight" :class="$route.name === 'thankyou' || isCodCheckoutLogin ? 'invisible' : ''">
        <div>
          <span v-if="isExclusive" class="hicon" @click="openSearch()">
            <img src="./assets/images/mship-search.svg" alt="search" width="22" height="22" />
          </span>
          <span v-else class="hicon" @click="openSearch()">
            <img v-if="['supimaMenu', 'activeWearMenu', 'winterWearMenu'].includes(callerComp)" style="width: 27px !important;" src='./assets/images/search-white.png' alt="search" />
            <img v-else :src="imgBaseUrl + 'appIcons/ic_search@2x.png'" alt="search" />
          </span>
          <!-- <router-link :to="'/cart'" class="headercart hicon fa fa-shopping-cart">
            <div class="count" v-if="cartcount>0">{{cartcount}}</div>
          </router-link> -->
         <router-link
           :to="'/mywishlist'"
           class="hicon"
           v-if="!disableWishlist && $route.name !== 'mywishlist'"
           @click.native="myWishlistVisitEventHandler('default')"
          >
            <span v-if="isExclusive">
              <img src="./assets/images/mship-wishlist.svg" alt="search" width="22" height="22" />
            </span>
            <span v-else>
              <span
                v-if="['supimaMenu', 'activeWearMenu', 'winterWearMenu'].includes(callerComp)"
                class="headercart hicon fa heart"
                :class="this.$router.currentRoute.path === '/mywishlist' ? 'fa-heart-o active' : 'fa-heart-o'"
              >
              </span>
              <span v-else class="headercart hicon">
                <img :src="imgBaseUrl + 'appIcons/ic_wishlist@2x.png'" alt="wishlist" />
              </span>
            </span>
            <div class="count" v-if="wishlistCount > 0">{{ wishlistCount }}</div>
          </router-link>
          <router-link :to="'/cart'" class="hicon">
            <span @click="cartEventHandler">
              <span v-if="isExclusive">
                <img src="./assets/images/mship-cart.svg" alt="cart" width="22" height="22" class="headercart" />
              </span>
              <span v-else>
                <svg xmlns="http://www.w3.org/2000/svg"
                  class="mt-1 headercart"
                  width="25"
                  height="23"
                  viewBox="0 0 48 48"
                  v-if="['supimaMenu', 'activeWearMenu', 'winterWearMenu'].includes(callerComp)"
                  style="stroke: #fff;fill: #fff;stroke-width:1.4;-webkit-font-smoothing: antialiased;"
                >
                  <path xmlns="http://www.w3.org/2000/svg"
                    d="M43,46H5c-2.209,0-4-1.791-4-4l4-24c0.678-3.442,2.668-4,4.877-4h2.652  C14.037,7.052,18.602,2,24,2s9.963,5.052,11.471,12h2.652c2.209,0,4.199,0.558,4.877,4l4,24C47,44.209,45.209,46,43,46z M24,4  c-4.352,0-8.045,4.178-9.418,10h18.837C32.045,8.178,28.353,4,24,4z M41,18c-0.308-1.351-0.957-2-2.37-2h-2.828  C35.925,16.976,36,17.975,36,19c0,0.552-0.447,1-1,1s-1-0.448-1-1c0-1.027-0.069-2.031-0.201-3H14.201C14.07,16.969,14,17.973,14,19  c0,0.552-0.447,1-1,1s-1-0.448-1-1c0-1.025,0.075-2.024,0.197-3H9.369C7.957,16,7.309,16.649,7,18L3,42c0,1.104,0.896,2,2,2h38  c1.104,0,2-0.896,2-2L41,18z"
                    shape-rendering="auto"
                  />
                  <line x1="5" y1="32" x2="44" y2="32" style="stroke-width:3;"/>
                </svg>
                <img v-else :src="imgBaseUrl + 'appIcons/ic_newCart@2x.png'" alt="cart" />
              </span>
              <!--
              <svg xmlns="http://www.w3.org/2000/svg"
                class="mt-1 headercart"
                width="25"
                height="23"
                viewBox="0 0 48 48"
                :style="['supimaMenu', 'activeWearMenu'].includes(callerComp) ? 'stroke: #fff;fill: #fff;stroke-width:1.4;-webkit-font-smoothing: antialiased;' : 'stroke: rgb(114 107 107);fill: rgb(34 32 32);stroke-width:1.4;-webkit-font-smoothing: antialiased;'"
              >
                <path xmlns="http://www.w3.org/2000/svg"
                  d="M43,46H5c-2.209,0-4-1.791-4-4l4-24c0.678-3.442,2.668-4,4.877-4h2.652  C14.037,7.052,18.602,2,24,2s9.963,5.052,11.471,12h2.652c2.209,0,4.199,0.558,4.877,4l4,24C47,44.209,45.209,46,43,46z M24,4  c-4.352,0-8.045,4.178-9.418,10h18.837C32.045,8.178,28.353,4,24,4z M41,18c-0.308-1.351-0.957-2-2.37-2h-2.828  C35.925,16.976,36,17.975,36,19c0,0.552-0.447,1-1,1s-1-0.448-1-1c0-1.027-0.069-2.031-0.201-3H14.201C14.07,16.969,14,17.973,14,19  c0,0.552-0.447,1-1,1s-1-0.448-1-1c0-1.025,0.075-2.024,0.197-3H9.369C7.957,16,7.309,16.649,7,18L3,42c0,1.104,0.896,2,2,2h38  c1.104,0,2-0.896,2-2L41,18z"
                  shape-rendering="auto"
                />
                <line x1="5" y1="32" x2="44" y2="32" style="stroke-width:3;"/>
              </svg>
              -->
              <!-- <span class="headercart hicon fa fa-shopping-cart"></span> -->
              <!-- <img data-src="https://tss-static-images.gumlet.io/icons/cart-icon.png" /> -->
              <div class="count" v-if="cartcount > 0">{{ cartcount }}</div>
            </span>
          </router-link>
        </div>
      </div>
      <div
        v-if="this.$route.name !== 'listing' && this.$route.name !== 'search' && this.$route.name !== 'mywishlist'"
        :class="['supimaMenu', 'activeWearMenu'].includes(callerComp) ? 'pabsolute supima-home-logo' : 'navbar-brand'"
        @click="homeEventHandler(webcategory && isComboActive ?'/'+ webcategory:'/')"
      >
        <img v-if="['supimaMenu', 'activeWearMenu'].includes(callerComp)" :src="callerComp === 'supimaMenu' ? imgBaseUrl + 'supima-home-logo.png' : imgBaseUrl + 'active-wear-logo-mob.png'"/>
        &nbsp;
      </div>
      <div>
        <div
          class="collapse navbar-collapse stylescrollbar navMenu"
          id="navbarNavDropdown"
          :class="!['supimaMenu', 'activeWearMenu', 'winterWearMenu'].includes(callerComp) ? 'navbar-mt' : ''"
        >
          <div class="navheader showmobile">
            <!-- <button class="back_mobile mobilenav" type="button">
              <span class="fa fa-angle-left"></span>
            </button> -->
            <div class="pl-2 d-flex align-items-center header-background" :class="{'exclusive-header': exclusiveUser}">
              <div class="">
                <router-link :to="webcategory && isComboActive ? '/'+ webcategory:'/'" class="toggle-menu"
                  >&nbsp;
                  <img
                    :data-src="exclusiveUser ? imgBaseUrl + 'exclusive/exclusive-white-logo.png' :  '/static/img/newlogosticky.f7f01f0.png'"
                    class="sidebar-home-img"
                    alt="The Souled Store Logo"
                  />
                </router-link>
              </div>
              <div
                class="pl-3 user-info toggle-menu"
              >
              
              <div :class="authStatus ? 'location-change-style' : 'guest-location-style'" >
                <LocationChange></LocationChange>
              </div>
                <div v-if="authStatus" class="user-info-slidemob" @click="redirectToMyAcc">
                  <div class='d-flex align-items-center name-arrow-wrapper'>
                    <span class="f16 text-capitalize">{{ user && user.firstname }} {{user && user.lastname }}</span>
                    <span style="color: white;" class='arrow'></span>
                  </div>
                  <div v-if="exclusiveUser" class="exclusive-info fbold">
                    <p>Member</p>
                    <hr v-if="exclusiveDetails && exclusiveDetails.exclusive_savings"/>
                    <p v-if="exclusiveDetails && exclusiveDetails.exclusive_savings">
                      <span class='iflink font-weight-normal'>Total {{(memberSavingsTxt && memberSavingsTxt.tag_text) || 'Member Savings'}} Till Now: </span>
                      {{ currencySymbol }} {{exclusiveDetails.exclusive_savings}}
                    </p>
                  </div>
                </div>
                <div
                  v-else
                  @click="redirectToLogin"
                  class="ml-4 login-register toggle-menu"
                >
                  <p>Login/Register</p>
                </div>
              </div>
            </div>
          </div>
          <ul class="navbar-nav" v-if="!(this.$route.path === '/' && isComboActive)">
            <div class="d-flex flex-row mt-3 mx-3 gender-wrapper" v-if="bannerPlaceHolderForSideNav">
              <div v-if="showMenWebMenu" class="col d-flex align-items-center">
                <button class='tab-btn px-0' :class="activeGenderType === 'men' ? 'active-tab-class font-SourceSansPro-SemiBold':''" @click="activeGenderType = 'men'">
                  Men
                </button>
                <div class="seperator" v-if="activeGenderType === 'kids'"></div>
              </div>
              <div v-if="showWomenWebMenu" class="col d-flex align-items-center">
                <button class='tab-btn px-0' :class="activeGenderType === 'women' ? 'active-tab-class font-SourceSansPro-SemiBold':''" @click="activeGenderType = 'women'">
                  Women
                </button>
              </div>
              <div class="col d-flex align-items-center" v-if="showKidsWebMenu && bannerPlaceHolderForKidsWebCategory">
                <div class="seperator" v-if="activeGenderType === 'men'"></div>
                <button class='tab-btn px-0' :class="activeGenderType === 'kids' ? 'active-tab-class font-SourceSansPro-SemiBold':''" @click="activeGenderType = 'kids'">
                  Kids
                </button>
              </div>
            </div>
            <div v-for="(item, index) in genderSpecificNavData" :key="index">
              <div :class="item.isFullWidthWeb ? 'submenucontainer' : ''">
                <div style="margin-left: 5px;" v-if="item.isFullWidthWeb">
                  <div class="row">
                    <div
                      class="col-md-4"
                      :class="item.name + 'Gender'"
                      v-for="(categoryItem, categoryIndex) in item.categories"
                      :key="categoryIndex"
                    >
                      <h5
                        :class="
                          categoryItem.mobile_dropdown ? 'navsubtitle' : ''
                        "
                        :style="categoryItem && categoryItem.is_custom_text_color && categoryItem.custom_text_color
                          ? `color: ${categoryItem.custom_text_color} !important;` : ''
                        "
                        v-if="categoryItem.is_clickable"
                      >
                        <router-link
                          :to="
                            categoryItem.url_key && categoryItem.is_clickable ? categoryItem.url_key : ''
                          "
                          class="toggle-menu"
                          active-class="active"
                          >
                          <span 
                              :class="categoryItem && categoryItem.font_type && categoryItem.font_type.length
                                ? `font-${categoryItem.font_type}`
                                : 'font-SourceSansPro-Regular'
                              "
                              :style="categoryItem && categoryItem.is_custom_text_color && categoryItem.custom_text_color
                                ? `color: ${categoryItem.custom_text_color} !important;` : ''
                              "
                            >
                          {{ categoryItem.name }}
                          <sup
                            v-if="categoryItem.has_tag"
                            style="color: #f00"
                          >
                            {{ categoryItem.tag_name }}</sup
                          >
                          </span>
                          <span class="ripple"></span>
                        </router-link>
                      </h5>
                      <h5
                        :class="
                          categoryItem.mobile_dropdown ? 'navsubtitle' : ''
                        "
                        :style="categoryItem && categoryItem.is_custom_text_color && categoryItem.custom_text_color
                          ? `color: ${categoryItem.custom_text_color} !important;` : ''
                        "
                        v-else
                      >
                        <div
                            :id="`navbarDropdownMenuLinkDiff${categoryIndex}${item.name.replaceAll(' ', '_')}`"
                            data-toggle="dropdown"
                            aria-haspopup="false"
                            aria-expanded="false"
                          >
                          <span 
                              :class="categoryItem && categoryItem.font_type && categoryItem.font_type.length
                                ? `font-${categoryItem.font_type}`
                                : 'font-SourceSansPro-Regular'
                              "
                              :style="categoryItem && categoryItem.is_custom_text_color && categoryItem.custom_text_color
                                ? `color: ${categoryItem.custom_text_color} !important;` : ''
                              "
                            >
                          {{ categoryItem.name }}
                          <sup
                            v-if="categoryItem.has_tag"
                            style="color: #f00"
                          >
                            {{ categoryItem.tag_name }}</sup
                          >
                          </span>
                          <span class="ripple"></span>
                        </div>
                      </h5>
                      <div
                        v-if="
                          categoryItem.sub_categories &&
                          categoryItem.sub_categories.length
                        "
                        class="row sublevel2 mblesublevel2"
                        :class="
                          item.isFullWidthWeb
                            ? 'dropdown-menu fullwidth'
                            : 'dropdown-menu'
                        "
                        :aria-labelledby="`navbarDropdownMenuLinkDiff${categoryIndex}${item.name.replaceAll(' ', '_')}`"
                      >
                        <div class="col-md-6 col-xs-6 col-12" style="padding-left: 0 !important;padding-right: 0 !important;">
                          <div v-if="categoryItem.show_image_with_text" class="newSubMenu row">
                            <div class="d-flex flex-column toggle-menu subCatCard col-3 mb-1 text-center"
                            v-for="(subcategoryItem, index) in categoryItem.sub_categories"
                            @click="subMenu(subcategoryItem, item.name, categoryItem.name)"
                            :key="index"
                            >
                              <div class="iconWrap p-1">
                                <img :data-src="subcategoryItem.menu_icon_image ? subcategoryItem.menu_icon_image : ''" 
                                :class="subcategoryItem.menu_icon_image && subcategoryItem.menu_icon_image !== null
                                ? 'image-cropper' : 'circle'" :alt="subcategoryItem.name"/>
                              </div>
                              <div class="subcatInfo" style="font-size: 0.6rem;">
                                {{ subcategoryItem.name }}
                              </div>
                              <div class="subCathasTag" style="color: #f00;font-size: 0.6rem;" v-if="subcategoryItem.has_tag">
                                {{ subcategoryItem.tag_name }}
                              </div>
                            </div>
                          </div>
                          <ul v-else class="submenu">
                            <li
                              v-for="(subcategoryItem, index) in categoryItem.sub_categories"
                              :key="index"
                            >
                              <a
                                class="toggle-menu"
                                active-class="active"
                                @click="subMenu(subcategoryItem, item.name, categoryItem.name)"
                              >
                                <span style="display: flex;align-items: center;">
                                  <i v-if="bannerPlaceHolderForBulletPointControl" class="fa fa-circle pr-2" style="font-size: 0.4rem; color: #58595b;"></i>
                                  &emsp;{{ subcategoryItem.name }}
                                  <sup
                                  v-if="subcategoryItem.has_tag"
                                  style="color: #f00"
                                  >
                                    {{ subcategoryItem.tag_name }}</sup
                                  >
                                </span>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div v-else>
                  <div>
                    <div
                      v-for="(categoryItem, categoryIndex) in item.categories"
                      :key="categoryIndex"
                      class="mbnav"
                    >
                      <router-link
                        :to="
                          categoryItem.url_key && categoryItem.is_clickable ? categoryItem.url_key : ''
                        "
                        class="toggle-menu"
                        active-class="active"
                        >
                        <span style="display: flex;align-items: center;">
                          <i v-if="bannerPlaceHolderForBulletPointControl" class="fa fa-circle pr-2" style="font-size: 0.4rem; color: #58595b;"></i>
                           {{ categoryItem.name }}
                          <sup
                          v-if="categoryItem.has_tag"
                          style="color: #f00"
                          >
                            {{categoryItem.tag_name }}</sup
                          >
                        </span>
                      </router-link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class='mobile-menu-collections-section' :class="bannerPlaceHolderForSideNav && genderSpecificNavData && genderSpecificNavData.length ? 'section-border-separator-heavy' : ''" >
              <div v-for="(item, index) in otherMenuNavData" :key="index">
                <li v-if="item.mobile_dropdown" class="nav-item dropdown show">
                  <div
                    class="nav-link dropdown-toggle"
                    :id="`navbarDropdownMenuLink1${index}`"
                    data-toggle="dropdown"
                    role="tab"
                    aria-haspopup="true"
                    aria-expanded="false"
                  >
                    <span 
                      :class="item && item.font_type && item.font_type.length
                        ? `font-${item.font_type}`
                        : 'font-SourceSansPro-Regular'
                      "
                      :style="item && item.is_custom_text_color && item.custom_text_color
                        ? `color: ${item.custom_text_color} !important;` : ''
                      "
                    >
                      {{ item.name }}
                      <sup
                        v-if="item.has_tag"
                        style="color: #f00"
                        >
                          {{item.tag_name }}</sup
                        >
                    </span>
                    <span class="ripple"></span>
                  </div>
                  <div
                    v-if="item.categories && item.categories.length"
                    role="tabpanel"
                    :class="
                      item.isFullWidthWeb
                        ? 'dropdown-menu fullwidth'
                        : 'dropdown-menu'
                    "
                    :aria-labelledby="`navbarDropdownMenuLink1${index}`"
                  >
                    <div :class="item.isFullWidthWeb ? 'submenucontainer' : ''">
                      <div v-if="item.isFullWidthWeb">
                        <div class="row pl-1">
                          <div
                            class="col-md-4"
                            :class="item.name"
                            v-for="(categoryItem, categoryIndex) in item.categories"
                            :key="categoryIndex"
                          >
                            <h5
                              :class="
                                categoryItem.mobile_dropdown ? 'navsubtitle' : ''
                              "
                              v-if="categoryItem.is_clickable"
                              :style="bannerPlaceHolderForSideNav ? 'font-weight: normal;' : ''"
                            >
                              <router-link
                                :to="
                                  categoryItem.url_key && categoryItem.is_clickable ? categoryItem.url_key : ''
                                "
                                class="toggle-menu"
                                active-class="active"
                                >
                                <span
                                  style="display: flex;align-items: center;"
                                  :class="categoryItem && categoryItem.font_type && categoryItem.font_type.length
                                    ? `font-${categoryItem.font_type}`
                                    : 'font-SourceSansPro-Regular'
                                  "
                                  :style="categoryItem && categoryItem.is_custom_text_color && categoryItem.custom_text_color
                                    ? `color: ${categoryItem.custom_text_color} !important;` : ''
                                  "
                                >
                                  <i v-if="(bannerPlaceHolderForSideNav && bannerPlaceHolderForBulletPointControl)" class="fa fa-circle pr-2" style="font-size: 0.4rem; color: #58595b;"></i>
                                  &emsp;{{ categoryItem.name }}
                                <sup
                                  v-if="categoryItem.has_tag"
                                  style="color: #f00"
                                >
                                  {{ categoryItem.tag_name }}</sup
                                >
                                </span>
                                <span class="ripple"></span>
                              </router-link>
                            </h5>
                            <h5
                              :class="
                                categoryItem.mobile_dropdown ? 'navsubtitle' : ''
                              "
                              v-else
                              :style="bannerPlaceHolderForSideNav ? 'font-weight: normal;' : ''"
                            >
                              <div
                                  :id="`navbarDropdownMenuLink2${categoryIndex}${item.name.replaceAll(' ', '_')}`"
                                  data-toggle="dropdown"
                                  aria-haspopup="true"
                                  role="tab"
                                  aria-expanded="false"
                                >
                                <span
                                  style="display: flex;align-items: center;"
                                  :class="categoryItem && categoryItem.font_type && categoryItem.font_type.length
                                    ? `font-${categoryItem.font_type}`
                                    : 'font-SourceSansPro-Regular'
                                  "
                                  :style="categoryItem && categoryItem.is_custom_text_color && categoryItem.custom_text_color
                                    ? `color: ${categoryItem.custom_text_color} !important;` : ''
                                  "
                                >
                                  <i v-if="(bannerPlaceHolderForSideNav && bannerPlaceHolderForBulletPointControl)" class="fa fa-circle pr-2" style="font-size: 0.4rem; color: #58595b;"></i>
                                  &emsp;{{ categoryItem.name }}
                                <sup
                                  v-if="categoryItem.has_tag"
                                  style="color: #f00"
                                >
                                  {{ categoryItem.tag_name }}</sup
                                >
                                </span>
                                <span class="ripple"></span>
                              </div>
                            </h5>
                            <div
                              v-if="
                                categoryItem.sub_categories &&
                                categoryItem.sub_categories.length
                              "
                              class="row sublevel2 mblesublevel2"
                              role="tabpanel"
                              :class="
                                item.isFullWidthWeb
                                  ? 'dropdown-menu fullwidth'
                                  : 'dropdown-menu'
                              "
                              :aria-labelledby="`navbarDropdownMenuLink2${categoryIndex}${item.name.replaceAll(' ', '_')}`"
                            >
                              <div class="col-md-6 col-xs-6 col-12" style="padding-left: 0 !important;padding-right: 0 !important;">
                                <div v-if="categoryItem.show_image_with_text" class="newSubMenu row">
                                  <div class="d-flex flex-column toggle-menu subCatCard col-3 mb-1 text-center"
                                  v-for="(subcategoryItem, index) in categoryItem.sub_categories"
                                  @click="subMenu(subcategoryItem, item.name, categoryItem.name)"
                                  :key="index"
                                  >
                                    <div class="iconWrap p-1">
                                      <img :data-src="subcategoryItem.menu_icon_image ? subcategoryItem.menu_icon_image : ''" 
                                      :class="subcategoryItem.menu_icon_image && subcategoryItem.menu_icon_image !== null
                                      ? 'image-cropper' : 'circle'" :alt="subcategoryItem.name"/>
                                    </div>
                                    <div class="subcatInfo" style="font-size: 0.6rem;">
                                      {{ subcategoryItem.name }}
                                    </div>
                                    <div class="subCathasTag" style="color: #f00;font-size: 0.6rem;" v-if="subcategoryItem.has_tag">
                                      {{ subcategoryItem.tag_name }}
                                    </div>
                                  </div>
                                </div>
                                <ul v-else class="submenu">
                                  <li
                                    v-for="(subcategoryItem, index) in categoryItem.sub_categories"
                                    :key="index"
                                  >
                                    <a
                                      class="toggle-menu"
                                      active-class="active"
                                      @click="subMenu(subcategoryItem, item.name, categoryItem.name)"
                                    >
                                      <span
                                        style="display: flex;align-items: center;"
                                        :class="[
                                          bannerPlaceHolderForSideNav ? 'pl-3' : '',
                                          subcategoryItem && subcategoryItem.font_type && subcategoryItem.font_type.length
                                          ? `font-${subcategoryItem.font_type}`
                                          : 'font-SourceSansPro-Regular'
                                        ]"
                                        :style="subcategoryItem && subcategoryItem.is_custom_text_color && subcategoryItem.custom_text_color
                                          ? `color: ${subcategoryItem.custom_text_color} !important;` : ''
                                        "
                                      >
                                        <i v-if="(bannerPlaceHolderForSideNav && bannerPlaceHolderForBulletPointControl)" class="fa fa-circle pr-2" style="font-size: 0.4rem; color: #58595b;"></i>
                                        {{ subcategoryItem.name }}
                                        <sup
                                        v-if="subcategoryItem.has_tag"
                                        style="color: #f00"
                                        >
                                          {{ subcategoryItem.tag_name }}</sup
                                        >
                                      </span>
                                    </a>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div v-else>
                        <div v-if="item.show_image_with_text" class="newSubMenu row ml-3 mr-3" style="padding-left: 0 !important;padding-right: 0 !important;">
                          <div class="d-flex flex-column toggle-menu subCatCard col-3 mb-1 text-center"
                          v-for="(subcategoryItem, index) in item.categories"
                          @click="subMenu(subcategoryItem, item.name, categoryItem.name)"
                          :key="index"
                          >
                            <div class="iconWrap p-1">
                              <img :data-src="subcategoryItem.menu_icon_image ? subcategoryItem.menu_icon_image : ''" 
                              :class="subcategoryItem.menu_icon_image && subcategoryItem.menu_icon_image !== null
                              ? '' : 'circle'" :alt="subcategoryItem.name"/>
                            </div>
                            <div class="subcatInfo" style="font-size: 0.6rem;">
                              {{ subcategoryItem.name }}
                            </div>
                            <div class="subCathasTag" style="color: #f00;font-size: 0.6rem;" v-if="subcategoryItem.has_tag">
                              {{ subcategoryItem.tag_name }}
                            </div>
                          </div>
                        </div>
                        <div v-else>
                          <div
                            v-for="(categoryItem, categoryIndex) in item.categories"
                            :key="categoryIndex"
                            class="mbnav"
                          >
                            <router-link
                              :to="
                                categoryItem.url_key && categoryItem.is_clickable ? categoryItem.url_key : ''
                              "
                              class="toggle-menu"
                              active-class="active"
                              >
                              <span
                                style="display: flex;align-items: center;"
                                :class="categoryItem && categoryItem.font_type && categoryItem.font_type.length
                                  ? `font-${categoryItem.font_type}`
                                  : 'font-SourceSansPro-Regular'
                                "
                                :style="categoryItem && categoryItem.is_custom_text_color && categoryItem.custom_text_color
                                  ? `color: ${categoryItem.custom_text_color} !important;` : ''
                                "
                              >
                                <i v-if="(bannerPlaceHolderForSideNav && bannerPlaceHolderForBulletPointControl)" class="fa fa-circle pr-2" style="font-size: 0.4rem; color: #58595b;"></i>
                                &emsp;{{ categoryItem.name }}
                                <sup
                                v-if="categoryItem.has_tag"
                                style="color: #f00"
                                >
                                  {{categoryItem.tag_name }}</sup
                                >
                              </span>
                            </router-link>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
                <li v-else class="nav-item">
                  <router-link
                    :to="item.url_key ? item.url_key : '' "
                    class="nav-link toggle-menu"
                    :class="item && item.font_type && item.font_type.length
                      ? `font-${item.font_type}`
                      : 'font-SourceSansPro-Regular'
                    "
                    :style="item && item.is_custom_text_color && item.custom_text_color
                      ? `color: ${item.custom_text_color} !important;` : ''
                    "
                    @click.native="menuClick"
                  >
                    {{item.name}}
                    <sup v-if="item.has_tag" style="color: #f00">
                      {{ item.tag_name }}</sup
                    >
                  </router-link>
                </li>
              </div>
            </div>
            <div class="mobile-menu-order-section section-border-separator" v-if="authStatus">
              <li class="nav-item" v-if="excMemberShipData && excMemberShipData.length">
                <router-link
                  :to="excMemberShipData && excMemberShipData[0] && excMemberShipData[0].url_key ? excMemberShipData[0].url_key : '' "
                  class="nav-link toggle-menu"
                  :class="excMemberShipData && excMemberShipData[0] && excMemberShipData[0].font_type && excMemberShipData[0].font_type.length
                    ? `font-${excMemberShipData[0].font_type}`
                    : 'font-SourceSansPro-Regular'
                  "
                  :style="
                    excMemberShipData && excMemberShipData[0] && excMemberShipData[0].is_custom_text_color
                      ? `color: ${excMemberShipData[0].custom_text_color}`
                      : 'color:inherit'
                  "
                >
                  {{excMemberShipData[0].name}}
                  <sup v-if="excMemberShipData[0].has_tag" style="color: #f00">
                    {{ excMemberShipData[0].tag_name }}</sup
                  >
                </router-link>
              </li>
              <li v-if="bannerPlaceHolderForStoreNearMe" class="nav-item contact-us">
                <router-link
                  to="/stores-near-me"
                  class="nav-link defaultColor toggle-menu font-weight-normal"
                >
                  Store Near Me 
                </router-link>
              </li>
              <li class="nav-item my-account">
                <router-link to="/my-account" class="nav-link toggle-menu font-weight-normal"
                  >
                  My Account
                  <span class="badge badge-danger rounded-circle" title="Expiring soon"
                  v-if="hasCounts"
                  >
                    {{ totalCount }}
                  </span>
                  </router-link
                >
              </li>
              <li class="nav-item" :class="trackOrdersFlagHandler && trackOrdersFlagHandler.length > 0 ? 'track-my-order' : 'my-orders'">
                <router-link to="/orders" class="nav-link toggle-menu font-weight-normal"
                  >{{trackOrdersFlagHandler && trackOrdersFlagHandler.length > 0 ? 'Track my order' : 'My Orders' }}</router-link
                >
              </li>
              <!--
              <li class="nav-item mywishlist">
                <router-link
                  to="/mywishlist"
                  class="nav-link toggle-menu font-weight-normal"
                  @click.native="myWishlistVisitEventHandler('specific')"
                >
                  Wishlist
                </router-link>
              </li>
              -->
            </div>
            <div
              class='mobile-menu-more-info-section'
              :class="!authStatus ? 'section-border-separator' : ''"
              v-if="moreSectionCategories && moreSectionCategories.length && !(bannerPlaceHolderForMoreSection && bannerPlaceHolderForMoreSection.length === moreSectionCategories.length)"
            >
              <!-- <li class="nav-item faqs">
                <router-link
                  to="/faqs"
                  class="nav-link defaultColor toggle-menu"
                  >FAQs</router-link
                >
              </li>
              <li class="nav-item tnc">
                <router-link
                  to="/terms-and-conditions"
                  class="nav-link defaultColor toggle-menu"
                >
                  Terms And Conditions
                </router-link>
              </li> -->
              <li class="nav-item" v-if="excMemberShipData && excMemberShipData.length && !authStatus">
                <router-link
                  :to="excMemberShipData && excMemberShipData[0] && excMemberShipData[0].url_key ? excMemberShipData[0].url_key : '' "
                  class="nav-link toggle-menu"
                  :class="excMemberShipData && excMemberShipData[0] && excMemberShipData[0].font_type && excMemberShipData[0].font_type.length
                    ? `font-${excMemberShipData[0].font_type}`
                    : 'font-SourceSansPro-Regular'
                  "
                  :style="
                    excMemberShipData && excMemberShipData[0] && excMemberShipData[0].is_custom_text_color
                      ? `color: ${excMemberShipData[0].custom_text_color}`
                      : 'color:inherit'
                  "
                >
                  {{excMemberShipData[0].name}}
                  <sup v-if="excMemberShipData[0].has_tag" style="color: #f00">
                    {{ excMemberShipData[0].tag_name }}</sup
                  >
                </router-link>
              </li>
              <li v-if="bannerPlaceHolderForStoreNearMe && !authStatus" class="nav-item contact-us">
                <router-link
                  to="/stores-near-me"
                  class="nav-link defaultColor toggle-menu font-weight-normal"
                >
                  Store Near Me 
                </router-link>
              </li>
              <li class="nav-item contact-us">
                <router-link
                  to="/contact-us"
                  class="nav-link defaultColor toggle-menu font-weight-normal"
                  @click.native="contactUsEventHandler()"
                >
                  <span>Contact Us</span>
                </router-link>
              </li>
              <li class="nav-item faqs">
                <router-link
                  to="/faqs"
                  class="nav-link defaultColor toggle-menu font-weight-normal"
                >
                  FAQs
                </router-link>
              </li>
              <li v-if="isShowCommunityInitiatives" class="nav-item faqs">
                <router-link
                  to="/from-the-soul"
                  class="nav-link defaultColor toggle-menu font-weight-normal"
                >
                  Community Initiatives
                </router-link>
              </li>
              <li class="nav-item dropdown show section-border-separator">
                <div class="nav-link dropdown-toggle" id="navbarDropdownMenuLink3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" role="tab">
                  More
                  <span class="ripple"></span>
                </div>
                <div class="dropdown-menu" role="tabpanel" aria-labelledby="navbarDropdownMenuLink3">
                  
                  <div>
                    <div v-for="(categoryItem, categoryIndex) in moreSectionCategories" :key="categoryIndex" class="mbnav"
                    >
                      <router-link v-if="!(bannerPlaceHolderForMoreSection && bannerPlaceHolderForMoreSection.length && bannerPlaceHolderForMoreSection.includes(categoryItem.name && categoryItem.name.toLowerCase()))"
                        :to="categoryItem.url_key ? categoryItem.url_key : ''"
                        class="toggle-menu"
                        active-class="active"
                      >
                        <span style="display: flex;align-items: center;">{{ categoryItem.name }}</span>
                      </router-link>
                    </div>
                    <div class="mbnav" v-if="bannerPlaceHolderForBlog && bannerPlaceHolderForBlog.description">
                      <a :href="bannerPlaceHolderForBlog && bannerPlaceHolderForBlog.description" target="_blank"><span>{{ bannerPlaceHolderForBlog.tag_text || 'Blog'}}</span></a>
                    </div>
                  </div>
                </div>
              </li>
            </div>
          </ul>
        </div>
        <div class="overlay" @click="toggleHandler"></div>
      </div>
      <div>
        <div class="mobilesearch" v-if="togglesearch">
          <div class="mbinput">
            <autocomplete
              :trigger="trigger"
              :searchTerm="searchTerm"
            ></autocomplete>
          </div>
        </div>
      </div>
    </nav>
    <div class="row home-gender-wrapper" v-if="!bannerPlaceHolderForGoForAppOnlySale && ($route.path === '/men' || $route.path === '/women' || $route.path === '/kids') && !isCodCheckoutLogin">
      <div v-if="showMenWebMenu" class="col comboMenu" style="padding: 0px;" :class="$route.path === '/men' ? 'home-active-tab-class':''">
        <button  :style="$route.path === '/men' ? 'font-weight: 600' : ''" class='tab-btn pt-1 pb-1 men '  @click="setHomeMenu('men')">
          Men
          <span class="ripple"></span>
        </button>
      </div>
      <div v-if="showWomenWebMenu" class="col comboMenu" style="padding: 0px;" :class="$route.path === '/women' ? 'home-active-tab-class':''">
        <button :style="$route.path === '/women' ? 'font-weight: 600' : ''" class='tab-btn pt-1 pb-1 women'  @click="setHomeMenu('women')">
          Women
          <span class="ripple"></span>
        </button>
      </div>
      <div v-if="showKidsWebMenu && bannerPlaceHolderForKidsWebCategory" class="col comboMenu" style="padding: 0px;" :class="$route.path === '/kids' ? 'home-active-tab-class':''">
        <button  :style="$route.path === '/kids' ? 'font-weight: 600' : ''" class='tab-btn pt-1 pb-1 men '  @click="setHomeMenu('kids')">
          Kids
          <span class="ripple"></span>
        </button>
      </div>
    </div>
    <login-modal
      v-if="loginModel"
      @close="userAcc.loginBox = false"
    ></login-modal>
    <order-track v-if="oTrack" @close="oTrack = false"></order-track>
  </div>
</template>
<script>
var $ = require('jquery')
window.jQuery = $
const LoginModal = () => import('./components/common/LoginModal.vue')
const orderTrack = () => import('./components/widgets/orderTrack')
const autocomplete = () => import('./components/common/autocomplete')
import auth from './auth/index.js'
import {mapGetters} from 'vuex'
import debounce from 'lodash/debounce'
import {appMixins, osDetector, browserDetector} from './assets/js/appMixins'
import Vue from 'vue'
import LocationChange from './components/common/LocationChange.vue'

var offm = {
  props: {
    dataname: String,
    dataurl: String
  },
  data () {
    return {
      linkarray: this.dataname.split(','),
      datalink: this.dataurl.split(','),
      linkpath: '/artists/',
      tssMoneyCounts: 0,
      tssPointsCounts: 0
    }
  },
  template:
    '<div class="sublevel2"><ul class="submenu"><li v-for="(item, index) in linkarray" :key="index"><a href="https://www.thesouledstore.com" target="_blank" v-if="datalink[index] === \'wwe-official-merchandise\'">{{ item}} </a> <router-link :to="\'/artist/\'+ datalink[index]" v-else>{{ item}} </router-link></li></ul></div>'
}
export default {
  name: 'app',
  components: {
    LoginModal,
    'off-nav': offm,
    orderTrack,
    autocomplete,
    LocationChange
  },
  mixins: [appMixins, osDetector, browserDetector],
  data () {
    return {
      userAcc: auth.user,
      ckAuth: auth,
      searchTerm: '',
      value: '',
      suggestionAttribute: 'product',
      suggestions: [],
      selectedEvent: '',
      oTrack: false,
      count: 0,
      catImgPath: process.env.IMG_BASE_URL + process.env.CATEGORY_IMG,
      togglesearch: false,
      now: new Date(),
      launchDate: new Date(process.env.TIMER_START),
      trigger: false,
      showHeader: true,
      activeGenderType: 'men',
      starRating: null,
      trackOrdersToShow: [2, 8, 9, 16, 18, 26],
      moreSectionCategories: [
        {name: 'Careers', url_key: '/careers'},
        // {name: 'Community Initiatives', url_key: '/from-the-soul'},
        {name: 'About Us', url_key: '/about-us'},
        // {name: 'Gift Vouchers', url_key: '/gift-voucher'},
        {name: 'T&C', url_key: '/terms-and-conditions'},
        {name: 'Privacy Policy', url_key: '/privacy-policy'}
      ],
      imgBaseUrl: process.env.STATIC_IMG_SERVER2
    }
  },
  methods: {
    subMenu (subcategoryItem, type, category) {
      let url = subcategoryItem.url_key && subcategoryItem.is_clickable ? subcategoryItem.url_key : ''
      if (type === 'Men') {
        this.$store.commit('GTAG_EVENT', {eventName: 'men', payload: {id: subcategoryItem.name}})
      } else if (type === 'Women') {
        this.$store.commit('GTAG_EVENT', {eventName: 'women', payload: {id: subcategoryItem.name}})
      } else if (type === 'Themes') {
        this.$store.commit('GTAG_EVENT', {eventName: 'themes', payload: {id: subcategoryItem.name}})
      }
      this.$store.commit('MOENGAGE_EVENT', {eventName: 'MENU-LIST',
        payload: {
          Category: subcategoryItem.name,
          Section: type === 'Men' || type === 'Women' ? type : 'Men',
          Sub_Category: category
        }}
      )
      this.$store.commit('SET_NAVIGATION_WIDGET', 'Menu')
      this.$router.push(url)
    },
    addEventsForTshirt (url) {
      switch (url) {
        case '/men/t-shirts':
          this.$store.commit('MENS_TSHIRT_CLICK_EVENT', url)
          break
        case '/women/t-shirts':
          this.$store.commit('WOMENS_TSHIRT_CLICK_EVENT', url)
          break
        default:
          break
      }
    },
    getDeviceRating () {
      const os = this.getMobileOperatingSystem()
      if (os === 'ios') {
        this.starRating = this.isShowAppRatingOnMwebIos
      } else if (os === 'android') {
        this.starRating = this.isShowAppRatingOnMweb
      }
    },
    getRatingToShow (rating) {
      const os = this.getMobileOperatingSystem()
      const decimalPart = rating % 1
      if (decimalPart > 0.1 && decimalPart < 0.2) {
        return (rating * 20) + 1
      } else if (decimalPart > 0.5 && decimalPart < 0.7) {
        return (rating * 20) - (os === 'ios' ? 2 : 1)
      } else if (decimalPart > 0.7 && decimalPart < 0.9) {
        return (rating * 20) - (os === 'ios' ? 4 : 2)
      } else if (decimalPart < 0.1) {
        return (rating * 20) - 1
      } else {
        return (rating * 20)
      }
    },
    menuClick () {
      this.$store.commit('SET_NAVIGATION_WIDGET', 'Menu')
    },
    redirectToMyAcc () {
      this.$router.push('/my-account')
    },
    redirectToAppStore: function () {
      this.$store.commit('GTAG_EVENT', {eventName: 'App_Topbar_Click', payload: {}})
      this.$store.commit('GTAG_EVENT', {eventName: 'download_app', payload: {}})
      if (navigator.userAgent.toLowerCase().indexOf('android') > -1) {
        window.location.href =
          'https://play.google.com/store/apps/details?id=com.thesouledstore'
      } else if (navigator.userAgent.toLowerCase().indexOf('iphone') > -1) {
        window.location.href =
          'https://apps.apple.com/in/app/thesouledstore/id1493897434'
      } else {
        window.location.href =
          'https://play.google.com/store/apps/details?id=com.thesouledstore'
      }
    },
    searchFocus () {
      this.trigger = false
    },
    openSearch () {
      this.$router.push('/autocomplete')
    },
    redirectToLogin () {
      this.$router.push(`/login?redirect=${this.$route.fullPath}`)
    },
    cartEventHandler () {
      this.$store.commit('GTAG_EVENT', {eventName: 'CART_ICON_CLICK', payload: {}})
    },
    logout () {
      // auth.logout(this, '/')
      this.$store.dispatch('BLACKLIST_LOGOUT').then(res => {
        this.$store.dispatch('LOGOUT', {
          requiresAuth: this.$route.meta.requiresAuth
        }).then(res => {
          this.$toasted.show((res && res.message) || 'You have been successfully logged out', {
            theme: 'primary',
            className: 'toasted-customred',
            position: 'top-right',
            duration: 5000
          })
          this.$store.dispatch('CART_DATA')
          this.$store.dispatch('WISHLIST_DATA')
          $('body').removeClass('_freeze')
          $('.overlay').removeClass('show')
          this.$store.state.auth.phoneNumber = ''
        })
      })
    },
    search: function (e) {
      var regex = new RegExp(/^\s+$/)
      if (regex.test(this.value)) {
        this.value = ''
      } else {
        if (e.keyCode === 13) {
          this.$router.push('/search?q=' + this.value)
        } else if (this.value.length > 2) {
          // this.$router.push('/search/' + this.value)
        }
      }
    },
    loginBoxModal () {
      // this.userAcc.loginBox = true
      this.$store.dispatch('SET_LOGINBOX', { flag: true })
    },
    submitSearch: function () {
      this.$router.push('/search?q=' + this.value)
      // this.value = ''
    },
    clickInput: function () {
      this.selectedEvent = 'click input'
    },
    clickButton: function () {
      this.selectedEvent = 'click button'
    },
    selected: function () {
      this.selectedEvent = 'selection changed'
    },
    enter: function () {
      this.selectedEvent = 'enter'
      this.$router.push('/search?q=' + this.value)
      // this.value = ''
    },
    keyUp: function () {
      this.selectedEvent = 'keyup pressed'
    },
    keyDown: function () {
      this.selectedEvent = 'keyDown pressed'
    },
    keyRight: function () {
      this.selectedEvent = 'keyRight pressed'
    },
    clear: function () {
      this.selectedEvent = 'clear input'
    },
    escape: function () {
      this.selectedEvent = 'escape'
    },
    trackModal () {
      this.oTrack = true
    },
    onClickHeaderLogo () {
      window.open(process.env.TSS_URL, '_blank')
    },
    goToPreviousPage () {
      window.history.back()
    },
    myWishlistVisitEventHandler (priority) {
      priority === 'default' ? this.$store.commit('GTAG_EVENT', {eventName: `myWishlist_pageview`, payload: {visitFrom: Vue.ls.get('routeObj').current}}) : this.$store.commit('GTAG_EVENT', {eventName: `myWishlist_pageview`, payload: {visitFrom: 'My Account Section'}})
      priority === 'default' ? this.$store.dispatch('TATVIC_EVENT', {eventName: 'WISHLIST_REDIRECTION_CLICK',
        payload: {
          INTERACTION_TYPE: 'Icon Click'
        }
      }) : this.$store.dispatch('TATVIC_EVENT', {eventName: 'WISHLIST_REDIRECTION_CLICK',
        payload: {
          INTERACTION_TYPE: 'CTA Click'
        }
      })
    },
    homeEventHandler (path) {
      this.$store.dispatch('TATVIC_EVENT', {eventName: 'LOGO_CLICK', payload: {}})
      this.$router.push(path)
    },
    appOpenHandler: debounce(function (e) {
      const gemderHomeUrl = [
        'https://www.thesouledstore.com/men',
        'https://www.thesouledstore.com/women',
        'https://www.thesouledstore.com/kids'
      ]
      let payloadUrl = gemderHomeUrl.includes(document.URL) ? 'https://www.thesouledstore.com' : document.URL
      this.$store.dispatch('GET_FIREBASE_DYNAMIC_LINK_DATA', {link: payloadUrl}).then(res => {
        res && res.shortLink && res.shortLink.length
        ? window.location.replace(res.shortLink)
        : this.appOpenFallbackHandler()
      })
      this.$store.commit('MOENGAGE_EVENT', {
        eventName: 'OPEN_APP_CLICK',
        payload: {
          UserId: this.user && this.user.user_id ? this.user.user_id : 0,
          Platform: 'WEB'
        }
      })
    }, 800),
    appOpenFallbackHandler () {
      const deviceOs = this.getMobileOperatingSystem()
      if (deviceOs === 'android') {
        const url = 'intent://thesouledstore.com/#Intent;scheme=https;package=com.thesouledstore;end'
        window.location.replace(url)
      } else if (deviceOs === 'ios') {
        window.location.replace('https://bit.ly/appxtss')
      }
    },
    setHomeMenu (gender) {
      const routeObj = Vue.ls.get('routeObj')
      this.$store.commit('WEBCATEGORY', gender)
      this.$store.commit('GTAG_EVENT', {eventName: 'top_navigation',
        payload: {
          USER_ID: this.user && this.user.user_id ? this.user.user_id : 0,
          USER_TYPE: this.user && this.user.user_type,
          SOURCE: routeObj.previous,
          PAGE_NAME: routeObj.current,
          INTERACTION_TYPE: gender,
          UPDATED_SCHEMA: 'Yes',
          LOGGED_IN_STATUS: this.$store.getters.authStatus ? 'Logged In' : 'Non Logged In'
        }
      })
      this.activeGenderType = this.webcategory
      this.$router.push(`/${gender}`)
    },
    toggleHandler () {
      this.setHomeMenu(this.activeGenderType)
    },
    getPlatformCounts () {
      this.notificationData && this.notificationData.forEach(element => {
        if (element.platform === 'TSS_MONEY') {
          this.tssMoneyCounts = element.counts
        } else if (element.platform === 'TSS_POINTS') {
          this.tssPointsCounts = element.counts
        } else {
          this.tssMoneyCounts = 0
          this.tssPointsCounts = 0
        }
      })
    },
    contactUsEventHandler () {
      this.$store.commit('MOENGAGE_EVENT', {eventName: 'TRACK_CONTACT_US_SIDEMENU_CLICK',
        payload: {
          UserId: this.user && this.user.user_id ? this.user.user_id : 0,
          DateTime: new Date() && new Date().toISOString(),
          Platform: 'WEB',
          PageName: 'SideMenu'
        }}
      )
    }
  },
  beforeUpdate () {
    $('body').removeClass('_freeze')
  },
  mounted: function () {
    this.$store.dispatch('COUNTRIES')
    this.activeGenderType = this.webcategory || 'men'
    if (this.$route.name === 'search' && this.$route.query && this.$route.query.q) {
      this.$store.dispatch('setSearchPageKey', this.$route.query.q)
    }
    if (this.$route.path === '/autocomplete') {
      this.showHeader = false
    } else {
      this.showHeader = true
    }
    this.ckAuth.checkAuth()
    this.bannerPlaceHolderForGiftVoucher ? this.moreSectionCategories && this.moreSectionCategories.splice(3, 0, {name: 'Gift Vouchers', url_key: '/gift-voucher'}) : ''
    !this.bannerPlaceHolderForStoreNearMe ? this.moreSectionCategories && this.moreSectionCategories.splice(1, 0, {name: 'Store Near Me', url_key: '/stores-near-me'}) : ''
    // $('.toggle-menu').on('click', this.toggleMenu)
    this.getPlatformCounts()
    this.getDeviceRating()
  },
  computed: {
    ...mapGetters({
      loginModel: 'loginModelBox',
      authStatus: 'authStatus',
      cartcount: 'cartcount',
      _products: 'FETCH_PRODUCTS',
      isMystery: 'isMystery',
      user: 'user',
      isExclusive: 'isExclusive',
      exclusiveUser: 'exclusiveUser',
      navMenuData: 'navMenuData',
      webcategory: 'webcategory',
      bannerPlcaeHolderData: 'bannerPlcaeHolderData',
      isComboActive: 'isComboActive',
      orders: 'orders',
      wishlistCount: 'wishlistCount',
      disableWishlist: 'disableWishlist',
      exclusiveDetails: 'exclusiveDetails',
      supimaLandingData: 'supimaLandingData',
      productListingHeader: 'productListingHeader',
      productListingStyle: 'productListingStyle',
      activeWearLandingData: 'activeWearLandingData',
      isBirthdayMonth: 'isBirthdayMonth',
      memberSavingsTxt: 'memberSavingsTxt',
      notificationData: 'notificationData',
      isPosLogin: 'isPosLogin',
      isCodCheckoutLogin: 'isCodCheckoutLogin',
      currencySymbol: 'currencySymbol',
      isSelectedCountryIndia: 'isSelectedCountryIndia',
      getGlobalSettingKeys: 'getGlobalSettingKeys',
      globalBannerPlaceholder: 'globalBannerPlaceholder',
      hasAddressChanged: 'hasAddressChanged',
      countries: 'countries'
    }),
    hasCounts () {
      return (this.tssMoneyCounts + this.tssPointsCounts) > 0
    },
    totalCount () {
      return this.tssMoneyCounts + this.tssPointsCounts
    },
    genderSpecificNavData () {
      if (this.bannerPlaceHolderForSideNav) {
        const genderType = this.activeGenderType
        if (genderType === 'men') {
          return this.navMenuData && this.navMenuData.filter((itm) => itm.name === 'Men')
        } else if (genderType === 'women') {
          return this.navMenuData && this.navMenuData.filter((itm) => itm.name === 'Women')
        }
        return this.navMenuData && this.navMenuData.filter((itm) => itm.name === 'Kids')
      }
    },
    otherMenuNavData () {
      if (!this.bannerPlaceHolderForSideNav) {
        return this.navMenuData && this.navMenuData.filter((itm) => itm.name && !itm.name.toLowerCase().includes('membership'))
      }
      return this.navMenuData && this.navMenuData.filter((itm) => itm.name !== 'Men' && itm.name !== 'Women' && itm.name !== 'Kids' && itm.name && !itm.name.toLowerCase().includes('membership'))
    },
    excMemberShipData () {
      let excData = ''
      if (this.authStatus && this.exclusiveUser) {
        excData = this.navMenuData && this.navMenuData.filter((itm) => (itm.merged_categories === 'exclusive_user'))
      } else {
        excData = this.navMenuData && this.navMenuData.filter((itm) => (itm.merged_categories === 'non_exclusive_user'))
      }
      if (excData && excData.length > 0) {
        return excData
      }
      return this.navMenuData && this.navMenuData.filter((itm) => (itm.name === 'Membership'))
    },
    bannerPlaceHolderForSideNav: function () {
      const isSideNavObj = this.bannerPlcaeHolderData && this.bannerPlcaeHolderData.length && this.bannerPlcaeHolderData.find(bannerData =>
        bannerData.placeholder_for.toLowerCase() === 'Others'.toLowerCase() && bannerData.status === true && bannerData.product_type.toLowerCase() === 'SHOW_SIDE_MENU_WEB'.toLowerCase())
      if (isSideNavObj) {
        return true
      }
      return null
    },
    bannerPlaceHolderForBlog () {
      return this.bannerPlcaeHolderData && this.bannerPlcaeHolderData.length && this.bannerPlcaeHolderData.find(bannerData =>
        bannerData.placeholder_for.toLowerCase() === 'Home Screen Page'.toLowerCase() && bannerData.status === true && bannerData.product_type.toLowerCase() === 'SHOW_BLOG_IN_FOOTER_WEB'.toLowerCase())
    },
    trackOrdersFlagHandler () {
      if (this.orders && this.orders.length > 0) {
        return this.orders.filter(order => this.trackOrdersToShow.includes(order.order_status))
      }
    },
    bannerPlaceHolderForMoreSection: function () {
      const hideMoreSection = this.bannerPlcaeHolderData && this.bannerPlcaeHolderData.length && this.bannerPlcaeHolderData.find(bannerData =>
        bannerData.placeholder_for.toLowerCase() === 'Others'.toLowerCase() && bannerData.status === true && bannerData.product_type.toLowerCase() === 'HIDE_MOBILE_MENU_MORE_SECTION'.toLowerCase()
      )
      return hideMoreSection && hideMoreSection.tag_text && hideMoreSection.tag_text.split(',').map(itemName => itemName.trim())
    },
    bannerPlaceHolderForAppDownldPopup: function () {
      return this.bannerPlcaeHolderData && this.bannerPlcaeHolderData.length && this.bannerPlcaeHolderData.find(bannerData =>
      bannerData.placeholder_for.toLowerCase() === 'Others'.toLowerCase() && bannerData.status === true && bannerData.product_type.toLowerCase() === 'SHOW_APP_DOWNLOAD_POPUP_WEB'.toLowerCase())
    },
    bannerPlaceHolderForGiftVoucher: function () {
      return this.bannerPlcaeHolderData && this.bannerPlcaeHolderData.length && this.bannerPlcaeHolderData.find(bannerData =>
        bannerData.placeholder_for.toLowerCase() === 'others' && bannerData.status === true && bannerData.product_type.toLowerCase() === 'ENABLE_GIFT_VOUCHER_WEB'.toLowerCase()
      )
    },
    bannerPlaceHolderForStoreNearMe: function () {
      return this.bannerPlcaeHolderData && this.bannerPlcaeHolderData.length && this.bannerPlcaeHolderData.find(bannerData =>
        bannerData.placeholder_for.toLowerCase() === 'address screen' && bannerData.status === true && bannerData.product_type.toLowerCase() === 'SHOW_NEARME_BEFORE_MEMBERS_WEB'.toLowerCase()
      )
    },
    bannerPlaceHolderForKidsWebCategory: function () {
      return this.bannerPlcaeHolderData && this.bannerPlcaeHolderData.length && this.bannerPlcaeHolderData.find(bannerData =>
        bannerData.placeholder_for.toLowerCase() === 'Others'.toLowerCase() && bannerData.status === true &&
        bannerData.product_type.toLowerCase() === 'SHOW_KIDSWEAR_WEBCATEGORY_WEB'.toLowerCase())
    },
    bannerPlaceHolderForGoForAppOnlySale: function () {
      return this.bannerPlcaeHolderData && this.bannerPlcaeHolderData.length && this.bannerPlcaeHolderData.find(bannerData =>
        bannerData.placeholder_for.toLowerCase() === 'Others'.toLowerCase() && bannerData.status === true && bannerData.product_type.toLowerCase() === 'GO_APP_ONLY_SALE_WEB'.toLowerCase())
    },
    bannerPlaceHolderForBulletPointControl: function () {
      return this.bannerPlcaeHolderData && this.bannerPlcaeHolderData.length && this.bannerPlcaeHolderData.find(bannerData =>
        bannerData.placeholder_for.toLowerCase() === 'Others'.toLowerCase() && bannerData.status === true && bannerData.product_type.toLowerCase() === 'SIDEMENU_BULLET_CONTROL'.toLowerCase())
    },
    isShowCommunityInitiatives: function () {
      return this.bannerPlcaeHolderData && this.bannerPlcaeHolderData.length && this.bannerPlcaeHolderData.find(bannerData =>
        bannerData.placeholder_for.toLowerCase() === 'Home Screen Page'.toLowerCase() && bannerData.status === true && bannerData.product_type.toLowerCase() === 'SHOW_COMMUNITY_INITIATIVES_WEB'.toLowerCase())
    },
    isShowAppRatingOnMweb: function () {
      return this.bannerPlcaeHolderData && this.bannerPlcaeHolderData.length && this.bannerPlcaeHolderData.find(bannerData =>
        bannerData.placeholder_for.toLowerCase() === 'Home Screen Page'.toLowerCase() && bannerData.status === true && bannerData.product_type.toLowerCase() === 'HEADER_APP_RATING_MWEB_ANDROID'.toLowerCase())
    },
    isShowAppRatingOnMwebIos: function () {
      return this.bannerPlcaeHolderData && this.bannerPlcaeHolderData.length && this.bannerPlcaeHolderData.find(bannerData =>
        bannerData.placeholder_for.toLowerCase() === 'Home Screen Page'.toLowerCase() && bannerData.status === true && bannerData.product_type.toLowerCase() === 'HEADER_APP_RATING_MWEB_IOS'.toLowerCase())
    },
    callerComp () {
      if (this.$route.path.includes('supima-landing')) {
        return 'supimaMenu'
      } else if (this.$route.path.includes('active-wear-landing')) {
        return 'activeWearMenu'
      } else if (this.$route.path.includes('winter-wear-landing')) {
        return 'winterWearMenu'
      }
    },
    showWomenWebMenu: function () {
      return this.isSelectedCountryIndia ? true : this.globalBannerPlaceholder && this.globalBannerPlaceholder.length && this.globalBannerPlaceholder.find(bannerData => bannerData.is_active === true && bannerData.config_key === 'SHOW_WEB_MENU_WOMEN')
    },
    showMenWebMenu: function () {
      return this.isSelectedCountryIndia ? true : this.globalBannerPlaceholder && this.globalBannerPlaceholder.length && this.globalBannerPlaceholder.find(bannerData => bannerData.is_active === true && bannerData.config_key === 'SHOW_WEB_MENU_MEN')
    },
    showKidsWebMenu: function () {
      return this.isSelectedCountryIndia ? true : this.globalBannerPlaceholder && this.globalBannerPlaceholder.length && this.globalBannerPlaceholder.find(bannerData => bannerData.is_active === true && bannerData.config_key === 'SHOW_WEB_MENU_KIDS')
    }
  },
  watch: {
    value () {
      if (this.value.length > 2) {
        this.trigger = true
      }
    },
    isShowAppRatingOnMwebIos () {
      this.getDeviceRating()
    },
    isShowAppRatingOnMweb () {
      this.getDeviceRating()
    },
    $route () {
      setTimeout(function () {
        $('.navbar-collapse').removeClass('activenav')
        // document.getElementsByClassName('navbar-collapse').classList.remove('activenav')
      }, 300)
      if (this.$route.path === '/autocomplete') {
        this.showHeader = false
      } else {
        this.showHeader = true
      }
      if (this.$route.name !== 'search') {
        this.value = ''
        this.togglesearch = false
      }
      this.togglesearch = false
    },
    activeGenderType () {
      this.$store.commit('WEBCATEGORY', this.activeGenderType)
      Vue.ls.set('tss_landingCategory', this.activeGenderType)
    },
    hasAddressChanged: {
      handler: function () {
        Vue.ls.set('listing_meta_info', null)
        this.$set(this.$parent, 'loading', true)
        this.$store.dispatch('GET_HOME_SCREEN_DATA', {isComboActive: this.isComboActive})
        this.$store.dispatch('GET_NAVMENU_DATA')
        const countryId = this.$store.state.selectedCountryAddress.countryId
        const configKeys = this.getGlobalSettingKeys
        this.$store.dispatch('GLOBAL_GET_BANNERS_DATA', { countryId, configKeys })
        this.$store.dispatch('CART_DATA')
        this.$store.dispatch('WISHLIST_DATA')
      },
      deep: true
    }
  }
}
</script>

<style lang="css" scoped>
button.navbar-toggler.navbar-toggler-left.mobilenav:focus,
button.navbar-toggler.navbar-toggler-left.mobilenav:focus-visible{
    outline:none;
}
.moblle_nav98{display:flex; margin: 0 0 5px; padding: 0; border-bottom: 1px solid #eee;}
.moblle_nav98 li{width:50%; list-style: none;}
.moblle_nav98 li a{padding: 8px 0; text-align: center; display: block; width:100%}
.moblle_nav98 li.activeCat a{border-bottom: #ed2d2f 2px solid;}
.moblle_nav98 li:first-child a{border-right:1px solid #eee}
.menu-title {
  color: #117a7a;
  padding: 0px 20px;
}

.blinking {
  animation: blinkingText 1s infinite;
}
@keyframes blinkingText {
  20% {
    color: #9e0305;
  }
  49% {
    color: transparent;
  }
  70% {
    color: transparent;
  }
  100% {
    color: #ed2d2f;
  }
}

.nav-item:hover {
  background: #ffffff;
}

.mbnav a {
  display: block;
  color: #282d3f;
  padding: 3px 15px;
  font-size: 15px;
  line-height: 22px;
}

.submenucontainer .submenu {
  margin: 0;
}
.star-section {
  width: 70px;
  position: relative;
}
.rating-label{
  margin-top: 5px;
  margin-right: 5px;
}
.star-blank {
  opacity: 0.5;
}
.star-fill {
  position: absolute;
  left: 0;
  top: 0;
  overflow: hidden;
}
.star-fill img {
  max-width: 70px;
}
.home-gender-wrapper {
    padding: 0;
    left: 0;
    right: 0;
    appearance: none !important;
    height: 50px;
    margin: 0px
  }
  .home-gender-wrapper .tab-btn{
    align-items: center;
    background: transparent;
    border: unset;
    font-size: 0.9rem;
    height: 50%;
    width: 100%;
    text-transform: uppercase;
    -webkit-appearance: none;
    appearance: none;
    border-right: 1px solid #cbc6c6;
    display: flex;
    justify-content: center;
    color: #0a0a0a;
}
.comboMenu {
    align-items: center;
    justify-content: center;
    display: flex;
    float: left;
    padding: 0px !important;
}
.fixed-top .home-gender-wrapper {
  margin: 5px 0 !important;
}
.home-active-tab-class{
  border-bottom: 4px solid #187b7b;
}
.tab-btn:active{
  outline: none
}
.tab-btn:focus{
  outline: none
}
.tab-btn{
  font-size: 16px !important;
}
.submenucontainer .submenu li {
  display: block;
}
.section-border-separator {
  margin-top: 10px;
  border-top: 1px solid #eee;
  padding-top: 10px !important;
}
.section-border-separator-heavy {
  margin-top: 10px;
  border-top: 6px solid #eee;
  padding-top: 10px !important;
}

.submenucontainer .submenu li a {
  padding: 3px 0;
  color: #282d3f;
  font-size: 15px;
}

.navopen .sublevel2 {
  width: 100%;
}
.seperator {
  border-right: 1px solid #FFF;
  height: 70%;
}
.trackmap li.active:after {
}

.navbar-nav .nav-link {
  position: relative;
}

.sbx-google__input-placeholder {
  background: transparent;
}

.authbtn {
  cursor: pointer;
}

.authbtn {
  display: inline-block;
}

.headerRight > div {
  display: flex;
  justify-content: center;
  align-items: center;
}
.mobile-menu-order-section li {
  padding:4px 0;
}
.mobile-menu-more-info-section .contact-us{
  padding:4px 0;
}
.mobile-menu-more-info-section .faqs{
  padding:4px 0;
}
.fcapital {
  text-transform: capitalize;
}

.navbar {
  box-shadow: 0px 2px 3px rgba(0, 0, 0, 0.2);
  position: relative;
  z-index: 999;
}
.supima-menu .navbar {
  background-color: #e11b23;
  color: #fff
}
.activewear-menu .navbar {
  background-color: #000000;
  color: #fff;
  border-bottom: 4px solid #e93432
}

.navbar.fixed-top {
  position: fixed;
}

.header-background {
  background-color: #f8f8f8;
  margin: 0px !important;
  height: 120px;
}
.exclusive-header {
  background-color: #282d3f;
}


.navbar.fixed-top .navbar-brand,
.navbar.global-nav .navbar-brand {
  width: 70px;
  height: 45px;
  bottom: 5px;
}
.supima-home-logo {
  left: 30%;
}
.activewear-menu .supima-home-logo {
  left: 37%
}
.supima-home-logo img {
  height: 30px;
}
.activewear-menu .supima-home-logo img {
  height: 24px;
}
.topbar {
  background: #E12D2D;
  padding: 3px 0;
  min-height: 53px
}

.topbar a,
.topbar span {
  color: #fff;
  font-size: 13px;
}

.topbar a:hover {
  color: #fff;
}

.navMenu {
  margin-left: 230px;
}

.navicon .noTdropdown {
  padding: 14px 0 13px 0px !important;
}

.navicon a .dropdown-menu {
  padding: 15px !important;
}

.navicon .dropdown-menu a {
  font-size: 15px !important;
}

.dropdown-menu.right {
  right: 0;
  left: inherit;
}

.dropdown-item.active,
.dropdown-item:active,
.dropdown-item:focus,
.dropdown-item:hover {
  background-color: transparent;
}

.left-arrow-style {
  top: 8px;
  width: 22px;
  height: auto;
}

.count {
  top: -1px;
  right: -6px;
  font-size: 10px;
  width: 16px;
  height: 16px;
}
@media screen and (min-width: 992px) {
    .navbar-brand:not(.slidem):before {
      content: '';
      display: block;
      width: 23px;
      height: 16px;
      background: url('assets/images/eyes.png') no-repeat right;
      position: absolute;
      background-size: 100% auto;
      top: 25px;
      left: 17px;
    }
    .exclusive .navbar.fixed-top .navbar-brand::before,
    .exclusive .navbar.global-nav .navbar-brand::before {
          left: 18px !important;
          margin-top: -7px;
          width: 15px !important;
    }
    .navbar.fixed-top .navbar-brand::before,
    .navbar.global-nav .navbar-brand::before {
          left: 8px !important;
          margin-top: -16px;
          width: 15px !important;
    }
    
  }
@media screen and (max-width: 1200px) {
  .sidebar-home-img {
    width: 70px;
  }
  .submenucontainer h5,
  .submenucontainer .defaultColor {
    font-family: inherit;
    color: #282d3f;
    padding: 10px 0px;
    font-size: 15px;
  }

  .submenucontainer .navopen h5 {
    font-family: 'Source Sans Pro', sans-serif;
font-weight: 600;
  }

  .submenucontainer
    .submenu
    li
    a.router-link-exact-active.router-link-active:not(.headercart) {
    color: #282d3f;
    font-family: 'Source Sans Pro', sans-serif;
font-weight: 600;
  }

  .navbar-collapse.activenav ul.navbar-nav li {
    border-bottom: none;
  }

  .user-order-section {
    margin-top: 20px;
    border-top: 1px solid #eee;
    padding-top: 20px !important;
    padding-bottom: 20px !important;
    border-bottom: 1px solid #eee;
  }

  .navbar-toggleable-md .navbar-nav .nav-link {
    color: #282d3f;
    padding-right: 0.8rem;
    padding-left: 0.8rem;
    font-size: 14px;
    margin-right: 0px;
  }

  .nav-item.non-exc-mem a,
  .nav-item.exc-mem a {
    color: #e66a51 !important;
    font-family: inherit !important;
  }

  .nav-item.track-my-order a {
    color: #148c8d !important;
  }

  .nav-item.my-account a,
  .nav-item.savetheirsouls a,
  .nav-item.my-orders a,
  .nav-item.faqs a,
  .nav-item.track-my-order a,
  .nav-item.contact-us a,
  .nav-item.tnc a {
    font-family: inherit !important;
  }

  .mobilesearch {
    width: 300px;
    margin-right: 8em;
  }
  .dropdown-toggle[aria-expanded='false']:before {
    top: 5px;
  }
}

.notifylogin {
  position: fixed;
  top: 40px;
  background: #ed2d2f;
  width: 240px;
  padding: 10px;
  z-index: 999;
  right: 0px;
  visibility: hidden;
  opacity: 0;
  transition: all 1s ease-out;
  color: #fff;
  box-shadow: 0 0 3px rgba(0, 0, 0, 0.5);
}

.notifylogin.active {
  visibility: visible;
  opacity: 1;
  top: 70px;
  transition: all 0.5s ease-in;
}

.locked-tag {
  color: #58595b;
  padding: 3px 0;
}

@media screen and (max-width: 992px) {
  .col.comboMenu:last-child .tab-btn {
    border-right: none;
  }
  .notifylogin.active {
  }

.comboMenu:active {
    background-color: #d8dadc;
    background-size: contain;
}

  .navbar-brand:before {
    top: 28px;
    left: 11px;
    width: 15px;
    height: 16px;
  }

  .dropdown-toggle[aria-expanded='true']:before {
    display: block;
    position: absolute;
    right: 15px;
    font: normal normal normal 14px/1.5 FontAwesome;
    font-size: 20px;
    top: 2px;
    color: #000;
    text-rendering: auto;
    -webkit-font-smoothing: antialiased;
    content: '\f106';
  }

  .router-link-exact-active.router-link-active:not(.headercart) {
    font-family: 'Source Sans Pro', sans-serif !important;
font-weight: 600;
  }

  .dropdown-item.citem {
    font-size: 15px;
    padding: 0px 30px;
    line-height: 28px;
  }

  .navbar-nav {
    padding-bottom: 80px;
  }
  .navbar-mt {
    top: 0px;
  }

  .navbar-collapse.activenav {
    box-shadow: 5px 0 8px rgba(0, 0, 0, 0.2);
  }
  
  .navbar-collapse + .overlay.show {
    display: none !important;
  }
  .navbar-collapse.activenav + .overlay.show {
    display: block !important;
  }
  .navbar.fixed-top .navbar-collapse,
  .navbar.global-nav .navbar-collapse {
    top: 0;
  }

  .navbar {
    height: 42px;
  }

  .navMenu {
    margin-left: 0px;
  }

  .navbar-brand {
    width: 80px;
    margin-left: auto;
    margin-right: auto;
    left: 50%;
    margin-left: -40px;
    top: -32px;
    -webkit-transition: unset;
  }

  .navbar-brand.slidemob {
    display: inline-block;
    position: inherit;
    width: 90px;
    margin-left: 0px;
    left: inherit;
    top: inherit;
    margin-right: auto;
    bottom: 0px;
    background: url('assets/images/newlogosticky.png') center center no-repeat;
    background-size: 75% !important;
  }

  .user-info {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    flex-direction: column;
  }
  .location-change-style {
    margin: 1px;
    align-self: start;
  }
  .guest-location-style{
    margin: 4px;
  }
  .user-info .name-arrow-wrapper {
    color: #282d3f;
  }
  .exclusive-header .user-info .name-arrow-wrapper {
    color:#ffffff;
  }
  .login-register {
    width: 122px;
    height: 31px;
    border-radius: 4px;
    border: solid 1px #148c8d;
    position: relative;
  }

  .login-register p {
    position: absolute;
    height: 18px;
    font-size: 13px;
    font-weight: normal;
    font-stretch: normal;
    font-style: normal;
    line-height: 1.38;
    letter-spacing: normal;
    text-align: center;
    color: #148c8d;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  }

  .user-info-slidemob .arrow:before {
    font: normal normal normal 16px/1 FontAwesome;
    content: '\F105';
    font-weight: bolder;
  }
  .user-info-slidemob .name-arrow-wrapper{
    gap: 0.9rem;
  }

  .user-info-slidemob .exclusive-info p {
    margin: 0px;
    padding: 0px;
    color: #e76a52;
    font-size: 11px;
  }
  .user-info-slidemob .exclusive-info hr {
    background-image: linear-gradient(to right, #e76a52, #282d3f);
    margin: 3px 0px !important;
    height: 1px;
  }

  .navbar.fixed-top .navbar-brand,
  .navbar.global-nav .navbar-brand {
    position: static;
    height: auto;
    bottom: 0;
    margin-left: 40%;
  }

  .headerRight {
    top: 9px;
  }
  .supima-menu .headerRight a, .activewear-menu .headerRight a {
    color: #fff
  }

  .mobilesearch {
    width: 100%;
  }

  #togglesearch {
    display: inline-block;
    text-decoration: none;
  }
  .navbar-collapse {
    border-right: none;
  }

  .mobilesearch {
    position: absolute;
    width: 100%;
    border-radius: 0;
    top: 40px;
    z-index: 9;
    left: 0;

    transition: all 0.3s ease-in;
  }

  .mobilesearch input:focus {
    outline: none;
  }

  .mobilesearch.active {
    visibility: visible;
    opacity: 1;
    transition: all 0.3s ease-out;
  }

  .mobilesearch.active:before {
    content: '';
    width: 0;
    height: 0;
    border-left: 8px solid transparent;
    border-right: 8px solid transparent;
    border-bottom: 8px solid #58595b;
    position: absolute;
    top: -7px;
    right: 55px;
  }

  .searchinput {
    height: 100%;
    width: 85%;
    border: 0;
  }

  .mobilesearch .searchinput {
    padding: 10px;
  }

  .mbinput {
    width: 100%;
    background: #fff;
    box-shadow: 0px 0 5px #a7a9ac;
    padding: 0.3rem 0.5rem 0.3rem 0.2rem;
  }

  .navbar-toggleable-md .navbar-nav .nav-link {
    margin-left: 0;
  }
  .navbar-toggleable-md .navbar-nav .nav-link[aria-expanded='true'] {
    color: #282d3f !important;
  }
  .supima-menu .menu-hamburger, .activewear-menu .menu-hamburger {
    vertical-align: middle;
  }
  .supima-menu .menu-hamburger img, .activewear-menu .menu-hamburger img {
    height: 27px;
  }
  .navbar-light .navbar-nav .nav-link:hover,
  .dropdown.active,
  .navbar-light .navbar-nav .open > .nav-link,
  .navbar-light .navbar-nav .active > .nav-link,
  .navbar-light .navbar-nav .nav-link.open,
  .navbar-light .navbar-nav .nav-link.active {
    background-color: #ffffff;
    color: #282d3f;
    box-shadow: none;
  }
}

.roseAreRed {
  color: #ff0000 !important;
}

.overlay {
  background-color: #000;
  opacity: 0.7;
  width: 100%;
  z-index: 98;
  height: 100vh;
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  display: none;
}

.overlay.show {
  display: block;
}
 /* Header */

  
  .exclusive .navbar-brand {
    background: url('./assets/images/membership-logo.png') center center no-repeat;
    background-size: contain;
  }

  .birthday-logo .navbar-brand {
    background: url('https://prod-img.thesouledstore.com/public/theSoul/images/Welcome-100-app.png') center center no-repeat;
    background-size: contain;
  }

  .exclusive .navbar.fixed-top .navbar-brand,
  .exclusive .navbar.global-nav .navbar-brand {
    background: url('./assets/images/membership-logo.png') center center no-repeat;
    background-size: contain;
  }

  .birthday-logo .navbar.fixed-top .navbar-brand,
  .birthday-logo .navbar.global-nav .navbar-brand {
    background: url('https://prod-img.thesouledstore.com/public/theSoul/images/Welcome-100-app.png') center center no-repeat;
    background-size: contain;
  }
  .exclusive-congrats-msg {
    color: #e76a52;
    font-size: 40px;
    font-weight: bold;
    padding: 100px 0px;
  }
  .exclusive .navbar-brand:before {
    filter: brightness(0%);
    -webkit-filter: brightness(0%);
  }

.exclusive .navbar.fixed-top .navbar-brand,
.exclusive .navbar.global-nav .navbar-brand {
    width: 52px;
    position: absolute;
    left:0;
    top: -10px;
  }

  .exclusive .navbar.fixed-top .navbar-brand:not(.slidem):before,
  .exclusive .navbar.global-nav .navbar-brand:not(.slidem):before {
    width: 9px !important;
    height: 24px;
    left: 7px;
    top: 18px;
    margin-top: -6px;
  }
  .exclusive .supima-menu .navbar .navbar-brand {
    width: 52px;
    height: 62px;
    top: -10px;
  }
  .exclusive .supima-menu .fixed-top  .navbar-brand,
  .exclusive .supima-menu .global-nav  .navbar-brand {
    width: 50px;
    top: -12px;
  }
  .exclusive .supima-menu .navbar .navbar-brand:not(.slidem)::before {
    width: 9px !important;
    height: 24px;
    left: 7px;
    top: 18px;
    margin-top: -6px;
  }

  .navbar.fixed-top .navbar-brand,
  .navbar.global-nav .navbar-brand {
    height: 62px;
    width: 60px;
    bottom: 1px;
    position: absolute;
    left:0;
    top: -10px;
  }

  .navbar.fixed-top .navbar-brand:not(.slidem):before,
  .navbar.global-nav .navbar-brand:not(.slidem):before {
    width: 11px;
    background-size: 83% auto;
    height: 24px;
    left: 8px;
    top: 24px;
    margin-top: -8px;
  }

  

  .exclusive .navbar-brand:not(.slidem):before {
    width: 15px;
    background-size: 83% auto;
    height: 24px;
    left: 12px;
    top: 18px;
  }

  .exclusive .search input#search {
    padding-left: 50px;
  }
  .gender-wrapper {
    background: #ebebeb;
    border-radius: 0.3rem;
    margin-bottom: 10px;
    box-shadow: 0 3px 10px 0 rgb(0 0 0 / 19%) !important;
    height: 2rem !important;
  }
  .gender-wrapper .col {
    padding-left: 0 !important;
    padding-right: 0 !important;
  }
  .gender-wrapper .tab-btn{
  background: transparent;
  border: unset;
  font-size: 1rem;
  height: 100%;
  width: 100%;
  border-radius: 0.5rem;
  color: #828282;
  font-weight: 600;
  -webkit-text-stroke: 0.35px #ffffff;
  -webkit-font-smoothing: antialiased;
  appearance: none;
}
.tab-btn:active{
  outline: none
}
.tab-btn:focus{
  outline: none
}
.active-tab-class{
  background-color: #fff !important;
  font-weight: 600;
  color: #0a0a0a !important;
}
.newSubMenu {
  background: #f6f6f6;
  border-radius: 0.2rem;
  border: 1px solid #cacaca;
}
/* Hide scrollbar for Chrome, Safari and Opera */
#navbarNavDropdown::-webkit-scrollbar {
    display: none;
}
/* Hide scrollbar for IE, Edge and Firefox */
#navbarNavDropdown {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}
.seperatorGender {
  border-top: 0.3rem #eee solid;
}
.newSubMenu {
  margin-left: 2px;
}
.circle {
  display: inline-block;
  border-radius: 50%;
  min-width: 30px;
  min-height: 30px;
  padding: 5px;
  background: #b9b9b9bb;
  color: white;
  text-align: center;
  line-height: 1;
  box-sizing: content-box;
  white-space: nowrap;
}
.circle:before {
  content: "";
  display: inline-block;
  vertical-align: middle;
  padding-top: 100%;
  height: 0;
}
.circle span {
  display: inline-block;
  vertical-align: middle;
}
.image-cropper {
  border-radius: 50%;
  height: 45px;
  width: 45px;
}
.font-SourceSansPro-Bold {
  font-weight: 600 !important;
}
.font-SourceSansPro-Regular {
  font-weight: normal !important;
}
.font-SourceSansPro-SemiBold {
  -webkit-text-stroke: 0.35px #ffffff;
  -webkit-font-smoothing: antialiased;
}
.font-OswaldDemiBoldItalic {
  -webkit-font-smoothing: antialiased;
  font-family: 'Oswald Demi Bold Italic' !important;
}
.font-OswaldDemiBoldItalic-Large {
  -webkit-font-smoothing: antialiased;
  font-family: 'Oswald Demi Bold Italic' !important;
  font-size: 1.4rem !important;
}
@media screen and (max-width: 768px) {  
 .count {
   top: -2px;
   right: 1px;
 }
}
@media screen and (max-width: 415px) {
  .submenucontainer h5,
  .submenucontainer .defaultColor {
    font-family: inherit;
    color: #282d3f;
    font-size: 15px;
  }
  .submenucontainer .submenu li a {
    font-size: 13px;
  }
  .mbnav a {
    font-size: 15px;
  }
}
@media screen and (max-width: 320px) {
  .image-cropper {
    border-radius: 50%;
    height: 36px;
    width: 40px;
  }
  .circle {
  display: inline-block;
  border-radius: 50%;
  min-width: 20px;
  min-height: 20px;
  padding: 5px;
  background: #b9b9b9bb;
  color: white;
  text-align: center;
  line-height: 1;
  box-sizing: content-box;
  white-space: nowrap;
}
}
.location-modal-mob {
  background: #E12D2D;
  color: #fff;
  padding: 8px 20px;
}
</style>
<style>
@media screen and (max-width: 991px) {
  .exclusive .exclusive-topbar {
    background: #3E3F45;
  }
  .exclusive .exclusive-topbar .col-md-12 span span {
    background: -webkit-linear-gradient(#E1E3F6, #ECE7F6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
  .exclusive .exclusive-topbar .close span {
    color: #fff;
  }
  .exclusive .topbar {
    background: #000;
    border-bottom: 3px solid #ED2D2F;
  }
  .exclusive .navbar {
    box-shadow: none !important;
  }
  .exclusive .home-gender-wrapper {
    background: #000;
  }
  .exclusive .home-gender-wrapper button.tab-btn {
    color: #fff;
    font-weight: bold;
    border-right: none;
  }
  .exclusive .home-gender-wrapper .comboMenu {
    border-left: 1px solid #f5eafd;
  }
  .exclusive .home-gender-wrapper .comboMenu:first-child {
    border-left: none;
  }
  .exclusive .home-gender-wrapper .home-active-tab-class {
    border-bottom: none;
  }
  .exclusive .home-gender-wrapper .home-active-tab-class button.tab-btn {
    color: #000;
  }
  .exclusive .home-active-tab-class {
    background: url('./assets/images/menu-link-bg.png');
    background-size: cover;
    color: #000;
  }
  .exclusive .headerRight .hicon {
    padding: 0 7px;
  }
  .exclusive .headerRight > div > span {
    margin-right: 6px;
  }
  .exclusive .navbar-light .navbar-toggler-icon {
    background: url('./assets/images/mship-toggle.svg') no-repeat;
    margin-top: 6px;
  }
  .exclusive .headerRight .hicon .count {
    top: -5px !important;
    right: 0px;
  }
  .exclusive .exmembership-wrapper {
    border-top: 1px solid #ccc; 
  }
}
</style>
