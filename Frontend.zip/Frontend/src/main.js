import Vue from 'vue'
import babelPolyfill from 'babel-polyfill'
import App from './App'
import VueHead from 'vue-head'
import router from './router'
import VueCarousel from 'vue-carousel'
import VuejsDialog from 'vuejs-dialog'
import VueAxios from 'vue-axios'
import axios from 'axios'
import SimpleVueValidation from 'simple-vue-validator'
import store from './store'
import Vuex from 'vuex'
import Storage from 'vue-ls'
import Toasted from 'vue-toasted'
import LazyLoadDirective from '@/assets/js/imgLazyLoadObserver'
import LazyLoadBannerImpressionDirective from '@/assets/js/bannerImpressionTrack'
import ResizeObserver from 'resize-observer-polyfill'
Vue.use(Toasted)
var options = {
  namespace: 'tss-v2__',
  name: 'ls',
  storage: 'local'
}
// custom directive for lazyload of viewport only images
Vue.directive('lazyloadImage', LazyLoadDirective)

// custom directive for lazyload & measure banner impression on view images
Vue.directive('bannerImageLoad', LazyLoadBannerImpressionDirective)

// custom directive for first content paint of image
Vue.directive('imageBackground', {
  inserted (el, binding, vnode) {
    if (binding.value && binding.value.length && el && el.parentElement && !el.parentElement.style.height) {
      let resolution = binding.value && binding.value.split(':')
      const ratio = resolution[0] / resolution[1]
      let renderWidth = el.parentElement.getBoundingClientRect().width
      if (renderWidth) {
        let renderHeight = parseInt(renderWidth / ratio)
        el.parentElement.style.height = renderHeight + 'px'
        el.parentElement.style.background = '#FFEBE7'
      }
    }
  },
  componentUpdated (el, binding, vnode) {
    if (binding.value && binding.value.length && el && el.parentElement && !el.parentElement.style.height) {
      let resolution = binding.value && binding.value.split(':')
      const ratio = resolution[0] / resolution[1]
      let renderWidth = el.parentElement.getBoundingClientRect().width
      if (renderWidth) {
        let renderHeight = parseInt(renderWidth / ratio)
        el.parentElement.style.height = renderHeight + 'px'
        el.parentElement.style.background = '#FFEBE7'
      }
    }
  }
})

// custom directive to detect outside click of an element
Vue.directive('click-outside', {
  bind (el, binding, vnode) {
    el.clickOutsideEvent = (event) => {
      if (!(el === event.target || el.contains(event.target))) {
        vnode.context[binding.expression](event)
      }
    }
    document.body.addEventListener('click', el.clickOutsideEvent)
  },
  unbind (el) {
    document.body.removeEventListener('click', el.clickOutsideEvent)
  }
})

Vue.directive('dynamicMinHeight', {
  inserted (el) {
    let timeoutId = null
    const observer = new ResizeObserver(entries => {
      clearTimeout(timeoutId)
      timeoutId = setTimeout(() => {
        for (let entry of entries) {
          if (entry.target === el) {
            el.style.minHeight = `${entry.contentRect.height}px`
          }
        }
      }, 100)
    })
    observer.observe(el)
    if (router.currentRoute.path === '/') {
      el.style.minHeight = '0px'
    }
    // Vue Router navigation guard
    const unbindRouteChange = router.beforeEach((to, from, next) => {
      setTimeout(() => {
        observer.disconnect()
        el.style.minHeight = '0px'
        observer.observe(el)
      }, 0)
      next()
    })
    el._unbindRouteChange = unbindRouteChange
  },
  unbind (el) {
    // Clean up the navigation guard when the directive is unbound
    if (el._unbindRouteChange) {
      el._unbindRouteChange()
      delete el._unbindRouteChange
    }
  }
})

Vue.config.productionTip = false
Vue.config.ignoredElements = [
  'fw-storyblock',
  'fw-embed-feed'
]
Vue.prototype.$http = axios
Vue.prototype.$hostname = process.env.V1_HOST
Vue.use(babelPolyfill)
Vue.use(VueHead, {
  separator: ''
})
Vue.use(VueCarousel)
Vue.use(VuejsDialog)
Vue.use(Storage, options)
import 'es6-promise/auto'
/* eslint-disable no-new */

Vue.use(VueAxios, axios)
Vue.use(SimpleVueValidation, {mode: 'conservative'})
Vue.use(Vuex)

// Generate random mac address
if (!Vue.ls.get('tss_mac_token')) {
  var navigatorInfo = window.navigator
  var screenInfo = window.screen
  var uid = navigatorInfo.mimeTypes.length
  uid += navigatorInfo.userAgent.replace(/\D+/g, '')
  uid += navigatorInfo.plugins.length
  uid += screenInfo.height || ''
  uid += screenInfo.width || ''
  uid += screenInfo.pixelDepth || ''
  var mactoken = uid + new Date().getTime() + Math.random().toString()
  Vue.ls.set('tss_mac_token', mactoken)
}

new Vue({
  el: '#app',
  router,
  template: '<App/>',
  store,
  components: {App}
})
