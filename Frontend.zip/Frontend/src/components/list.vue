<template>
  <section class="section" id="kids">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section-heading-custom">
                        <h2>OUR PARTNER</h2>
                    </div>
                </div>
                <section class="">
                    <div class="container">
                        <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-start">
                            <div v-for="(store,index) in listData" :key="index" class="col mb-5">
                                <div class="card h-100">
                                    <!-- Product image-->
                                    <img class="card-img-top" :src="store.thumbnail_image" alt="...">
                                    <!-- Product details-->
                                    <div class="card-body" style="padding:5px;">
                                        <div class="d-flex justify-content-between align-items-left text-left">
                                            <h5 class="card-title mb-0 card-title-heading">{{store.store_name}}</h5>
                                            <!-- <a href="#" @click="wardList()" class="view-more">View More &gt;</a> -->

                                            <router-link style="color: #68a522;font-size: 10px;font-family: initial;" :to="'/ward-list/' + store.store_id">View More &gt;</router-link>
                                        </div>

                                        <div class="text-left view-more-desc">
                                            {{store.platform}}
                                        </div>
                                    </div>
                                    <!-- Product actions-->
                                    <!-- <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                        <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="#">View options</a></div>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
</template>
<script>
  export default {
    name: 'app',
    mixins: [],
    components: {},
    props: {
      listData: Array,
      type: String
    },
    data () {
      return {}
    },
    created: function () {},
    mounted: function () {},
    updated: function () {},
    watch: {},
    computed: {},
    methods: {},
    beforeDestroy () {}
  }
</script>
<style scoped>
#kids{
    padding-top:20px !important;
    padding-bottom:20px !important;
}
#kids .section-heading-custom {
    margin-bottom:25px !important;
}
.section-heading-custom h2 {
    font-size: 18px !important;
    font-weight: 600 !important;
    color: #898383 !important;
    font-family: sans-serif;
    
}
.view-more{
    font-size:9px;
    color:#5fd420;
}
.view-more-desc{
    font-size:10px;
    color:#7e7676;
}
.card-title-heading {
    font-size: 13px;
    font-family: cursive;
}
</style>

