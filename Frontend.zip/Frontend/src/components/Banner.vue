<template>
  <div class="bg-dark header-image" id="top">
        <div class="container px-4 px-lg-7">
            <!-- <div class="text-center text-white">
                <h1 class="display-6 fw-bold">Style Your SOUL</h1>
                <p class="lead fw-normal text-white-50 mb-0">Navigate Your Past Buys and Styles!</p>
                
            </div> -->
            <div id="login">
                <div class="container">
                    <div id="login-row" class="row justify-content-center align-items-center">
                        <div id="login-column" class="col-md-4">
                            <div id="login-box" class="col-md-12">
                                <form id="login-form" class="form" method="POST" v-on:submit.prevent="login">
                                    <h3 class="text-center text-info">Login</h3>
                                    <div class="form-group">
                                        <label for="username" class="text-info">Email Id:</label><br>
                                        <input type="text" v-model="emailid" name="username" id="username" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="password" class="text-info">Password:</label><br>
                                        <input type="password" v-model="password" name="password" id="password" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <!-- <label for="remember-me" class="text-info"><span>Remember me</span> <span><input id="remember-me" name="remember-me" type="checkbox"></span></label><br> -->
                                        <input type="submit" name="submit" class="btn btn-info btn-md" value="Login">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
  // import {mapState, mapGetters} from 'vuex'
  export default {
    name: 'app',
    mixins: [],
    components: {},
    data () {
      return {
        emailid: '',
        password: ''
      }
    },
    created: function () {},
    mounted: function () {},
    updated: function () {},
    watch: {},
    computed: {},
    methods: {
      login () {
        this.$store.dispatch('LOGIN_USER', {otp: '1234', email: this.emailid, password: this.password}).then(res => {
          this.$router.push('/')
        })
      }
    },
    beforeDestroy () {}
  }
</script>
<style scoped>
.header-image {
    background-image: url('../../assets/images/background-image.jpeg'); /* Replace with your image path */
    background-size: cover; /* Makes the background cover the entire header */
    background-position: center; /* Centers the background image */
    background-repeat: no-repeat; /* Prevents the image from repeating */
    color: white; /* Ensures text color is readable over the background */
    width: 100%;
    height: 550px;
}
.header-image-container {
    margin-top:150px;
}

body {
  margin: 0;
  padding: 0;
  background-color: #17a2b8;
  height: 100vh;
}
#login .container #login-row #login-column #login-box {
  margin-top: 120px;
  max-width: 600px;
  height: 320px;
  border: 1px solid #9C9C9C;
  background-color: #ffffff;
}
#login .container #login-row #login-column #login-box #login-form {
  padding: 20px;
}
#login .container #login-row #login-column #login-box #login-form #register-link {
  margin-top: -85px;
}

</style>
