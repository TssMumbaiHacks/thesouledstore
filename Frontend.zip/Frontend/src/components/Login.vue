<template>
  <div id="app">
    <header class="header-area header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <span>This is login api</span>
                </div>
            </div>
        </div>
    </header>
  </div>
</template>
<script>
  export default {
    name: 'app',
    mixins: [],
    components: {},
    data () {
      return {}
    },
    created: function () {},
    mounted: function () {},
    updated: function () {},
    watch: {},
    computed: {},
    methods: {},
    beforeDestroy () {}
  }
</script>
