<template>
  <div id="app">
    <header class="header-area header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                        <!-- ***** Logo Start ***** -->
                        <a href="#"  @click="redirectTo('home')" class="logo">
                            <img style="width:180px; height:70px;" src="../../assets/images/logo-closesthub.png">
                        </a>
                        <!-- ***** Logo End ***** -->

                        <!-- ***** Menu Start ***** -->
                        <ul class="nav">
                            <li class="scroll-to-section">
                                <a href="#" class="active" @click="redirectTo('home')">Home</a>
                            </li>
                            <li class="scroll-to-section" @click="redirectTo('srp')"><a href="#">Virtual Try</a></li>
                            <!-- <li class="scroll-to-section" @click="redirectTo('srp')"><a href="">Closest</a></li> -->
                            <li class="scroll-to-section" @click="redirectToLogin()"><a href="#">{{getLoginText}}</a></li>
                        </ul>
                        <a class='menu-trigger'>
                            <span>Menu</span>
                        </a>
                    </nav>
                </div>
            </div>
        </div>
    </header>
  </div>
</template>
<script>
  import Vue from 'vue'
  import {mapGetters} from 'vuex'
  export default {
    name: 'app',
    mixins: [],
    components: {},
    data () {
      return {}
    },
    created: function () {},
    mounted: function () {},
    updated: function () {},
    watch: {},
    computed: {
      ...mapGetters(['authStatus']),
      getLoginText () {
        console.log(Vue.ls.get('tss_token'), 'datadata')
        return Vue.ls.get('tss_token') ? 'Logout' : 'Login'
      }
    },
    methods: {
      redirectToLogin () {
        Vue.ls.get('tss_token') ? this.$store.dispatch('LOGOUT', {
          requiresAuth: false
        }) : this.$router.push('/login')
      },
      redirectTo (name) {
        if (name === 'home') {
          this.$router.push('/')
        } else if (name === 'srp') {
          this.$router.push('/srp')
        }
      }
    },
    beforeDestroy () {}
  }
</script>
