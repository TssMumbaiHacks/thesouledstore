<template>
  <transition name="fade">
    <div class="failute">
      <div class="container contentpages">
        <div class="row">
          <div class="col-md-12">
            <div class="sdata">
              <div class="mtb20 text-center">
                <img data-src="https://tss-static-images.gumlet.io/badrequest.png" alt="Something went wrong"/>
              </div>
              <br/>
              <h5 class="text-center lightfont" style="line-height:30px;">
                Something seems to have gone wrong. We've been notified about this error and we will be looking into it right away. <br/>
                <router-link to="/contact-us">Contact Us</router-link>
                if you want to share any specific information.
              </h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  </transition>
</template>


<script>

  export default {
    name: 'error',
    data () {
      return {
        staticImg: process.env.STATIC_IMG
      }
    }
  }
</script>
<style lang="css" scoped="">

</style>
<!-- Add "scoped" attribute to limit CSS to this component only -->
