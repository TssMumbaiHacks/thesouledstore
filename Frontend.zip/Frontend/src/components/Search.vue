<template>
    <div class="main-banner" id="top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <div class="left-content">
                        <div class="thumb">
                            <div class="inner-content">
                                <h4>Cross Partner Product Discovery</h4>
                                <span>Revolitionzing Store Product Search With Advanced LLM Models <br/><span></span></span>
                                <form class="form-group" role="search">
                                        <div class="row">
                                            <div class="col-8" style="padding-right:2px">
                                            <input type="text" class="form-control" v-model="search.text" placeholder="Search Your Query">
                                            </div>
                                            <div class="col-3" style="padding-left:0px">
                                                <select class="form-control" v-model="search.store">
                                                    <option value="1">TSS</option>
                                                    <option value="2">Snitch</option>
                                                    <option value="3">Powerlook</option>
                                                </select>
                                            </div>
                                        </div>
                                </form>
                                <!-- <div class="container mt-3 mr-3">
                                </div> -->
                            </div>
                            <img src="../assets/images/resized_image.jpeg" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="right-content">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="right-first-image">
                                    <div class="thumb">
                                        <div class="inner-content">
                                            <h4>Image Search</h4>
                                            <span>Search By Image Or Video</span>
                                        </div>
                                        <div class="hover-content">
                                            <div class="inner">
                                                <h4>Upload Image</h4>
                                                <p>Select your image that you want to try on virtually</p>
                                                <div class="main-border-button">
                                                    <div class="custom-file-upload">
                                                        <div class="file-upload-wrapper">
                                                            <button class="btn btn-custom">
                                                                <i class="bi bi-upload"></i> Upload File
                                                            </button>
                            <input type="file" class="file-upload-input">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <img src="../assets/images/baner-right-image-01.jpg">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="right-first-image">
                                    <div class="thumb">
                                        <div class="inner-content">
                                            <h4>Vibes Search</h4>
                                            <span>Upload Favorite Vibes Or Ambience</span>
                                        </div>
                                        <div class="hover-content">
                                            <div class="inner">
                                                <h4>Upload Vibe Image</h4>
                                                <p>Upload your vibe or ambience image and get a virtual appearance of outfits</p>
                                                <div class="main-border-button">
                                                    <div class="custom-file-upload">
                                                        <div class="file-upload-wrapper">
                                                            <button class="btn btn-custom">
                                                                <i class="bi bi-upload"></i> Upload File
                                                            </button>
                                                            <input type="file" class="file-upload-input"  id="formFileLg">
                                                        </div>
                                                    </div>
                                                    <!-- <div clas="upload-file">
                                                        <input class="form-control form-control-lg" id="formFileLg" type="file">
                                                    </div> -->
                                                </div>
                                            </div>
                                        </div>
                                        <img src="../assets/images/baner-right-image-01.jpg">
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="right-first-image">
                                    <div class="thumb">
                                        <div class="inner-content">
                                            <h4>Video Search</h4>
                                            <span>Upload Video</span>
                                        </div>
                                        <div class="hover-content">
                                            <div class="inner">
                                                <h4>Upload Video</h4>
                                                <p>Select your video that you want to try on virtually </p>
                                                <div class="main-border-button">
                                                    <div class="custom-file-upload">
                                                        <div class="file-upload-wrapper">
                                                            <button class="btn btn-custom">
                                                                <i class="bi bi-upload"></i> Upload File
                                                            </button>
                                                            <input type="file" class="file-upload-input" id="formFileLg">
                                                        </div>
                                                    </div>
                                                    <!-- <div clas="upload-file">
                                                        <input class="form-control form-control-lg" id="formFileLg" type="file">
                                                    </div> -->
                                                </div>
                                            </div>
                                        </div>
                                        <img src="../assets/images/baner-right-image-01.jpg">
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="right-first-image" style="border:1px solid #dcdada; border-radius:6px;" @click="searchData()">
                                    <div class="thumb">
                                        <div class="inner-content">
                                            <button class="btn btn-primary">
                                                <i class="fa fa-search"></i> Search
                                            </button>
                                        </div>
                                        <div class="hover-content">
                                            <div class="inner">
                                                <h4></h4>
                                                <p></p>
                                                <div class="main-border-button">
                                                    <div class="custom-file-upload">
                                                        <div class="file-upload-wrapper">
                                                            <button class="btn btn-custom">
                                                                <i class="fa fa-search"></i> Search
                                                            </button>
                                                            <input type="file" class="file-upload-input" id="formFileLg">
                                                        </div>
                                                    </div>
                                                    <!-- <div clas="upload-file">
                                                        <input class="form-control form-control-lg" id="formFileLg" type="file">
                                                    </div> -->
                                                </div>
                                            </div>
                                        </div>
                                        <img style="opacity:0" src="../assets/images/baner-right-image-01.jpg">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Main Banner Area End ***** -->
</template>
<script>
  import {mapGetters} from 'vuex'
  export default {
    name: 'app',
    mixins: [],
    components: {},
    data () {
      return {
        search: {
          text: '',
          store: '1',
          file: '',
          video: '',
          vibe: ''
        }
      }
    },
    created: function () {},
    mounted: function () {},
    updated: function () {},
    watch: {
      search_input: {
        handler: function (newVal) {
          this.search.text = newVal
        },
        deep: true
      }
    },
    computed: {
      ...mapGetters(['search_input'])
    },
    methods: {
      searchData () {
        let payload = {
          query: this.search.text,
          store_id: this.search.store
        }
        this.$store.dispatch('SEARCH_TEXT', payload).then(res => {
          this.$router.push('/srp')
        })
      }
    },
    beforeDestroy () {}
  }
</script>
<style scoped>
.upload-file{
    font-size: 13px;
    color: #fff;
    border: 1px solid #fff;
    padding: 12px 25px;
    display: inline-block;
    font-weight: 500;
    transition: all .3s;
}
.custom-file-upload {
    position: relative;
}

.file-upload-wrapper {
    position: relative;
}

.file-upload-input {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
    cursor: pointer;
}

.btn {
    display: inline-flex;
    align-items: center;
}

.btn i {
    margin-right: 8px;
}
.btn-custom {
    background-color: white;
    color: black;
    border: 1px solid black; /* Optional: Add a border if desired */
}

.btn-custom:hover {
    background-color: #f8f9fa; /* Optional: Slightly darker shade for hover */
    color: black;
    border-color: black;
}
</style>
