<template>
  <transition name="fade">
    <router-link to="/"><img data-src="'https://tss-static-images.gumlet.io/404-page_2.jpg'" alt="404 Not Found"/></router-link>
  </transition>
</template>


<script>

  export default {
    name: 'error',
    data () {
      return {
        staticImg: process.env.STATIC_IMG
      }
    }
  }
</script>
<style lang="css" scoped="">

</style>
<!-- Add "scoped" attribute to limit CSS to this component only -->
