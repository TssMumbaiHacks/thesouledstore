<template>
  <section class="section" id="kids">
        <div class="container" v-if="listData.length > 0">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-heading-custom">
                        <h2>OUR PARTNER</h2>
                        <span class="summary-text">{{summary}}</span>
                    </div>
                </div>
                <section class="">
                    <div class="container">
                        <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-start">
                            <div v-for="(product,index) in listData" :key="index" class="col mb-5">
                                <div class="card h-100">
                                    <!-- Product image-->
                                    <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Virtual Try</div>
                                    <img class="card-img-top" :src="product.images[0]" alt="...">
                                    <!-- Product details-->
                                    <div class="card-body" style="padding:5px;">
                                        <div class="d-flex justify-content-between align-items-left text-left">
                                            <h5 class="card-title mb-0 card-title-heading">{{product.product_name}}</h5>
                                            <router-link style="color: #68a522;font-size: 10px;font-family: initial;" to="/virtual/1">View More. &gt;</router-link>
                                        </div>

                                        <div class="text-left view-more-desc">
                                            <span class="fw-bold" style="font-weight:800">₹</span> {{product.price}}
                                        </div>
                                    </div>
                                    <!-- Product actions-->
                                    <!-- <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                        <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="#">View options</a></div>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default {
    name: 'ProductList',
    mixins: [],
    components: {},
    props: {
      listData: Array,
      type: String,
      summary: String
    },
    data () {
      return {}
    },
    created: function () {},
    mounted: function () {},
    updated: function () {},
    watch: {},
    computed: {
      ...mapGetters(['search_products', 'search_type', 'search_sumarry', 'search_input'])
    },
    methods: {},
    beforeDestroy () {}
  }
</script>
<style scoped>
#kids{
    padding-top:20px !important;
    padding-bottom:20px !important;
}
#kids .section-heading-custom {
    margin-bottom:25px !important;
}
.section-heading-custom h2 {
    font-size: 18px !important;
    font-weight: 600 !important;
    color: #898383 !important;
    font-family: sans-serif;
    
}
.view-more{
    font-size:9px;
    color:#5fd420;
}
.view-more-desc{
    margin-top:4px;
    font-size:10px;
    color:#7e7676;
}
.card-title-heading {
    font-size: 13px;
    font-family: cursive;
}
.summary-text{
   font-size: 10px;
    font-family: initial;
    margin-bottom: 0;
}
.badge {
 background-color: #74baa9 !important;
}
</style>

