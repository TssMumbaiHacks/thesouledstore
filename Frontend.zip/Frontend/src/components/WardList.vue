<template>
  <section class="section" id="kids">
        <div class="container" v-if="ward_list.length > 0">
            <div class="row">
                <div class="col-lg-12" style="margin-top:100px;">
                    <div class="section-heading-custom">
                        <h2>Closet List</h2>
                        <span class="summary-text">{{summary}}</span>
                    </div>
                </div>
                <section class="">

                    <div class="container">
                        <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-start">
                            <div v-for="(product,index) in ward_list" :key="index" class="col mb-5">
                                <div class="card h-100">
                                    <!-- Product image-->
                                    <div class="badge bg-dark text-white position-absolute" style="top: 0.5rem; right: 0.5rem">Virtual Try</div>
                                    <img class="card-img-top" :src="product.image_url" alt="...">
                                    <!-- Product details-->
                                    <div class="card-body" style="padding:5px;">
                                        <div class="d-flex justify-content-between align-items-left text-left">
                                            <h5 class="card-title mb-0 card-title-heading">{{product.display_name}}</h5>
                                            <a href="#" class="view-more">Try Now &gt;</a>
                                        </div>
                                    </div>
                                    <!-- Product actions-->
                                    <!-- <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                        <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="#">View options</a></div>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </section>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default {
    name: 'WardList',
    mixins: [],
    components: {},
    props: {},
    data () {
      return {}
    },
    created: function () {},
    mounted: function () {
      let payload = {
        store_id: this.$route.params.wname
      }
      this.$store.dispatch('GET_WARD_LIST', payload)
    },
    updated: function () {},
    watch: {},
    computed: {
      ...mapGetters(['ward_list'])
    },
    methods: {},
    beforeDestroy () {}
  }
</script>
<style scoped>
#kids{
    padding-top:20px !important;
    padding-bottom:20px !important;
}
#kids .section-heading-custom {
    margin-bottom:25px !important;
}
.section-heading-custom h2 {
    font-size: 18px !important;
    font-weight: 600 !important;
    color: #898383 !important;
    font-family: sans-serif;
    
}
.view-more{
    font-size:9px;
    color:#5fd420;
}
.view-more-desc{
    margin-top:4px;
    font-size:10px;
    color:#7e7676;
}
.card-title-heading {
    font-size: 13px;
    font-family: cursive;
}
.summary-text{
   font-size: 10px;
    font-family: initial;
    margin-bottom: 0;
}
.badge {
 background-color: #74baa9 !important;
}
</style>

