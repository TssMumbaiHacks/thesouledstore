<template>
    <div class="container-fluid margin-top">
        <div class="row">
        <!-- Left Section -->
        <div class="col-lg-6 col-md-6 left-section">
          <product-list :listData="stores" :type="'virtual'"></product-list>
        </div>

        <!-- Right Section -->
        <div class="col-lg-6 col-md-6 right-section">
            <div class="row">
                <div class="col-lg-6 col-md-4 right-section section-heading-custom" style="margin-top:12px;">
                    <h2>Virtual Assistant</h2>
                    <span class="summary-text">This area is blank and ready for content</span>
                </div>
                
                    <div class="col-lg-6 col-md-4">
                        <form>
                            <span class="summary-text">Upload User Modal</span>
                            <!-- <input type="file" class="form-input"> -->
                            <input type="file" @change="handleFileUpload" id="inputFile" multiple accept="file_extension|image/*" />
                            <button @click="handleSubmitForm2" class="btn btn-primary text-uppercase mt-3" > Submit
                            </button>
                        </form>
                    </div>
            </div>
            <div class="row">
              <img style="margin-left: 14px;margin-top: 6px; margin-bottom: 10px;" :src="assitant">
            </div>
            <!-- <h3 class="my-4">Details</h3>
            <p class="text-muted">This area is blank and ready for content.</p> -->
        </div>
        </div>
  </div>
</template>
<script>
  import ProductList from './list.vue'
  import {mapGetters} from 'vuex'
  export default {
    name: 'virtualTry',
    mixins: [],
    components: {ProductList},
    data () {
      return {
        selectedFiles: []
      }
    },
    created: function () {},
    mounted: function () {
      this.$store.dispatch('GET_STORES')
      let payload = {
        store_id: '1'
      }
      this.$store.dispatch('GET_ASSISTANT', payload)
    },
    updated: function () {},
    watch: {},
    computed: {
      ...mapGetters(['stores', 'assitant'])
    },
    methods: {
      handleFileUpload (event) {
        // const file = event.target && event.target.files && event.target.files[0]
        this.selectedFiles = event.target.files
      },
      handleSubmitForm2 () {
        let formData = new FormData()
        if (this.selectedFiles.length > 0) {
          for (let i = 0; i < this.selectedFiles.length; i++) {
            formData.append('media', this.selectedFiles[i])
          }
          // this.$store.dispatch('GET_ASSISTANT', {formData})
        }
      }
    },
    beforeDestroy () {}
  }
</script>
<style>
    .left-section {
      border-right: 1px solid #ddd;
      padding-right: 15px;
    }
    .product-tile {
      margin-bottom: 15px;
    }
    .right-section {
      padding-left: 15px;
    }
    .product-image {
      height: 150px;
      width: 100%;
      object-fit: cover;
    }
    .margin-top {
      margin-top: 100px;
    }
    .section-heading-custom h2 {
    font-size: 18px !important;
    font-weight: 600 !important;
    color: #898383 !important;
    font-family: sans-serif;
    }
    .section-heading-custom h2 {
    font-size: 18px !important;
    font-weight: 600 !important;
    color: #898383 !important;
    font-family: sans-serif;
    }
    .summary-text{
    font-size: 11px;
    font-family: initial;
    margin-bottom: 0;
    }
    .section-heading-custom h2 {
    font-size: 18px !important;
    font-weight: 600 !important;
    color: #898383 !important;
    font-family: sans-serif;
    }
</style>
