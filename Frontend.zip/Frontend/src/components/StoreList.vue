<template>
  <div>
    <list :listData="stores" :type="'store'"></list>
  </div>
</template>
<script>
  import List from './list.vue'
  import {mapGetters} from 'vuex'
  export default {
    name: 'app',
    mixins: [],
    components: {List},
    data () {
      return {}
    },
    created: function () {},
    mounted: function () {
      this.$store.dispatch('GET_STORES')
    },
    updated: function () {},
    watch: {},
    computed: {
      ...mapGetters(['stores'])
    },
    methods: {},
    beforeDestroy () {}
  }
</script>
<style scoped>
</style>

