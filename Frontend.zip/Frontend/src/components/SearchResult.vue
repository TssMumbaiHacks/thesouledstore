<template>
  <div>
    <!-- Search -->
    
    <search></search>
    <!-- ***** Kids Area Starts ***** -->
    <search-list></search-list>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import Search from './Search.vue'
  import SearchList from './SearchList.vue'
  export default {
    name: 'SearchResult',
    mixins: [],
    components: {Search, SearchList},
    computed: {
      ...mapGetters(['search_products', 'search_type', 'search_sumarry', 'search_input'])
    },
    data () {
      return {}
    },
    mounted: function () {}
  }
</script>
