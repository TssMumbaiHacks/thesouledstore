<template>
  <div>
    <!-- Search -->
    <search></search>
    <!-- ***** Kids Area Starts ***** -->
    <store-list></store-list>
  </div>
</template>
<script>
  import Search from './Search.vue'
  import {mapGetters} from 'vuex'
  import StoreList from './StoreList.vue'
  export default {
    name: 'home',
    mixins: [],
    computed: {
      ...mapGetters(['stores'])
    },
    components: {Search, StoreList},
    data () {
      return {}
    }
  }
</script>
