<template>
  <div>
    <main-banner></main-banner>
  </div>
</template>
<script>
  import MainBanner from './Banner.vue'
  export default {
    name: 'app',
    mixins: [],
    components: {MainBanner},
    data () {
      return {}
    },
    created: function () {},
    mounted: function () {},
    updated: function () {},
    watch: {},
    computed: {},
    methods: {},
    beforeDestroy () {}
  }
</script>
