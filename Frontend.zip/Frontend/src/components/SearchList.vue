<template>
  <div>
    <list :listData="search_products" :summary="search_sumarry" :type="'search'"></list>
  </div>
</template>
<script>
  import List from './ProductList.vue'
  import {mapGetters} from 'vuex'
  export default {
    name: 'SearchList',
    mixins: [],
    components: {List},
    data () {
      return {}
    },
    created: function () {},
    mounted: function () {},
    updated: function () {},
    watch: {},
    computed: {
      ...mapGetters(['search_products', 'search_type', 'search_sumarry', 'search_input'])
    },
    methods: {},
    beforeDestroy () {}
  }
</script>
<style scoped>
</style>

