<template>
  <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="under-footer">
                        <p>Copyright © 2024 ClosetHub Co., Ltd. All Rights Reserved. 
                        <br>Design: <a href="https://templatemo.com" target="_parent" title="free css templates">TheSouledStore</a></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</template>
<script>
  export default {
    name: 'Footer',
    mixins: [],
    components: {},
    data () {
      return {}
    },
    created: function () {},
    mounted: function () {},
    updated: function () {},
    watch: {},
    computed: {},
    methods: {},
    beforeDestroy () {}
  }
</script>
<style scoped>
footer{
    margin-top: 0px;
    padding: 0px;
}
.under-footer{
    margin-top:0px;
}
</style>

