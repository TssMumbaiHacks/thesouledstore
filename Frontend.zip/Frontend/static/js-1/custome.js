var fullwidth;

$(document).ready(function() {

    $('#footernav ul li a').each(function() {
        $(this).attr('href', '#')
    })
    $('.addbx ').each(function() {
        var ac = $(this).hasClass('active')
        if ($(this).hasClass('active')) {
            $(ac).addClass('naresh')
        }
    })

    fullwidth = $(window).width();

    $('body').on('click', '.mobilenav', function() {
        $('.navbar-collapse').toggleClass('activenav')
        if ($('.navbar-collapse').hasClass('activenav')) {
            $('body').addClass('_freeze')
            $('.overlay').addClass('show')
            setTimeout(function() {
                $('.shop').addClass('show')
                $('.shop a').attr('aria-expanded', 'true')
                $('#productnav').parent().addClass('navopen')
            }, 200)
        } else {
            $('body').removeClass('_freeze')
            $('.overlay').removeClass('show')
        }
    })

    $('body').on('click', '.newmobilenav', function() {
        $('.navbar-collapse').toggleClass('activenav')
        if ($('.navbar-collapse').hasClass('activenav')) {
            $('body').addClass('_freeze')
            $('.overlay').addClass('show')
            setTimeout(function() {
                $('.shop').addClass('show')
                $('.shop a').attr('aria-expanded', 'true')
                $('#productnav').parent().addClass('navopen')
                $('.navopen').removeClass('navopen')
                $('.actPosi0').addClass('navopen')
            }, 200)
        } else {
            $('body').removeClass('_freeze')
            $('.overlay').removeClass('show')
        }
    })

    $('body').on('click', '.mobilenavfootertab', function() {
        $('.navbar-collapse').addClass('activenav')
        if ($('.navbar-collapse').hasClass('activenav')) {
            $('body').addClass('_freeze')
        }
    })
    setInterval(function() {
        if ($('.navbar').hasClass('fixed-top')) {
            $('.navbar-brand:not(.slidem)').toggleClass('closeeys')
        } else {
            $('.navbar-brand:not(.slidem)').toggleClass('closeeys')
        }
    }, 2000)
    setInterval(function() {
        $('.text-banner-wrapper .know-more-btn').toggleClass('know-more-shadow')
    }, 1800)
    $('body').on('click', '#togglesearch,.searchbutton', function() {
        $('.mobilesearch').toggleClass('active');
        if ($('.mobilesearch').hasClass('active')) {
            setTimeout(function() {
                document.getElementById('globSearch').focus();
            }, 200)
        }
    })
    $('body').on('click', '.togglebtn', function() {
        var b = $(this).attr('itemid');
        $('#' + b).slideToggle();
    })
    $('body').on({
        mouseover: function() {
            var wd = $(window).width();
            $('.fullwidth.deskFullWidth').css('width', wd + 1);
            var lp = $(this).offset().left;
            $(this).find('.fullwidth.deskFullWidth').css('left', -lp)
            $(this).addClass('activeMenu');
            $(this).find('.dropdown-menu.deskDropMenu, .fullwidth.deskFullWidth, .dropdown-menu.right').stop(true, true).delay(100).fadeIn(300);
        },
        mouseout: function() {
            $(this).find('.dropdown-menu.deskDropMenu, .fullwidth.deskFullWidth, .dropdown-menu.right').stop(true, true).delay(100).fadeOut(300);
            $(this).removeClass('activeMenu');
        }
    }, 'ul.navbar-nav li.dropdown');

    $('body').on('click', '.dropdown-menu.deskDropMenu, .fullwidth.deskFullWidth, .dropdown-menu.right', function (){
        var b = $(this).parent()
        $(b).removeClass('active')
        $(this).stop(true, true).delay(100).fadeOut(300);
    })

    $(window).scroll(function(event) {
        var scroll = $(window).scrollTop();
        if (scroll > 30) {
            $('.navbar').addClass('fixed-top')
            if ($('.appInstallWrapper').length) {
              $('.appInstallWrapper').addClass('fixed-top')
              $('.navbar').css('top', '62px')
              $('.appInstallWrapper').css('border-bottom', '1px solid #E4E4E4')
            }
        } else {
            $('.navbar').removeClass('fixed-top')
            if ($('.appInstallWrapper').length) {
              $('.appInstallWrapper').removeClass('fixed-top')
              $('.navbar').css('top', '')
              $('.appInstallWrapper').css('border-bottom', '')
            }
        }
    });

    $(window).scroll(function(event) {
        var scroll = $(window).scrollTop();
        if (scroll > 30) {
            $('.app-install-popup').addClass('app-fixed-popup')
        } else {
            $('.app-install-popup').removeClass('app-fixed-popup')
        }
    });


    $("body").on("click", '.navsubtitle', function(e) {
        e.stopPropagation();
        e.preventDefault();
        var t = $(this).parent();
        if ($(t).hasClass('navopen')) {
            $(t).toggleClass('navopen');
        } else {
            $('div').removeClass('navopen');
            $(t).toggleClass('navopen');
        }
    });

    $("body").on("click", '.newnavsubtitle', function(e) {
        e.stopPropagation();
        e.preventDefault();
        var t = $(this).parent();
        if ($(t).hasClass('navopen')) {
        } else {
            $('div').removeClass('navopen');
            $(t).toggleClass('navopen');
        }
    });

    $("body").on("click", '.mblesublevel2', function(e) {
        var t = $(this).parent();
        $(t).removeClass('navopen')
        $(this).stop(true, true).delay(100).fadeOut(300);
    });

    $("body").on("click", '.dropdown-toggle', function(e) {
        $('.Men').addClass('navopen');
        $('.Women').addClass('navopen');
    });

    $('body').on('change', '.artistfilter input[type="checkbox"]', function() {
        var b = $(this).val()
        if (this.checked) {
            // console.log(b)
            if (b == 'all') {
                $('button.all').addClass('activebtn')
                $('.filterbox ').show()
                $('#afilter').removeClass('addfilter')
                $('.artistfilter input:checkbox').removeAttr('checked')
                $(this).attr('checked', 'checked')
            } else {
                $('button.all').removeClass('activebtn')
                // console.log('custom')
                $('#afilter').addClass('addfilter')
                $('.filterbox ').hide()
                checkeditems()
            }
        } else {
            var a = $('.artistfilter input[type="checkbox"]').map(function() {
                if (this.checked)
                    return $(this).val();
            }).toArray();
            if (a.length == 0) {
                $('.filterbox ').show()
                $('#afilter').removeClass('addfilter')
                $('.artistfilter input:checkbox').removeAttr('checked')
            } else {
                $('.' + b).hide()
            }
        }
    })



    fileinputChange();

    // dellivery page
    $('.ckbox').each(function() {
        $(this).on('click', function() {
            var b = $(this).parent().parent();
            $('.addbx').removeClass('active');
            if ($(this).attr('checked', 'checked')) {
                console.log('checked');
                $(b).addClass('active');
            }
        })
    })
    // end of dellivery page
    // login register
    $('.forgotpassword').click(function() {
        $('.loginregister').hide();
        $('.forgotcontainer').show();
    })


    $('body').on('click', '.toggleglobal', function() {
        var d = $(this).attr('data-toggle');
        $(d).toggleClass('activediv')
    })

});
// end of document ready

function checkeditems() {
    $('.artistfilter input:checked').each(function() {
        var d = $(this).val()
        $('.' + d).show()
    })
}

function filteropt(opt) {
    var b = $('.filteroption');
    if ($('#' + opt).hasClass('active')) {
        $('#' + opt).toggleClass('active');
        $('.' + opt).toggleClass('active');
        $(b).toggleClass('active');
        $('.plisting').toggleClass('disable');
    } else {
        $('.filteroptionsModal').removeClass('active');
        $('.plisting').removeClass('disable');
        $(b).removeClass('active');
        $('.btn').removeClass('active');
        $('#' + opt).addClass('active');
        $('.' + opt).addClass('active');
        $(b).addClass('active');
        $('.plisting').addClass('disable');
    }
}

function getUrl() {
    var b = window.location.href;
}

function fileinputChange() {
    $('.uploadimg').on('click', function() {
        var vale = $(this).val();
        var path = $(this).parent().next();
        $(path).html(vale);
    })
}
