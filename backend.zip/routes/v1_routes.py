from controllers import (
    AuthController,
    HealthController,
    DataController,
)

# API Routes
V1RoutesDict = {
    "/health": HealthController.AppHealthCheck(),
    "/login": AuthController.Login(),

    # Search
    "/text":DataController.Search(),
    "/search": DataController.SmartSearch(),
    "/stores": DataController.Stores(),
    "/user_closets": DataController.UserClosets(),

    "/similar": DataController.SimilarProduct(),
    "/tryon": DataController.VirtualTryOn()
}

