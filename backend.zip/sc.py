from pymongo import MongoClient
import os
import json
import falcon
from helpers import helper

from vertexai.preview.generative_models import GenerativeModel, Part
from google.cloud import storage
from vertexai.vision_models import Image, MultiModalEmbeddingModel, MultiModalEmbeddingResponse
import vertexai
from PIL import Image as PILImage
import chromadb

from tqdm import tqdm
import requests
from io import BytesIO

from vertexai.vision_models import Image, MultiModalEmbeddingModel, MultiModalEmbeddingResponse
from vertexai.language_models import TextEmbeddingInput, TextEmbeddingModel

from settings import OPEN_API_KEY
from openai import OpenAI

from vertexai.language_models import TextEmbeddingInput, TextEmbeddingModel
text_emb_model = TextEmbeddingModel.from_pretrained("text-embedding-004")


dimensionality = 512

db_password = "3EletoSLk3EEvPqR"
connection_string = f"mongodb+srv://hrhk123:{db_password}@cluster0.ajyhw.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

client = MongoClient(connection_string)

db = client['closet']
collection = db['data_all_1']
documents = collection.find()

model = MultiModalEmbeddingModel.from_pretrained("multimodalembedding")
text_emb_model = TextEmbeddingModel.from_pretrained("text-embedding-004")
client_image = chromadb.PersistentClient(path="vdb")
collection_image = client_image.get_or_create_collection(name="fashion_db")
vertexai.init(project="ai-coe-386307", location="us-central1")

def generate_embeddings(image):
  response = requests.get(image)
  with open("temp_image.jpg", "wb") as file:
    file.write(response.content)

  image = Image.load_from_file("temp_image.jpg")
  embeddings = model.get_embeddings(
      image=image,
      dimension=1408,
  )
  os.remove("temp_image.jpg")
  return embeddings.image_embedding


prod_li = []
for doc in documents:
  prod_li.append(doc)


file_li = []
emb_li = []
from tqdm import tqdm
for i in tqdm(range(0,100,1)):
  try:
    prod = prod_li[i]
    for img in prod.get("images"):
      emb = generate_embeddings(img)
      file_li.append(img)
      emb_li.append(emb)
  except Exception as err:
    print("hehel", str(err))
    continue

final_li = []
final_emb_li = []
for i in range(len(file_li)):
  if file_li[i] not in final_li:
    final_li.append(file_li[i])
    final_emb_li.append(emb_li[i])

print(len(final_li))
print(len(final_emb_li))

collection_image.add(
    ids = final_li,
    embeddings = final_emb_li
)

client_text = chromadb.PersistentClient(path="content")
collection_text = client.get_or_create_collection(name="content_db")
attr = ['product_id','product_name','product_type','description','neckline', 'sleeve_length', 'categories', 'artists', 'attributes', 'patterns', 'styles', 'material_compositions','occasions']
sem_data = []
for prod in prod_li:
  data = {}
  for a in attr:
    data[a] = prod[a]
  sem_data.append(data)
text_emb_final = []
model = TextEmbeddingModel.from_pretrained("text-embedding-004")

for batch in range(0,len(sem_data),15):
  dimensionality = 512
  task = "RETRIEVAL_DOCUMENT"
  batch_data = sem_data[batch:batch+15]
  inputs = [TextEmbeddingInput(str(text), task) for text in batch_data]
  kwargs = dict(output_dimensionality=dimensionality) if dimensionality else {}
  embeddings = model.get_embeddings(inputs, **kwargs)
  text_emb_li = [embedding.values for embedding in embeddings]
  text_emb_final.extend(text_emb_li)


id_li = [str(s.get("product_id")) for s in sem_data]
collection_text.add(
    ids = id_li,
    embeddings = text_emb_final
)


