import jwt
import falcon
import settings


def encodeJwt(payload):
    return jwt.encode(payload, settings.SECRET_KEY, algorithm='HS512')

def decodeJwt(encoded, verify=True):
    options = {'verify_aud': False, 'require_sub': True}

    try:
        try:
            return jwt.decode(encoded, settings.SECRET_KEY, verify=verify, algorithms=['HS512'], options=options)
        except:
            raise falcon.HTTPUnauthorized("Your session has expired.Kindly logout and login")
    except jwt.ExpiredSignatureError as e:
        raise falcon.HTTPUnauthorized("Token Expired")
