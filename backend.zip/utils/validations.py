import re

def email_validation(email):
    regex = '^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$'
    if re.search(regex, email):
        return True
    return False

# Not to be used for email addresses
def data_sanitization(raw_html):
    remove_lt = re.sub(r'<', '&lt', str(raw_html))
    remove_gt = re.sub(r'>', '&gt', remove_lt)
    clean_data = re.sub(r'[.]', '', remove_gt)
    clean_data = clean_data.replace("’","'").replace("‘","'").replace('“','"').replace('”','"')

    return str(clean_data)
