Closet Hub

pyenv install 3.10.12

pyenv local 3.10.12

python -m venv venv


linux:
source venv/bin/activate

