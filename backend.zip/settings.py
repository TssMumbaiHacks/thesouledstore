import os
from os.path import join, dirname
from dotenv import load_dotenv, find_dotenv

dotenv_path = join(dirname(__file__), '.env')
load_dotenv(find_dotenv(), override=True)
ENV = os.environ

V1_API_PREFIX = '/api/v1'
JWT_EXPIRY_DAY = 30
SECRET_KEY = "245273587324583258732r83hf8743267"
LLAMA_API_KEY = "LA-b1d72a138c4e42e58f879162a84003dee715930959dc4bfbad89ca706ad2e1bb"


# AWS S3 credentials
AWS_ACCESS_KEY_ID='AKIASXP4WNCKO4PDSPC4'
AWS_SECRET_ACCESS_KEY='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'
AWS_BUCKET_NAME='contactusimages'


OPEN_API_KEY="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"
