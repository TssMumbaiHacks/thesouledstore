import json
import falcon
from pymongo.errors import ConnectionFailure

class AppHealthCheck:
    """
    To Check APP Health Status
    """

    def on_get(self, req, resp):
        """
        Handles GET request for app health check.
        """
        # Initialize the health check response data
        data = {
            "health": "OK",
            "message": "Ok, Working Fine.",
            "db_health": False
        }

        try:
            mongo_session = req.context["mongo_session"]
            data["db_health"] = bool(mongo_session['closet']['healthcheck'].find_one({"health": True}))
        except ConnectionFailure:
            data["message"] = "Database connection failed."

        # Set response status and content
        resp.status = falcon.HTTP_200
        resp.content_type = 'application/json'
        resp.text = json.dumps(data)
