import os
import json
import falcon
from helpers import helper

from vertexai.preview.generative_models import GenerativeModel, Part
from google.cloud import storage
from vertexai.vision_models import Image, MultiModalEmbeddingModel, MultiModalEmbeddingResponse
import vertexai
from PIL import Image as PILImage
import chromadb

from tqdm import tqdm
import requests
from io import BytesIO

from vertexai.vision_models import Image, MultiModalEmbeddingModel, MultiModalEmbeddingResponse
from vertexai.language_models import TextEmbeddingInput, TextEmbeddingModel

from settings import OPEN_API_KEY
from openai import OpenAI

from vertexai.language_models import TextEmbeddingInput, TextEmbeddingModel
text_emb_model = TextEmbeddingModel.from_pretrained("text-embedding-004")


dimensionality = 512


os.environ["HF_API_TOKEN"] = "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"


client_text = chromadb.PersistentClient(path="content")
collection_text = client_text.get_or_create_collection(name="content_db")
task="RETRIEVAL_DOCUMENT"

text = "I want rather I need clothes to wear in hackathon"

inputs = [TextEmbeddingInput(str(text), task)]
kwargs = dict(output_dimensionality=dimensionality) if dimensionality else {}
embeddings = text_emb_model.get_embeddings(inputs, **kwargs)
text_emb_li = [embedding.values for embedding in embeddings]



PROJECT_ID = "ai-coe-386307"
LOCATION = "us-central1"
model = MultiModalEmbeddingModel.from_pretrained("multimodalembedding")
client_image = chromadb.PersistentClient(path="vdb")

collection_image = client_image.get_or_create_collection(name="fashion_db")
os.environ['OPENAI_API_KEY'] = OPEN_API_KEY
path_to_json = '/home/user/Desktop/Mumbaihack/closet_hub/aiml_cred.json'
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = path_to_json

client = OpenAI()

class Search():
    """
    To Check APP Search
    """

    def on_post(self, req, resp):
        """
        Post Request For Search
        """
        req_data = req.context["data"]
        mongo_session = req.context['mongo_session']
        query = req_data["query"]
        store_id = req_data["store_id"]

        products, summary = extract_products(mongo_session, query, store_id)
        if not products:
            products, summary = extract_products(mongo_session, query, store_id, explanation_backup=1)

        data = {
            "summary" : summary,
            "products": products
        }
        resp.text = json.dumps(data, default=str)
        resp.content_type = 'application/json'

attribute_keywords = {
    "skin_color_complextion": "",
    "summmary":"",
    "product_name": [],
    "price": [],
    "product_type": [],
    "neckline": [],
    "sleeve_length": [],
    "categories": [],
    "artists": [],
    "attributes": [],
    "patterns": [],
    "styles": [],
    "material_compositions": [],
    "care_instructions": [],
    "lengths": [],
    "seasons": [],
    "closure_types": [],
    "occasions": [],
    "special_features": [],
    "sustainability_features": [],
    "trending_statuses": [],
    "textures": [],
    "weights": [],
    "allergens": [],
    "colors":[]
}

def generate_prompt(user_query, explanation_backup=0):
    explanation_backup = """Analyze the following user query and extract specific product attributes according to the provided schema only and dont include if no attribute is macthing. The output should be a dictionary in JSON format with key-value pairs, where each key corresponds to an attribute. The price attribute should be in decimal format and must not contain any strings. Ensure the JSON starts with { and ends with }, without backticks. In the same JSON output, include a straightforward summary of the fashion suggestions based on the customers query, addressing the customer directly and without adding any query suggestions and summary should be catchy and attractive and also add skin color complextion in json and filter best cloth recommendation based on the color completion for colors and always include products name as query"""

    explanation = '''Analyze the following user query and extract specific product attributes according to the provided schema. The goal is to generate a JSON object formatted as a dictionary with key-value pairs that can be used as filters for a MongoDB query.

    Requirements:
    1. Include only attributes that are directly relevant to the user’s query. Do not include attributes that are not explicitly mentioned or implied in the query.
    2. Always include `product_name`, `categories`, and `summary` in the output, even if they are `None`.
    3. Exclude all other attributes that are `None`, empty, or irrelevant to the query, except for `product_name`, `categories`, and `summary`.
    4. Ensure the `price` attribute is in decimal format and only included if explicitly relevant to the query (e.g., when the user specifies a price range).
    5. Include `skin_color_complextion` if it directly relates to the query and filter the best clothing recommendations based on the color complexion for colors.
    6. Provide a straightforward, catchy, and attractive summary of the fashion suggestions based on the customer's query, addressing the customer directly.
    7. Format the JSON response correctly, starting with `{` and ending with `}`, without any backticks or additional code formatting.

    Use the following schema for the output attributes:

    {
        "skin_color_complextion": "",
        "summary": "",
        "product_name": [],
        "price": [],
        "product_type": [],
        "neckline": [],
        "sleeve_length": [],
        "categories": [],
        "artists": [],
        "attributes": [],
        "patterns": [],
        "styles": [],
        "material_compositions": [],
        "care_instructions": [],
        "lengths": [],
        "seasons": [],
        "closure_types": [],
        "occasions": [],
        "special_features": [],
        "sustainability_features": [],
        "trending_statuses": [],
        "textures": [],
        "weights": [],
        "allergens": [],
        "colors": []
    }

    Example JSON output based on a query like "I want to go to a party":

    {
        "product_name": null,
        "categories": null,
        "occasions": ["party"],
        "summary": "For a party, choose stylish and vibrant outfits that make you stand out!"
    }

    Ensure the JSON response is concise, relevant, and tailored as filters for a MongoDB query based on the user’s query.'''

    schema_keys = ", ".join(attribute_keywords.keys())

    if explanation_backup:
        explanation = explanation_backup

    prompt = f"{explanation}\nSchema Attributes: {schema_keys}\nUser Query: {user_query}\nExtracted Attributes:"
    return prompt


def extract_products(mongo_session, query, store_id, explanation_backup=0):
    """
    Fetch products based on the filter criteria from MongoDB.
    """
    collection_name =f"data_all_{store_id}"

    if collection_name in mongo_session['closet'].list_collection_names():
        print(f"The collection '{collection_name}' exists in the database.")
    else:
        return {}, "No Data Found..."

    prompt = generate_prompt(query, explanation_backup=explanation_backup)

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.5
        )

    attributes_text = response.choices[0].message.content

    try:
        product_details = json.loads(attributes_text)
    except json.JSONDecodeError as e:
        print("Failed to decode JSON:", e)
        product_details = {}

    summary =  product_details.get("summary", "")
    user_complexion =  product_details.get("skin_color_complextion", "")

    query = construct_query(product_details, user_complexion=user_complexion)
    print("query", query)

    users_collection = mongo_session['closet'][collection_name]

    def to_array(value):
        return value if isinstance(value, list) else [value]

    pipeline = [
        {'$match': query},
        {'$addFields': {
            'relevance': {
                '$add': [
                    {'$cond': [{'$in': ['$product_name', to_array(product_details.get('product_name', []))]}, 25, 0]},
                    {'$cond': [{'$in': ['$colors', to_array(product_details.get('colors', []))]}, 20, 0]},
                    {'$cond': [{'$in': ['$categories.category', to_array(product_details.get('categories', []))]}, 5, 0]},
                    {'$cond': [{'$in': ['$price', to_array([product_details.get('price', 0)])]}, 8, 0]},
                    {'$cond': [{'$in': ['$artists.name', to_array(product_details.get('artists', []))]}, 6, 0]},
                    {'$cond': [{'$in': ['$attributes.name', to_array(product_details.get('attributes', []))]}, 4, 0]},
                    {'$cond': [{'$in': ['$patterns.pattern', to_array(product_details.get('patterns', []))]}, 4, 0]},
                    {'$cond': [{'$in': ['$styles.style', to_array(product_details.get('styles', []))]}, 5, 0]},
                    {'$cond': [{'$in': ['$material_compositions.composition', to_array(product_details.get('material_compositions', []))]}, 4, 0]},
                    {'$cond': [{'$in': ['$care_instructions.instruction', to_array(product_details.get('care_instructions', []))]}, 2, 0]},
                    {'$cond': [{'$in': ['$lengths.length', to_array(product_details.get('lengths', []))]}, 3, 0]},
                    {'$cond': [{'$in': ['$seasons.season', to_array(product_details.get('seasons', []))]}, 3, 0]},
                    {'$cond': [{'$in': ['$closure_types.type', to_array(product_details.get('closure_types', []))]}, 2, 0]},
                    {'$cond': [{'$in': ['$occasions.occasion', to_array(product_details.get('occasions', []))]}, 6, 0]},
                    {'$cond': [{'$in': ['$special_features.feature', to_array(product_details.get('special_features', []))]}, 4, 0]},
                    {'$cond': [{'$in': ['$sustainability_features.feature', to_array(product_details.get('sustainability_features', []))]}, 3, 0]},
                    {'$cond': [{'$in': ['$trending_statuses.status', to_array(product_details.get('trending_statuses', []))]}, 5, 0]},
                    {'$cond': [{'$in': ['$textures.texture', to_array(product_details.get('textures', []))]}, 3, 0]},
                    {'$cond': [{'$in': ['$weights.weight', to_array([product_details.get('weights', 0)])]}, 2, 0]},
                    {'$cond': [{'$in': ['$allergens.allergen_info', to_array(product_details.get('allergens', []))]}, 1, 0]}
                ]
            }
        }},
        {'$sort': {'relevance': -1}}
    ]

    results = list(users_collection.aggregate(pipeline))
    final_result=[]

    for item in results:
        final_result.append({
            "product_name" : item["product_name"],
            "product_id" : item["product_id"],
            "stock" : item["stock"],
            "price" : item["price"],
            "special_price" : item["special_price"],
            "categories" : item["categories"],
            "artists" : item["artists"],
            "patterns" : item["patterns"],
            "material_compositions" : item["material_compositions"],
            "seasons" : item["seasons"],
            "occasions" : item["occasions"],
            "textures" : item["textures"],
            "images" : item["images"],
            })

    return final_result, summary


def construct_query(product_features, user_complexion=""):
    query = {}

    schema_mapping = {
        'product_name': 'product_name',
        'price': 'price',
        'product_type': 'product_type.type',
        'neckline': 'neckline.name',
        'sleeve_length': 'sleeve_length.length',
        'categories': 'categories.category',
        'artists': 'artists.name',
        'attributes': 'attributes.name',
        'patterns': 'patterns.pattern',
        'styles': 'styles.style',
        'material_compositions': 'material_compositions.composition',
        'care_instructions': 'care_instructions.instruction',
        'lengths': 'lengths.length',
        'seasons': 'seasons.season',
        'closure_types': 'closure_types.type',
        'occasions': 'occasions.occasion',
        'special_features': 'special_features.feature',
        'sustainability_features': 'sustainability_features.feature',
        'trending_statuses': 'trending_statuses.status',
        'textures': 'textures.texture',
        'weights': 'weights.weight',
        'allergens': 'allergens.allergen_info',
        'colors': 'colors'
    }

    # Expanded mapping of complexion types to suitable colors
    complexion_color_mapping = {
        "fair": [
            "light blue", "peach", "light pink", "white", "lavender", 
            "mint green", "beige", "soft yellow", "baby blue", 
            "powder pink", "ivory", "light coral", "sky blue"
        ],
        "medium": [
            "green", "blue", "brown", "olive", "mustard", 
            "teal", "burnt orange", "rust", "turquoise", 
            "coral", "forest green", "khaki", "navy blue", 
            "deep purple", "charcoal", "burgundy"
        ],
        "dark": [
            "red", "white", "yellow", "green", "black", 
            "cobalt blue", "emerald green", "magenta", 
            "mustard yellow", "tan", "royal blue", 
            "violet", "fuchsia", "gold", "silver", 
            "copper", "maroon", "deep red", "orange"
        ],
        "very fair": [
            "soft pink", "aqua", "pastel colors", "light gray", 
            "cream", "light mint", "rose", "light lavender", 
            "champagne", "pale gold", "baby yellow"
        ],
        "olive": [
            "plum", "purple", "dark pink", "burgundy", 
            "warm beige", "dark green", "earth tones", 
            "chocolate", "bronze", "burnt sienna", "moss green"
        ],
        "tan": [
            "coral", "salmon", "peacock blue", "dark teal", 
            "ruby red", "amber", "warm gray", "sage green", 
            "mulberry", "topaz", "rosewood", "tangerine"
        ]
    }


    query = {}
    or_conditions = []
    for key, value in product_features.items():
        if key in schema_mapping:
            if isinstance(value, str):
                regex_condition = {
                    schema_mapping[key]: {
                        "$regex": value,
                        "$options": "i"
                    }
                }
                or_conditions.append(regex_condition)
            elif isinstance(value, list) and value:
                regex_conditions = [
                    {schema_mapping[key]: {"$regex": v, "$options": "i"}}
                    for v in value if isinstance(v, str)
                ]
                or_conditions.extend(regex_conditions)
            elif key == 'price' and isinstance(value, (int, float)):
                or_conditions.append({schema_mapping[key]: {"$lte": value}})
            else:
                or_conditions.append({schema_mapping[key]: value})

    # Add color filtering based on user's complexion
    if user_complexion and user_complexion in complexion_color_mapping:
        suitable_colors = complexion_color_mapping[user_complexion]
        or_conditions.append({
            'colors': {
                "$in": suitable_colors
            }
        })
    # Combine all conditions under $or operator
    query = {"$or": or_conditions} if or_conditions else {}

    return query


class SmartSearch:
    """
    To Check APP Search
    """

    def on_post(self, req, resp):
        """
        Post Request For Search
        """
        mongo_session = req.context['mongo_session']
        media = req.get_param_as_list('media')
        store_id = req.get_param('store_id', 1)
        vibe_media = req.get_param_as_list('vibe_media')
        media_array = []
        vibe_media_array = []

        if media:
            for media_item in media:
                file_upload = helper.imageUploadToS3(media_item)
                media_array.append(file_upload)

        if vibe_media:
            for vibe_item in vibe_media:
                file_upload = helper.imageUploadToS3(vibe_item)
                vibe_media_array.append(file_upload)

        print(media_array, vibe_media_array)

        if media_array:
            image_data = image_search(media_array[0])
            list_of_imgs = image_data.get("ids")
            identifiers = [url.split('product/')[-1] for url in list_of_imgs[0]]
            print(identifiers, "3444")
        # Logic to get mongo query
        data = helper.extract_products_from_mongo(mongo_session, store_id, identifiers)

        resp.text = json.dumps(data, default=str)
        resp.content_type = 'application/json'


class Stores:
    def on_get(self, req, resp):
        reqData = req.context["data"]
        mongo_session = req.context['mongo_session']

        data = {
            "status": falcon.HTTP_200,
            "message": "",
            "object": {}
        }

        # Access the database
        db = mongo_session['closet']

        # Access the collection
        stores_collection = db['data_stores']

        # Fetch all documents from the collection
        store_documents = stores_collection.find()

        data['object']['stores'] = helper.bson_to_json(documents=store_documents)

        resp.status = falcon.HTTP_200
        resp.text = json.dumps(data)


image_url_mapping = {
    "gym_wear": "https://images.thesouledstore.com/public/theSoul/uploads/catalog/product/1729922602_6948770.jpeg",
    "family_party_wear": "https://images.thesouledstore.com/public/theSoul/uploads/catalog/product/1729922602_8641496.jpeg",
    "friends_party_wear": "https://images.thesouledstore.com/public/theSoul/uploads/catalog/product/1729922602_6471347.jpeg",
    "night_club": "https://images.thesouledstore.com/public/theSoul/uploads/catalog/product/1729923511_9522040.jpeg",
    "professional_attire": "https://images.thesouledstore.com/public/theSoul/uploads/catalog/product/1729922602_2717283.jpeg",
    "semi_professional_attire": "https://images.thesouledstore.com/public/theSoul/uploads/catalog/product/1729922602_2717283.jpeg",
    "traditional": "https://images.thesouledstore.com/public/theSoul/uploads/catalog/product/1729922602_6471347.jpeg"
}

class UserClosets:

    def on_post(self, req, resp):
        req_data = req.context["data"]
        user_data = req.context['user']

        user_id = user_data.get("user", None)
        store_id = req_data.get("store_id", None)
        closet_type = req_data.get("closet_type", None)

        if not user_id:
            raise falcon.HTTPUnauthorized("Your session has expired. Kindly logout and login.")

        if not store_id:
            raise falcon.HTTPUnauthorized("Kindly provide store.")

        data = {
            "status": falcon.HTTP_200,
            "message": "Closets Data.",
            "object": {}
        }

        mongo_session = req.context['mongo_session']
        collection_name = f"data_users_{store_id}"
        all_data_users_coll = mongo_session['closet'][collection_name]

        user_products = all_data_users_coll.find({'user_id': int(user_id)})
        product_ids = [product['product_id'] for product in user_products if 'product_id' in product]

        products_collection = mongo_session['closet'][f'data_all_{store_id}']

        pipeline = [
            {'$match': {'product_id': {'$in': product_ids}}},
            {'$unwind': '$closet_type_id'},
            {'$group': {
                '_id': '$closet_type_id',
                'products': {'$push': {
                    'product_id': '$product_id',
                    'product_name': '$product_name',
                    'images': '$images',
                    'stock': '$stock',
                    'price': '$price',
                    'special_price': '$special_price',
                }}
            }},
            {'$sort': {'_id': 1}}
        ]

        categorized_products = products_collection.aggregate(pipeline)

        if closet_type:
            categorized_products = [category for category in categorized_products if category['_id'] == closet_type]

        cat_list = [c.get("_id") for c in categorized_products]

        data = mongo_session['closet']["data_closet_types"].find({
            'id': {'$in': cat_list}
        }, {
            '_id': 0,
            'id': 1,
            'display_name': 1
        })

        if closet_type:
            data = {
                "closet_type": closet_type,
                "products": categorized_products[0]["products"]
            }
        else:
            f_data = list(data)
            for attire in f_data:
                print(attire, "4")
                attire_id = attire["id"]
                if attire_id in image_url_mapping:
                    attire["image_url"] = image_url_mapping[attire_id]
            print(f_data)

            data = {
                "closet_types": f_data
            }

        resp.status = falcon.HTTP_200
        resp.text = json.dumps(data)


class SimilarProduct:

    def on_post(self, req, resp):
        pass


def generate_embeddings(image):
  response = requests.get(image)
  with open("temp_image.jpg", "wb") as file:
    file.write(response.content)

  image = Image.load_from_file("temp_image.jpg")
  embeddings = model.get_embeddings(
      image=image,
      dimension=1408,
  )
#   os.remove("temp_image.jpg")
  return embeddings.image_embedding


# def generate_embeddings_path(image):

#   image = Image.load_from_file(image)
#   embeddings = model.get_embeddings(
#       image=image,
#       dimension=1408,
#   )
#   return embeddings.image_embedding


def image_search(image):
  emb = generate_embeddings(image)
  print(emb, "33", collection_image)
  result = collection_image.query(
      query_embeddings = emb,
      n_results = 5
  )
  return result


import requests
import base64
from gradio_client import Client, file


def image_to_base64(image_content):
    """
    Convert binary image content to a base64 string.
    """
    return base64.b64encode(image_content).decode('utf-8')

def download_image(url):
    response = requests.get(url)
    response.raise_for_status()  # Raises an error on a bad status
    return response.content


import requests
from vertexai.vision_models import Image
from gradio_client import Client, file as grfile

def download_image(model, garment):
    response = requests.get(model)
    with open("model.jpg", "wb") as file:
      file.write(response.content)
    response = requests.get(garment)
    with open("garment.jpg", "wb") as file:
      file.write(response.content)


class VirtualTryOn():

    def on_post(self, req, resp):

        media = req.get_param_as_list('media')
        media_array = [1]

        # for media_item in media:
        #     file_upload = helper.imageUploadToS3(media_item)
        #     media_array.append(file_upload)

        data = {
            "url": "https://prod-img.thesouledstore.com/public/theSoul/uploads/catalog/product/1729261002_3112440.jpg?format=webp&w=480&dpr=0.9"
        }
  
        resp.status = falcon.HTTP_200
        resp.text = json.dumps(data)
        return

        final_image_url = "https://prod-img.thesouledstore.com/public/theSoul/uploads/catalog/product/1729261002_3112440.jpg?format=webp&w=480&dpr=0.9"
        try:
            if media_array:
                client = Client("Nymbo/Virtual-Try-On")
                download_image("https://prod-img.thesouledstore.com/public/theSoul/uploads/catalog/product/1729261002_3112440.jpg?format=webp&w=480&dpr=0.9","https://prod-img.thesouledstore.com/public/theSoul/uploads/catalog/product/1729309603_2027035.jpg?format=webp&w=480&dpr=0.9")
                result = client.predict(
                        dict={"background":grfile("model.jpg"),"layers":[],"composite":None},
                        garm_img=grfile("garment.jpg"),
                        garment_des="Hello!!",
                        is_checked=True,
                        is_checked_crop=False,
                        denoise_steps=30,
                        seed=42,
                        api_name="/tryon"
                )
                os.remove("model.jpg")
                os.remove("garment.jpg")
                if result:
                    file_path = result[0]
                    with open(file_path, 'rb') as file:
                        final_image_url = helper.imageUploadToS3new(file, file_path.split('/')[-1])
                        print("final_image_url", final_image_url)
        except Exception as err:
            pass

        data = {
            "url": final_image_url
        }

        resp.status = falcon.HTTP_200
        resp.text = json.dumps(data)