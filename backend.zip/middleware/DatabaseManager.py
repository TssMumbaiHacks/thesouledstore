import falcon


class DatabaseManager(object):
    def __init__(self, mongo_session):
        self.mongo_session = mongo_session

    def process_request(self, req, res, resource=None):
        req.context["mongo_session"] = self.mongo_session
